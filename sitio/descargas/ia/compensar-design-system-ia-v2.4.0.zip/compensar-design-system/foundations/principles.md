1.1

# Principios del Sistema

Este sistema guía todas las decisiones de diseño para el Portal Público y el Portal Transaccional de Medicina Prepagada. Cada componente debe alinearse con estos principios.

01

## Claridad

La información debe presentarse de forma comprensible, directa y sin ambigüedades.

Evitar tecnicismos innecesarios y textos extensos en procesos médicos.
02

## Jerarquía funcional

Cada pantalla debe guiar al usuario hacia la acción correcta sin distracciones.

Una acción primaria clara por vista.
03

## Accesibilidad por defecto

La accesibilidad no es opcional ni posterior; es parte del diseño desde el inicio.

Todo componente debe cumplir WCAG 2.2 AA en Light, Dark y Alto Contraste.
04

## Consistencia sistemática

Los patrones deben repetirse de forma coherente para reducir carga cognitiva.

No crear variantes si ya existe un patrón aprobado.
05

## Empatía estructurada

En procesos sensibles, el sistema debe comunicar con claridad y respeto.

Los mensajes críticos deben orientar y ofrecer acción siguiente.

Estos principios son obligatorios para diseño, desarrollo y QA. Cualquier excepción **debe ser validada por UX.**

> Fuente: `docs/foundations/principles.html` · v2.4.0
