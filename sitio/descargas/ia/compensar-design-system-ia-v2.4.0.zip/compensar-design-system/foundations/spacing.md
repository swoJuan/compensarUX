1.4

# Espaciado

Sistema espacial transversal basado en una unidad base de **8px**. Usar siempre los tokens — nunca valores sueltos. Alineado con la grilla de 8pt de Figma y listo para implementaciones web y app.

Usar siempre `.p-16`, `.mb-24`, `var(--space-16)` — nunca valores hardcoded. Los tokens restringido requieren justificación de diseño.   Ver en Figma
8px
Unidad principal

Todo el sistema de espaciado se construye a partir de 8px. Esto asegura alineación visual entre componentes y facilita la implementación en desarrollo.

Múltiplos de **8px**: 8, 16, 24, 32, 48, 64, 96, 128 **Uso restringido:** 2px, 4px, 12px — solo cuando el diseño lo requiere explícitamente.
Nunca usar valores fuera de la escala · Nunca decimales · Siempre múltiplos de 8
Transversal para Web y App · Alineado con grilla de 8pt Figma
Tokens de espaciado

| Visual | Variable CSS | rem | Clases |  |
| --- | --- | --- | --- | --- |

Clases utilitarias
Implementación transversal
Mapa `$spacers`

```html
$space-8:   8px;
$space-16: 16px;
$space-24: 24px;
$space-32: 32px;
$space-48: 48px;
$space-64: 64px;

$spacers: (
  0: 0,
  1: $space-8,   // 8px
  2: $space-16,  // 16px
  3: $space-24,  // 24px
  4: $space-32,  // 32px
  5: $space-48,  // 48px
  6: $space-64,  // 64px
);
```

Uso en Web / App

```html
// Bootstrap utility → token CSS
// .p-3 = padding: 1rem = 16px ✗ (Bootstrap default)
// .p-3 = padding: var(--space-24) = 24px ✓ (con $spacers override)

// Angular component
.cmp-card {
  padding: var(--space-24);    // 24px
  margin-bottom: var(--space-32); // 32px
  gap: var(--space-16);        // 16px
}

.cmp-section {
  padding-block: var(--space-64); // 64px
}
```

Uso en código

```html
<!-- Padding + Margin con clases utilitarias -->
<div class="p-16 mb-24">
  contenido con padding 16px y margin-bottom 24px
</div>

<!-- Card con padding y gap -->
<div class="p-24 gap-16" style="display:flex">
  <img ...>
  <p class="mb-0">Texto de la card</p>
</div>

<!-- Sección con padding vertical grande -->
<section class="py-64 px-32">
  <h2 class="mb-16">Título</h2>
  <p class="mb-24">Descripción</p>
</section>
html
/* CSS custom properties — usar siempre var() */
.card {
  padding:       var(--space-24);  /* 24px */
  margin-bottom: var(--space-32);  /* 32px */
  gap:           var(--space-16);  /* 16px */
}

.section {
  padding-block: var(--space-64);  /* 64px */
}

.list-item {
  padding: var(--space-8) var(--space-16);  /* 8px 16px */
  gap:     var(--space-8);                  /* 8px */
}

/* Nunca: padding: 24px; ✗ */
/* Siempre: padding: var(--space-24); ✓ */
html
/* Stack: separación vertical automática entre hermanos */
.stack-8  > * + * { margin-top: var(--space-8);  }  /* 8px  */
.stack-16 > * + * { margin-top: var(--space-16); }  /* 16px */
.stack-24 > * + * { margin-top: var(--space-24); }  /* 24px */
.stack-32 > * + * { margin-top: var(--space-32); }  /* 32px */
.stack-48 > * + * { margin-top: var(--space-48); }  /* 48px */

/* Uso: */
<div class="stack-16">
  <div>Item 1</div>
  <div>Item 2</div>  <!-- margin-top: 16px automático -->
  <div>Item 3</div>
</div>
```

Accesibilidad
Reglas generales

- Mantener separación clara entre elementos interactivos.
- No compactar formularios extensos.
- No usar espaciado como único indicador de jerarquía.
- Respetar siempre múltiplos de 8px.

Elementos interactivos

- Altura mínima táctil: **44px **- Separación mínima entre botones: **8px – 16px**
- Evitar botones demasiado juntos sin separación clara.

Padding mínimo recomendado

- Componentes interactivos: mínimo **12px vertical **- Cards: mínimo **16px / 24px **- Secciones principales: **48px o superior**

Dark / High Contrast

- No reducir espaciado en modos alternativos.
- Mantener separación clara para evitar bloques densos.
- Priorizar aire visual en interfaces críticas.

> Fuente: `docs/transversales/fundamentos/spacing.html` · v2.4.0
