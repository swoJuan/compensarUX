# Accesibilidad



Objetivo del sistema: WCAG 2.2 AA, teclado, foco visible, móvil, zoom al 200 % y los modos claro, oscuro y alto contraste. Los criterios por componente son los de su página de documentación; esto los reúne. Guías transversales: [Modo oscuro](../patterns/dark-mode.md) y [Alto contraste](../patterns/high-contrast.md).



## Accordion

_Fuente: [components/transversales/accordion.md](../components/transversales/accordion.md)_

### Accesibilidad

- El trigger es un `button` con `aria-expanded`.
- El panel usa `role="region"` y referencia al trigger.
- Tab, Enter y Space deben funcionar nativamente.
- Focus visible en todos los modos de color.

### Checklist QA

- Trigger usa texto mínimo de 16 px y componente real `mp-accordion`.
- Chevron 24 px rota al abrir/cerrar.
- Hover y focus son evidentes en los estados interactivos.
- El panel actualiza `aria-expanded` y altura al interactuar.
- Light, Dark y High Contrast mantienen contraste correcto.

## Alertas

_Fuente: [components/transversales/alerts.md](../components/transversales/alerts.md)_

### Accesibilidad

- Contraste mínimo 4.5:1.
- No depender solo del color: incluir icono y texto.
- Usar `role="status"` para información y `role="alert"` para errores importantes.
- El cierre debe tener `aria-label` descriptivo.

## Chips / Tags / Badges

_Fuente: [components/transversales/badges.md](../components/transversales/badges.md)_

### Accesibilidad

- Los chips deben exponer estado con `aria-pressed` cuando sean seleccionables.
- Los badges de estado deben tener texto claro o `aria-label`.
- No comuniques estados únicamente con color.
- El área clicable mínima para chips es 44 px.

### Checklist QA

- Verificar Light, Dark y High Contrast.
- Confirmar que chips muestran hover, focus, selected y disabled.
- Validar textos cortos sin desbordes.
- Probar que HTML, CSS y Sass del visualizador se copian completos.

## Botón

_Fuente: [components/transversales/buttons.md](../components/transversales/buttons.md)_

### Accesibilidad

- Navegación por teclado con Tab; activación con Enter y Space.
- Focus visible en todos los estados.
- Contraste mínimo AA 4.5:1 para texto y controles.
- Botones solo icono requieren `aria-label` descriptivo.
- No depender solo del color para comunicar estados.

## Cards

_Fuente: [components/transversales/cards.md](../components/transversales/cards.md)_

### Accesibilidad

Contraste
Texto, borde y acciones deben mantener contraste AA; en alto contraste el contenedor usa borde blanco sólido.
Foco visible
Si la card es interactiva, debe poder enfocarse y mostrar un indicador visible.
Texto alternativo
Las imágenes informativas requieren `alt`; las decorativas deben usar alt vacío.
Acción clara
Evita múltiples acciones principales y no dependas solo del hover para revelar interacción.

## Dropdown / Select

_Fuente: [components/transversales/dropdown.md](../components/transversales/dropdown.md)_

### Accesibilidad

### Roles ARIA obligatorios

- Wrapper: `role="combobox"`, `aria-expanded`, `aria-haspopup="listbox"`, `aria-controls="[panel-id]"`
- Panel: `role="listbox"` (simple) o `role="listbox" aria-multiselectable="true"` (múltiple)
- Opción: `role="option"`, `aria-selected`
- Opción deshabilitada: `aria-disabled="true"`
- Campo requerido: `aria-required="true"`
- Estado de error: `aria-invalid="true"`, `aria-describedby`

### Interacción por teclado

- Tab — mueve el foco al trigger
- Enter / Space — abre el panel o selecciona la opción activa
- ↑ / ↓ — navega entre opciones (mueve `aria-activedescendant`)
- Escape — cierra el panel, devuelve el foco al trigger
- Home / End — primera / última opción

### Contraste mínimo

4.5:1 para texto de opción y label. El estado focus debe ser perceptible sin depender solo del color.

### Foco de la opción

La opción activa por teclado lleva un contorno interior de 2 px con `use/border/strong` (Light #666666 · Dark #E0E0E0 · Alto contraste #FFFFFF; en alto contraste el fondo de la opción es negro). El trigger conserva su propio foco.

## Input / Campo de texto

_Fuente: [components/transversales/inputs.md](../components/transversales/inputs.md)_

### Accesibilidad

- Cada campo tiene `<label for="…">` explícito. Nunca depender solo del placeholder.
- `aria-invalid="true"` + `aria-describedby` conectan el mensaje de error al campo para lectores de pantalla.
- Campos requeridos: asterisco con `aria-hidden="true"` más `required` y `aria-required="true"`.
- Íconos decorativos con `aria-hidden="true"`. Íconos accionables como `<button>` con `aria-label`.
- Focus visible en todos los estados. Contraste mínimo AA 4.5:1.
- Área táctil mínima 44 px. El campo tiene 56 px de altura.
- No depender solo del color para comunicar error o success.

## Loading

_Fuente: [components/transversales/loading.md](../components/transversales/loading.md)_

### Accesibilidad

- No dependas solo de la animación: conserva un texto visible.
- Usa `role="status"`, `aria-live="polite"` y `aria-busy="true"`.
- Mantén contraste adecuado en Light, Dark y High Contrast.
- Respeta usuarios con reducción de movimiento.

### Checklist QA

- Spinner mide 48 px por defecto y conserva proporciones en small/large.
- Texto visible usa 16 px y no se oculta en mobile.
- Light, Dark y High Contrast mantienen contraste correcto.
- El HTML expone `role="status"`, `aria-live` y `aria-busy`.
- Las descargas de CSS/Sass incluyen componente completo y animación separada.

## Modal

_Fuente: [components/transversales/modals.md](../components/transversales/modals.md)_

### Accesibilidad

- Usar `role="dialog"` y `aria-modal="true"`.
- Conectar título con `aria-labelledby`.
- Conectar mensaje con `aria-describedby`.
- Devolver el foco al botón que abrió el modal.

- Focus visible en cierre y acciones.
- Contraste mínimo AA.
- No depender solo del color para comunicar tipo.
- No abrir múltiples modales simultáneamente.

## Checkbox / Radio / Switch

_Fuente: [components/transversales/selection-controls.md](../components/transversales/selection-controls.md)_

### Accesibilidad

- Área mínima: 44 x 44 px (Checkbox y Radio). Switch: área interactiva de 52 x 44 px, con track de 52 x 32 px y knob de 28 x 28 px, centrados verticalmente.
- Label asociado al control mediante estructura de label/input.
- Focus visible obligatorio: contorno de 3 px con `use/border/strong` en Checkbox, Radio y Switch. El Switch deshabilitado no recibe foco.
- No depender solo del color para error o selección.
- Grupos radio deben usar `name` compartido.

## Tables

_Fuente: [components/transversales/tables.md](../components/transversales/tables.md)_

### Accesibilidad

Contraste
Filas, selección y hover deben mantener contraste suficiente.
Encabezados
Usa `th` y `scope` cuando aplique.
Teclado
Acciones y selección deben ser navegables por teclado.
No solo color
Estados como selección o error deben tener apoyo textual o estructural.

## Tabs

_Fuente: [components/transversales/tabs.md](../components/transversales/tabs.md)_

### Accesibilidad

Foco visible
El foco debe ser visible en cada tab, activo o inactivo. El componente dibuja un contorno exterior de 3 px con `use/border/strong` alrededor de la superficie visual de 35 px; si lo reemplazas, no lo elimines sin una alternativa visible.
Teclado
Flechas laterales cambian el foco entre tabs; `Tab` avanza al panel activo.
ARIA
Usa `tablist`, `tab`, `tabpanel`, `aria-controls` y `aria-labelledby`.
No solo color
El activo debe diferenciarse por color, forma y peso visual; no dependas solo del color.

## Toast

_Fuente: [components/transversales/toasts.md](../components/transversales/toasts.md)_

### Accesibilidad

- Usar región `aria-live="polite"` para feedback no crítico.
- No desaparecer demasiado rápido: 5 segundos como regla base.
- El botón cerrar requiere `aria-label`.
- No depender solo del color: incluir icono y texto.

## Accordion

_Fuente: [components/web/accordion.md](../components/web/accordion.md)_

### Accesibilidad

- El trigger es un `button` con `aria-expanded`.
- El panel usa `role="region"` y referencia al trigger.
- Tab, Enter y Space deben funcionar nativamente.
- Focus visible en todos los modos de color.

### Checklist QA

- Trigger usa texto mínimo de 16 px y componente real `mp-accordion`.
- Chevron 24 px rota al abrir/cerrar.
- Hover y focus son evidentes en los estados interactivos.
- El panel actualiza `aria-expanded` y altura al interactuar.
- Light, Dark y High Contrast mantienen contraste correcto.

## Chips / Tags / Badges

_Fuente: [components/web/badges.md](../components/web/badges.md)_

### Accesibilidad

- Los chips deben exponer estado con `aria-pressed` cuando sean seleccionables.
- Los badges de estado deben tener texto claro o `aria-label`.
- No comuniques estados únicamente con color.
- El área clicable mínima para chips es 44 px.

### Checklist QA

- Verificar Light, Dark y High Contrast.
- Confirmar que chips muestran hover, focus, selected y disabled.
- Validar textos cortos sin desbordes.
- Probar que HTML, CSS y Sass del visualizador se copian completos.

## Breadcrumb

_Fuente: [components/web/breadcrumb.md](../components/web/breadcrumb.md)_

### Accesibilidad

- Usa `nav` con `aria-label="Breadcrumb"`.
- Los enlaces deben ser identificables y navegables con teclado.
- Los separadores son decorativos y llevan `aria-hidden="true"`.
- Debe mantener contraste en Light, Dark y High Contrast.

### Checklist QA

- Home mide 20 px y separadores 16 px.
- Texto de breadcrumb usa 16 px y el nivel actual va en bold.
- Focus visible en enlaces anteriores.
- El último nivel no es enlace y declara `aria-current="page"`.
- Light, Dark y High Contrast mantienen contraste correcto.

## Empty State

_Fuente: [components/web/empty-state.md](../components/web/empty-state.md)_

### Accesibilidad

Ícono decorativo
El ícono del contenedor debe marcarse con `aria-hidden="true"`. El significado se transmite por el título y la descripción.
Jerarquía semántica
Usa `<h4 class="mp-h4">` como elemento del título. Ajusta el nivel (`h2`, `h3`…) si el contexto lo requiere para mantener la jerarquía correcta de la página.
Acción accesible
Los botones de acción deben tener texto descriptivo. Evita etiquetas genéricas como "Aquí" o "Click". Prefiere "Crear nuevo documento" sobre "Crear".
Contraste
El título y descripción usan tokens de texto primario y secundario respectivamente, garantizando contraste 4.5:1 en todos los modos del sistema.

## Navigation patterns

_Fuente: [components/web/header.md](../components/web/header.md)_

### Accesibilidad

- Focus visible obligatorio en todos los elementos interactivos
- Navegación por teclado completa (Tab, Enter, Escape)
- Estado activo con `aria-current="page"`
- No depender solo del color para comunicar estado
- Áreas clicables mínimo 44×44 px
- En móvil, evitar patrones dependientes de hover
- Usar `aria-expanded` en submenús y drawers
- Cerrar drawer con Escape y devolver foco al botón disparador

## Loading

_Fuente: [components/web/loading.md](../components/web/loading.md)_

### Accesibilidad

- No dependas solo de la animación: conserva un texto visible.
- Usa `role="status"`, `aria-live="polite"` y `aria-busy="true"`.
- Mantén contraste adecuado en Light, Dark y High Contrast.
- Respeta usuarios con reducción de movimiento.

### Checklist QA

- Spinner mide 48 px por defecto y conserva proporciones en small/large.
- Texto visible usa 16 px y no se oculta en mobile.
- Light, Dark y High Contrast mantienen contraste correcto.
- El HTML expone `role="status"`, `aria-live` y `aria-busy`.
- Las descargas de CSS/Sass incluyen componente completo y animación separada.

## Sidebar / Overlay

_Fuente: [components/web/sidebar.md](../components/web/sidebar.md)_

### Accesibilidad

- `role="dialog"` + `aria-modal="true"` en `.mp-sidebar`.
- `aria-label` o `aria-labelledby` apuntando al título del panel.
- Al abrir, mover el foco al primer elemento interactivo (botón cerrar o primer campo).
- Al cerrar, restaurar el foco al elemento que lo abrió.

- Implementar **focus trap**: Tab y Shift+Tab deben circular dentro del panel.
- Escape cierra el panel siempre.
- El backdrop tiene `aria-hidden="true"` — no es interactivo para lectores de pantalla.
- Contraste mínimo 4.5:1 en todo texto sobre el fondo del panel.

### Checklist QA

- Panel entra con animación suave desde la derecha (desktop) o desde abajo (mobile).
- Backdrop oscurece el fondo y cierra el panel al hacer clic.
- Escape cierra el panel desde cualquier elemento interno.
- El body del panel scrollea independientemente de la página.
- El footer permanece visible (sticky) al hacer scroll dentro del body.
- En mobile, el panel ocupa máximo 90dvh y tiene border-radius arriba.
- Focus ring visible al navegar con teclado.
- Se ve correctamente en Light, Dark y High Contrast.

## Stepper

_Fuente: [components/web/stepper.md](../components/web/stepper.md)_

### Accesibilidad

- `role="progressbar"` en `.mp-stepper__track`.
- `aria-valuenow` = paso actual, `aria-valuemin="1"`, `aria-valuemax` = total.
- `aria-label` descriptivo: *"Paso 2 de 3"*.

- El stepper es solo informativo — no es interactivo ni recibe foco.
- El contraste de las barras cumple WCAG AA en todos los temas.
- En High Contrast, el alto de barra sube a 3 px para mayor visibilidad.

### Checklist QA

- Las barras completadas (`.is-done`) muestran color primario.
- La barra activa (`.is-current`) muestra color primario.
- Las barras pendientes muestran color de borde sutil.
- El head muestra el número y título del paso actual correctamente.
- `aria-valuenow` se actualiza al navegar entre pasos.
- La variante compact oculta el head completamente.
- Se ve correctamente en Light, Dark y High Contrast.
- Las barras son equitativas en ancho (flex: 1 cada una).

## Bottom Sheet

_Fuente: [components/app/bottom-sheet.md](../components/app/bottom-sheet.md)_

### Accesibilidad

### Roles y atributos ARIA

- El panel raíz lleva `role="dialog"`, `aria-modal="true"` y `aria-label` o `aria-labelledby`.
- El botón handle tiene `aria-label="Arrastrar o cerrar"`.
- El campo de búsqueda usa `<label>` o `aria-label` explícito.
- Cada chip de filtro usa `aria-pressed` para reflejar el estado seleccionado.
- Los grupos de filtros usan `<section>` con `aria-labelledby` apuntando al título del grupo.

### Checklist QA

- Handle visible en todos los modos (Light, Dark, Alto contraste).
- Panel se cierra al tocar/pulsar el handle o al presionar Esc.
- Foco queda atrapado dentro del sheet mientras está abierto.
- Ítems de lista con min-height 56 px (área táctil mínima).
- Chips de filtro responden correctamente a tap/clic y actualizan `aria-pressed`.
- Botón "Aplicar" aplica los filtros seleccionados y cierra el panel.
- Botón "Limpiar" deselecciona todos los chips del panel.
- Contraste de texto ≥ 4.5:1 en todos los modos.
- Chips de filtro activos (#775ebb/#fff): contraste verificado ≥ 4.5:1.

## Dropdown / Select App

_Fuente: [components/app/dropdown.md](../components/app/dropdown.md)_

### Accesibilidad

### Roles ARIA obligatorios

- Wrapper: `role="combobox"`, `aria-expanded`, `aria-haspopup="listbox"`, `aria-controls="[panel-id]"`
- Panel: `role="listbox"` (simple) o `role="listbox" aria-multiselectable="true"` (múltiple)
- Opción: `role="option"`, `aria-selected`
- Opción deshabilitada: `aria-disabled="true"`
- Campo requerido: `aria-required="true"`
- Estado de error: `aria-invalid="true"`, `aria-describedby`

### Interacción por teclado

- Tab — mueve el foco al trigger
- Enter / Space — abre el panel o selecciona la opción activa
- ↑ / ↓ — navega entre opciones (mueve `aria-activedescendant`)
- Escape — cierra el panel, devuelve el foco al trigger
- Home / End — primera / última opción

### Contraste mínimo

4.5:1 para texto de opción y label. El estado focus debe ser perceptible sin depender solo del color.

## Pendiente de documentación

Sin sección de accesibilidad en su página de origen: Avatar / User chip, Paginación, Cómo conectarlo, Sistema de iconos, Header App, Tabs App.
