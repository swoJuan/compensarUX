# Colores

Fuente: `tokens/compensar.tokens.json` del sistema de diseño v2.4.0. Cada color tiene valor por modo (claro, oscuro y alto contraste). Usa siempre la variable CSS, nunca el valor.

## base/brand

| Token | Variable CSS | Claro | Oscuro | Alto contraste |
| --- | --- | --- | --- | --- |
| `base/brand/40` | `--base-brand-40` | #ffe6d6 | #ffe6d6 | #ffe6d6 |
| `base/brand/50` | `--base-brand-50` | #ffc299 | #ffc299 | #ffc299 |
| `base/brand/60` | `--base-brand-60` | #ffa366 | #ffa366 | #ffa366 |
| `base/brand/70` | `--base-brand-70` | #ff8533 | #ff8533 | #ff8533 |
| `base/brand/80` | `--base-brand-80` | #ff6600 | #ff9d5c | #ffff00 |
| `base/brand/90` | `--base-brand-90` | #e63f0c | #e65c00 | #e6e600 |
| `base/brand/100` | `--base-brand-100` | #cc5200 | #cc5200 | #cccc00 |
| `base/brand/yellow` | `--base-brand-yellow` | #ff980d | #ffe6d6 | #ffe6d6 |

## base/blue

| Token | Variable CSS | Claro | Oscuro | Alto contraste |
| --- | --- | --- | --- | --- |
| `base/blue/30` | `--base-blue-30` | #e6f1fb | #edf2fa | #edf2fa |
| `base/blue/40` | `--base-blue-40` | #d4e2fa | #d4e2fa | #d4e2fa |
| `base/blue/50` | `--base-blue-50` | #9fbef5 | #9fbef5 | #9fbef5 |
| `base/blue/60` | `--base-blue-60` | #5c91f2 | #5c91f2 | #5c91f2 |
| `base/blue/70` | `--base-blue-70` | #296ff0 | #296ff0 | #296ff0 |
| `base/blue/80` | `--base-blue-80` | #1f53b5 | #1f53b5 | #1f53b5 |
| `base/blue/90` | `--base-blue-90` | #18428f | #18428f | #18428f |
| `base/blue/100` | `--base-blue-100` | #2d4a67 | #102c5e | #102c5e |

## base/cyan blue

| Token | Variable CSS | Claro | Oscuro | Alto contraste |
| --- | --- | --- | --- | --- |
| `base/cyan blue/10` | `--base-cyan-blue-10` | #eef5fc | #eef5fc | #eef5fc |
| `base/cyan blue/20` | `--base-cyan-blue-20` | #d6e6f7 | #d6e6f7 | #d6e6f7 |
| `base/cyan blue/30` | `--base-cyan-blue-30` | #b2d0ee | #b2d0ee | #b2d0ee |
| `base/cyan blue/40` | `--base-cyan-blue-40` | #8cb8e0 | #8cb8e0 | #8cb8e0 |
| `base/cyan blue/50` | `--base-cyan-blue-50` | #6c9fd0 | #6c9fd0 | #6c9fd0 |
| `base/cyan blue/60` | `--base-cyan-blue-60` | #5286bc | #5286bc | #5286bc |
| `base/cyan blue/70` | `--base-cyan-blue-70` | #4a74a5 | #4a74a5 | #4a74a5 |
| `base/cyan blue/80` | `--base-cyan-blue-80` | #3c628c | #3c628c | #3c628c |
| `base/cyan blue/90` | `--base-cyan-blue-90` | #2d4f73 | #2d4f73 | #2d4f73 |
| `base/cyan blue/100` | `--base-cyan-blue-100` | #1f3d5a | #1f3d5a | #1f3d5a |

## base/green-1

| Token | Variable CSS | Claro | Oscuro | Alto contraste |
| --- | --- | --- | --- | --- |
| `base/green-1/30` | `--base-green-1-30` | #f7faf8 | #f7faf8 | #f7faf8 |
| `base/green-1/40` | `--base-green-1-40` | #e6f7e8 | #e6f7e8 | #cef0db |
| `base/green-1/50` | `--base-green-1-50` | #9fe0b8 | #9fe0b8 | #9fe0b8 |
| `base/green-1/60` | `--base-green-1-60` | #44bd75 | #44bd75 | #44bd75 |
| `base/green-1/70` | `--base-green-1-70` | #22a152 | #22a152 | #22a152 |
| `base/green-1/80` | `--base-green-1-80` | #0b853d | #0b853d | #0b853d |
| `base/green-1/90` | `--base-green-1-90` | #166936 | #166936 | #166936 |
| `base/green-1/100` | `--base-green-1-100` | #0d3d1f | #0d3d1f | #0d3d1f |

## base/green-2

| Token | Variable CSS | Claro | Oscuro | Alto contraste |
| --- | --- | --- | --- | --- |
| `base/green-2/10` | `--base-green-2-10` | #ecf7c9 | #ecf7c9 | #ecf7c9 |
| `base/green-2/20` | `--base-green-2-20` | #d8ee9c | #d8ee9c | #d8ee9c |
| `base/green-2/30` | `--base-green-2-30` | #c5e270 | #c5e270 | #c5e270 |
| `base/green-2/40` | `--base-green-2-40` | #b1d645 | #b1d645 | #b1d645 |
| `base/green-2/50` | `--base-green-2-50` | #9dc71e | #9dc71e | #9dc71e |
| `base/green-2/60` | `--base-green-2-60` | #95bf1b | #95bf1b | #95bf1b |
| `base/green-2/70` | `--base-green-2-70` | #84ad16 | #84ad16 | #84ad16 |
| `base/green-2/80` | `--base-green-2-80` | #6a8e11 | #6a8e11 | #6a8e11 |
| `base/green-2/90` | `--base-green-2-90` | #516d0d | #516d0d | #516d0d |
| `base/green-2/100` | `--base-green-2-100` | #3f540a | #3f540a | #3f540a |

## base/neutral

| Token | Variable CSS | Claro | Oscuro | Alto contraste |
| --- | --- | --- | --- | --- |
| `base/neutral/10` | `--base-neutral-10` | #f5f5f5 | #f5f5f5 | #f5f5f5 |
| `base/neutral/20` | `--base-neutral-20` | #e0e0e0 | #e0e0e0 | #e0e0e0 |
| `base/neutral/30` | `--base-neutral-30` | #cccccc | #cccccc | #cccccc |
| `base/neutral/40` | `--base-neutral-40` | #b8b8b8 | #b8b8b8 | #b8b8b8 |
| `base/neutral/50` | `--base-neutral-50` | #a4a4a4 | #a4a4a4 | #a4a4a4 |
| `base/neutral/60` | `--base-neutral-60` | #7f7f7f | #7f7f7f | #7f7f7f |
| `base/neutral/70` | `--base-neutral-70` | #666666 | #666666 | #666666 |
| `base/neutral/80` | `--base-neutral-80` | #333333 | #333333 | #333333 |
| `base/neutral/90` | `--base-neutral-90` | #292929 | #292929 | #292929 |
| `base/neutral/100 (Negro)` | `--base-neutral-100-negro` | #111111 | #111111 | #111111 |
| `base/neutral/white` | `--base-neutral-white` | #ffffff | #ffffff | #ffffff |
| `base/neutral/black` | `--base-neutral-black` | #000000 | #000000 | #000000 |

## base/red

| Token | Variable CSS | Claro | Oscuro | Alto contraste |
| --- | --- | --- | --- | --- |
| `base/red/30` | `--base-red-30` | #f7eeed | #f7eeed | #f7eeed |
| `base/red/40` | `--base-red-40` | #f2d8d5 | #f2d8d5 | #f2d8d5 |
| `base/red/50` | `--base-red-50` | #ebada7 | #ebada7 | #ebada7 |
| `base/red/60` | `--base-red-60` | #db7165 | #db7165 | #db7165 |
| `base/red/70` | `--base-red-70` | #d14434 | #d14434 | #d14434 |
| `base/red/75` | `--base-red-75` | #bb4945 | #bb4945 | #bb4945 |
| `base/red/80` | `--base-red-80` | #9e3328 | #9e3328 | #9e3328 |
| `base/red/90` | `--base-red-90` | #7d291f | #7d291f | #7d291f |
| `base/red/100` | `--base-red-100` | #521a14 | #521a14 | #521a14 |

## base/orange

| Token | Variable CSS | Claro | Oscuro | Alto contraste |
| --- | --- | --- | --- | --- |
| `base/orange/10` | `--base-orange-10` | #fff2e3 | #fff2e3 | #fff2e3 |
| `base/orange/20` | `--base-orange-20` | #ffe5cc | #ffe5cc | #ffe5cc |
| `base/orange/40` | `--base-orange-40` | #ffb380 | #ffb380 | #ffb380 |
| `base/orange/60` | `--base-orange-60` | #cc7a33 | #cc7a33 | #cc7a33 |
| `base/orange/100` | `--base-orange-100` | #6b4400 | #cc7a33 | #cc7a33 |

## base/yellow

| Token | Variable CSS | Claro | Oscuro | Alto contraste |
| --- | --- | --- | --- | --- |
| `base/yellow/30` | `--base-yellow-30` | #fff9ef | #fff9ef | #fff9ef |
| `base/yellow/40` | `--base-yellow-40` | #fff2d9 | #fff2d9 | #fff2d9 |
| `base/yellow/50` | `--base-yellow-50` | #fce1ac | #fce1ac | #fce1ac |
| `base/yellow/60` | `--base-yellow-60` | #fcce72 | #fcce72 | #fcce72 |
| `base/yellow/70` | `--base-yellow-70` | #ffc154 | #fcbf44 | #fcbf44 |
| `base/yellow/80` | `--base-yellow-80` | #bf9034 | #bf9034 | #bf9034 |
| `base/yellow/90` | `--base-yellow-90` | #967229 | #967229 | #967229 |
| `base/yellow/100` | `--base-yellow-100` | #634a1a | #634a1a | #634a1a |

## product/medicina

| Token | Variable CSS | Claro | Oscuro | Alto contraste |
| --- | --- | --- | --- | --- |
| `product/medicina/Cyan` | `--product-medicina-cyan` | #00e2db | #00e2db | #00e2db |
| `product/medicina/Purple` | `--product-medicina-purple` | #8268cb | #8268cb | #8268cb |
| `product/medicina/Gray` | `--product-medicina-gray` | #b3acab | #b3acab | #b3acab |

## product/accent

| Token | Variable CSS | Claro | Oscuro | Alto contraste |
| --- | --- | --- | --- | --- |
| `product/accent/30` | `--product-accent-30` | #f2fcff | #f2fcff | #f2fcff |
| `product/accent/40` | `--product-accent-40` | #e1f7fe | #e1f7fe | #e1f7fe |
| `product/accent/50` | `--product-accent-50` | #b3d7e0 | #b3d7e0 | #b3d7e0 |
| `product/accent/60` | `--product-accent-60` | #8fc5d0 | #8fc5d0 | #8fc5d0 |
| `product/accent/70` | `--product-accent-70` | #6bb4c0 | #6bb4c0 | #6bb4c0 |
| `product/accent/80` | `--product-accent-80` | #47a4af | #47a4af | #47a4af |
| `product/accent/90` | `--product-accent-90` | #24939d | #24939d | #24939d |
| `product/accent/100` | `--product-accent-100` | #03838a | #03838a | #03838a |

## product/gray

| Token | Variable CSS | Claro | Oscuro | Alto contraste |
| --- | --- | --- | --- | --- |
| `product/gray/5` | `--product-gray-5` | #f8f7f7 | #f8f7f7 | #f8f7f7 |
| `product/gray/10` | `--product-gray-10` | #eceaea | #eceaea | #eceaea |
| `product/gray/20` | `--product-gray-20` | #d9d5d5 | #d9d5d5 | #d9d5d5 |
| `product/gray/30` | `--product-gray-30` | #c6c1c0 | #c6c1c0 | #c6c1c0 |
| `product/gray/40` | `--product-gray-40` | #b3acab | #b3acab | #b3acab |
| `product/gray/50` | `--product-gray-50` | #a09796 | #a09796 | #a09796 |
| `product/gray/60` | `--product-gray-60` | #8c8280 | #8c8280 | #8c8280 |
| `product/gray/70` | `--product-gray-70` | #786e6c | #786e6c | #786e6c |
| `product/gray/80` | `--product-gray-80` | #635a59 | #635a59 | #635a59 |
| `product/gray/90` | `--product-gray-90` | #4d4746 | #4d4746 | #4d4746 |
| `product/gray/100` | `--product-gray-100` | #383333 | #383333 | #383333 |

## product/violet

| Token | Variable CSS | Claro | Oscuro | Alto contraste |
| --- | --- | --- | --- | --- |
| `product/violet/5` | `--product-violet-5` | #efecf9 | #efecf9 | #efecf9 |
| `product/violet/10` | `--product-violet-10` | #e0d9f3 | #e0d9f3 | #e0d9f3 |
| `product/violet/20` | `--product-violet-20` | #c1b3e7 | #c1b3e7 | #c1b3e7 |
| `product/violet/30` | `--product-violet-30` | #a28dda | #a28dda | #a28dda |
| `product/violet/40` | `--product-violet-40` | #8367ce | #8367ce | #8367ce |
| `product/violet/50` | `--product-violet-50` | #6d4cc5 | #6d4cc5 | #6d4cc5 |
| `product/violet/60` | `--product-violet-60` | #5b3ab4 | #5b3ab4 | #5b3ab4 |
| `product/violet/70` | `--product-violet-70` | #4e3199 | #4e3199 | #4e3199 |
| `product/violet/80` | `--product-violet-80` | #40297e | #40297e | #40297e |
| `product/violet/90` | `--product-violet-90` | #322064 | #322064 | #322064 |
| `product/violet/100` | `--product-violet-100` | #251749 | #251749 | #251749 |

## product/teal

| Token | Variable CSS | Claro | Oscuro | Alto contraste |
| --- | --- | --- | --- | --- |
| `product/teal/5` | `--product-teal-5` | #ebfffe | #ebfffe | #ebfffe |
| `product/teal/10` | `--product-teal-10` | #d0fffd | #d0fffd | #d0fffd |
| `product/teal/20` | `--product-teal-20` | #a0fffc | #a0fffc | #a0fffc |
| `product/teal/30` | `--product-teal-30` | #71fffa | #71fffa | #71fffa |
| `product/teal/40` | `--product-teal-40` | #41fff8 | #41fff8 | #41fff8 |
| `product/teal/50` | `--product-teal-50` | #12fff7 | #12fff7 | #12fff7 |
| `product/teal/60` | `--product-teal-60` | #00e1d9 | #00e1d9 | #00e1d9 |
| `product/teal/70` | `--product-teal-70` | #00c0b9 | #00c0b9 | #00c0b9 |
| `product/teal/80` | `--product-teal-80` | #009f99 | #009f99 | #009f99 |
| `product/teal/90` | `--product-teal-90` | #007d79 | #007d79 | #007d79 |
| `product/teal/100` | `--product-teal-100` | #005c59 | #005c59 | #005c59 |

## use/background

| Token | Variable CSS | Claro | Oscuro | Alto contraste |
| --- | --- | --- | --- | --- |
| `use/background/page` | `--use-background-page` | var(--base-neutral-white) | var(--base-neutral-100-negro) | var(--base-neutral-black) |

## use/primary

| Token | Variable CSS | Claro | Oscuro | Alto contraste |
| --- | --- | --- | --- | --- |
| `use/primary/default` | `--use-primary-default` | var(--base-brand-80) | var(--base-brand-80) | var(--base-brand-80) |
| `use/primary/hover` | `--use-primary-hover` | var(--base-brand-90) | var(--base-brand-90) | var(--base-brand-90) |
| `use/primary/active` | `--use-primary-active` | var(--base-brand-100) | var(--base-brand-100) | var(--base-brand-100) |
| `use/primary/default dark` | `--use-primary-default-dark` | #ff9d5c | var(--base-brand-80) | var(--base-brand-80) |

## use/border

| Token | Variable CSS | Claro | Oscuro | Alto contraste |
| --- | --- | --- | --- | --- |
| `use/border/default` | `--use-border-default` | var(--base-neutral-30) | var(--base-neutral-80) | var(--base-neutral-white) |
| `use/border/strong` | `--use-border-strong` | var(--base-neutral-70) | var(--base-neutral-20) | var(--base-neutral-white) |
| `use/border/subtle` | `--use-border-subtle` | var(--base-neutral-20) | var(--base-neutral-60) | var(--base-neutral-white) |
| `use/border/hover` | `--use-border-hover` | var(--use-primary-hover) | var(--use-primary-active) | var(--base-neutral-white) |
| `use/border/violet-dark` | `--use-border-violet-dark` | var(--product-violet-80) | var(--product-violet-10) | var(--base-neutral-white) |
| `use/border/violet` | `--use-border-violet` | var(--product-violet-10) | var(--product-violet-90) | var(--base-neutral-white) |

## use/focus

| Token | Variable CSS | Claro | Oscuro | Alto contraste |
| --- | --- | --- | --- | --- |
| `use/focus/border` | `--use-focus-border` | var(--base-brand-40) | var(--base-brand-80) | var(--base-neutral-white) |
| `use/focus/outline` | `--use-focus-outline` | var(--base-brand-80) | var(--base-brand-80) | var(--base-neutral-white) |
| `use/focus/background` | `--use-focus-background` | var(--base-brand-40) | var(--base-brand-40) | var(--base-brand-40) |

## use/text

| Token | Variable CSS | Claro | Oscuro | Alto contraste |
| --- | --- | --- | --- | --- |
| `use/text/primary` | `--use-text-primary` | var(--base-neutral-100-negro) | var(--base-neutral-10) | var(--base-neutral-white) |
| `use/text/secondary` | `--use-text-secondary` | var(--base-neutral-80) | var(--base-neutral-20) | var(--base-neutral-10) |
| `use/text/tertiary` | `--use-text-tertiary` | var(--base-neutral-70) | var(--base-neutral-50) | var(--base-neutral-20) |
| `use/text/inverse` | `--use-text-inverse` | var(--base-neutral-10) | var(--base-neutral-100-negro) | var(--base-neutral-black) |
| `use/text/link` | `--use-text-link` | var(--base-brand-80) | var(--base-brand-80) | var(--base-brand-80) |
| `use/text/theme/violet` | `--use-text-theme-violet` | var(--product-violet-70) | var(--product-violet-30) | var(--base-neutral-white) |
| `use/text/theme/yellow` | `--use-text-theme-yellow` | var(--base-yellow-70) | var(--base-yellow-30) | var(--base-neutral-white) |
| `use/text/theme/orange` | `--use-text-theme-orange` | var(--base-orange-60) | var(--base-orange-10) | var(--base-neutral-white) |
| `use/text/theme/blue` | `--use-text-theme-blue` | var(--base-blue-80) | var(--base-blue-30) | var(--base-neutral-white) |
| `use/text/theme/red` | `--use-text-theme-red` | var(--base-red-75) | var(--base-red-30) | var(--base-neutral-white) |
| `use/text/theme/green-1` | `--use-text-theme-green-1` | var(--base-green-1-80) | var(--base-green-1-30) | var(--base-neutral-white) |
| `use/text/theme/green-2` | `--use-text-theme-green-2` | var(--base-green-2-80) | var(--base-green-2-10) | var(--base-neutral-white) |
| `use/text/badge/orange` | `--use-text-badge-orange` | var(--use-text-secondary) | var(--use-text-inverse) | var(--use-text-secondary) |
| `use/text/badge/green-3` | `--use-text-badge-green-3` | var(--base-green-2-90) | var(--use-text-theme-green-2) | var(--use-text-theme-green-2) |
| `use/text/badge/error` | `--use-text-badge-error` | var(--base-red-80) | var(--use-text-theme-red) | var(--use-text-theme-red) |
| `use/text/on-dark/primary` | `--use-text-on-dark-primary` | var(--base-neutral-white) | var(--base-neutral-white) | var(--base-neutral-white) |
| `use/text/on-dark/secondary` | `--use-text-on-dark-secondary` | var(--base-neutral-10) | var(--base-neutral-20) | var(--base-neutral-50) |

## use/tables

| Token | Variable CSS | Claro | Oscuro | Alto contraste |
| --- | --- | --- | --- | --- |
| `use/tables/Head` | `--use-tables-head` | #a5d7d5 | #a5d7d5 | #a5d7d5 |
| `use/tables/Filter` | `--use-tables-filter` | #e3e7ed | #e3e7ed | #e3e7ed |
| `use/tables/Stripes` | `--use-tables-stripes` | #f5f5f7 | #f5f5f7 | #f5f5f7 |

## use/state

| Token | Variable CSS | Claro | Oscuro | Alto contraste |
| --- | --- | --- | --- | --- |
| `use/state/success/bg` | `--use-state-success-bg` | var(--base-green-1-40) | var(--base-green-1-90) | var(--base-green-1-100) |
| `use/state/success/text` | `--use-state-success-text` | var(--base-green-1-100) | var(--base-neutral-10) | var(--base-neutral-white) |
| `use/state/success/border` | `--use-state-success-border` | var(--base-green-1-60) | var(--base-green-1-70) | var(--base-green-1-70) |
| `use/state/success/icon` | `--use-state-success-icon` | var(--base-green-1-80) | var(--base-green-1-40) | var(--base-green-1-40) |
| `use/state/error/bg` | `--use-state-error-bg` | var(--base-red-30) | var(--base-red-90) | var(--base-red-100) |
| `use/state/error/text` | `--use-state-error-text` | var(--base-red-100) | var(--base-neutral-10) | var(--base-neutral-white) |
| `use/state/error/text-error-field` | `--use-state-error-text-error-field` | var(--base-red-80) | var(--base-neutral-10) | var(--base-neutral-white) |
| `use/state/error/icon` | `--use-state-error-icon` | var(--base-red-70) | var(--base-neutral-10) | var(--base-neutral-white) |
| `use/state/error/border` | `--use-state-error-border` | var(--base-red-60) | var(--base-red-70) | var(--base-red-70) |
| `use/state/error/mandatory` | `--use-state-error-mandatory` | var(--base-red-75) | var(--base-red-70) | var(--base-red-70) |
| `use/state/warning/bg` | `--use-state-warning-bg` | var(--base-yellow-40) | var(--base-yellow-100) | var(--base-yellow-100) |
| `use/state/warning/text` | `--use-state-warning-text` | var(--use-text-primary) | var(--base-neutral-10) | var(--base-neutral-white) |
| `use/state/warning/border` | `--use-state-warning-border` | var(--base-yellow-60) | var(--base-yellow-70) | var(--base-yellow-70) |
| `use/state/warning/icon bg` | `--use-state-warning-icon-bg` | var(--base-yellow-90) | var(--base-yellow-70) | var(--base-yellow-70) |
| `use/state/warning/icon color` | `--use-state-warning-icon-color` | var(--use-text-primary) | var(--use-text-inverse) | var(--use-text-inverse) |
| `use/state/info/bg` | `--use-state-info-bg` | var(--base-blue-30) | var(--base-blue-90) | var(--base-blue-100) |
| `use/state/info/text` | `--use-state-info-text` | var(--base-blue-100) | var(--base-neutral-10) | var(--base-neutral-white) |
| `use/state/info/border` | `--use-state-info-border` | var(--base-cyan-blue-50) | var(--base-blue-70) | var(--base-blue-70) |
| `use/state/info/icon` | `--use-state-info-icon` | var(--base-cyan-blue-60) | var(--base-blue-70) | var(--base-blue-70) |

## use/overlay

| Token | Variable CSS | Claro | Oscuro | Alto contraste |
| --- | --- | --- | --- | --- |
| `use/overlay/subtle` | `--use-overlay-subtle` | #000000 | #000000 | #000000 |
| `use/overlay/strong 2` | `--use-overlay-strong-2` | #000000 | #000000 | #000000 |
| `use/overlay/strong 3` | `--use-overlay-strong-3` | #000000 | #000000 | #000000 |

## use/surface

| Token | Variable CSS | Claro | Oscuro | Alto contraste |
| --- | --- | --- | --- | --- |
| `use/surface/surface` | `--use-surface-surface` | var(--base-neutral-10) | var(--base-neutral-70) | var(--base-neutral-black) |
| `use/surface/subtle` | `--use-surface-subtle` | var(--product-gray-20) | var(--product-gray-80) | var(--base-neutral-black) |
| `use/surface/orange` | `--use-surface-orange` | var(--base-orange-10) | var(--base-orange-60) | var(--base-neutral-black) |
| `use/surface/cyan blue` | `--use-surface-cyan-blue` | var(--base-cyan-blue-10) | var(--base-cyan-blue-80) | var(--base-neutral-black) |
| `use/surface/violet` | `--use-surface-violet` | var(--product-violet-5) | var(--product-violet-80) | var(--base-neutral-black) |
| `use/surface/white` | `--use-surface-white` | var(--base-neutral-white) | var(--base-neutral-90) | var(--base-neutral-black) |
| `use/surface/green` | `--use-surface-green` | var(--base-green-1-30) | var(--base-green-1-90) | var(--base-neutral-black) |
| `use/surface/green-2` | `--use-surface-green-2` | var(--base-green-2-10) | var(--base-green-1-90) | var(--base-neutral-black) |
| `use/surface/theme/blue-dark/30` | `--use-surface-theme-blue-dark-30` | var(--base-blue-30) | var(--base-blue-80) | var(--base-neutral-black) |
| `use/surface/theme/blue-dark/40` | `--use-surface-theme-blue-dark-40` | var(--base-blue-40) | var(--base-blue-50) | var(--base-neutral-black) |
| `use/surface/theme/blue-dark/50` | `--use-surface-theme-blue-dark-50` | var(--base-blue-50) | var(--base-blue-60) | var(--base-neutral-black) |
| `use/surface/theme/blue-dark/60` | `--use-surface-theme-blue-dark-60` | var(--base-blue-60) | var(--base-blue-60) | var(--base-neutral-black) |
| `use/surface/theme/blue-dark/90` | `--use-surface-theme-blue-dark-90` | var(--base-blue-90) | var(--base-blue-30) | var(--base-neutral-white) |
| `use/surface/theme/gray/5` | `--use-surface-theme-gray-5` | var(--product-gray-5) | var(--product-gray-90) | var(--base-neutral-black) |
| `use/surface/theme/gray/10` | `--use-surface-theme-gray-10` | var(--product-gray-10) | var(--product-gray-80) | var(--base-neutral-black) |
| `use/surface/theme/gray/20` | `--use-surface-theme-gray-20` | var(--product-gray-20) | var(--product-gray-70) | var(--base-neutral-black) |
| `use/surface/theme/green-1/30` | `--use-surface-theme-green-1-30` | var(--base-green-1-30) | var(--base-green-1-80) | var(--base-neutral-black) |
| `use/surface/theme/green-1/40` | `--use-surface-theme-green-1-40` | var(--base-green-1-40) | var(--base-green-1-50) | var(--base-neutral-black) |
| `use/surface/theme/green-1/50` | `--use-surface-theme-green-1-50` | var(--base-green-1-50) | var(--base-green-1-60) | var(--base-neutral-black) |
| `use/surface/theme/green-2/10` | `--use-surface-theme-green-2-10` | var(--base-green-2-10) | var(--base-green-2-100) | var(--base-neutral-black) |
| `use/surface/theme/green-2/20` | `--use-surface-theme-green-2-20` | var(--base-green-2-20) | var(--base-green-2-60) | var(--base-neutral-black) |
| `use/surface/theme/green-2/40` | `--use-surface-theme-green-2-40` | var(--base-green-2-40) | var(--base-green-2-60) | var(--base-neutral-black) |
| `use/surface/theme/green-2/60` | `--use-surface-theme-green-2-60` | var(--base-green-2-60) | var(--base-green-2-20) | var(--base-neutral-black) |
| `use/surface/theme/neutral/30` | `--use-surface-theme-neutral-30` | var(--base-neutral-30) | var(--base-neutral-70) | var(--base-neutral-black) |
| `use/surface/theme/orange/10` | `--use-surface-theme-orange-10` | var(--base-orange-10) | var(--base-orange-100) | var(--base-neutral-black) |
| `use/surface/theme/orange/20` | `--use-surface-theme-orange-20` | var(--base-orange-20) | var(--base-orange-40) | var(--base-neutral-black) |
| `use/surface/theme/orange/40` | `--use-surface-theme-orange-40` | var(--base-orange-40) | var(--base-orange-60) | var(--base-neutral-black) |
| `use/surface/theme/orange/60` | `--use-surface-theme-orange-60` | var(--base-orange-40) | var(--base-orange-10) | var(--base-neutral-black) |
| `use/surface/theme/red/30` | `--use-surface-theme-red-30` | var(--base-red-30) | var(--base-red-80) | var(--base-neutral-black) |
| `use/surface/theme/red/40` | `--use-surface-theme-red-40` | var(--base-red-40) | var(--base-red-50) | var(--base-neutral-black) |
| `use/surface/theme/red/50` | `--use-surface-theme-red-50` | var(--base-red-50) | var(--base-red-60) | var(--base-neutral-black) |
| `use/surface/theme/red/60` | `--use-surface-theme-red-60` | var(--base-red-60) | var(--base-red-60) | var(--base-neutral-black) |
| `use/surface/theme/violet/5` | `--use-surface-theme-violet-5` | var(--product-violet-5) | var(--product-violet-90) | var(--base-neutral-black) |
| `use/surface/theme/violet/10` | `--use-surface-theme-violet-10` | var(--product-violet-10) | var(--product-violet-80) | var(--base-neutral-black) |
| `use/surface/theme/violet/20` | `--use-surface-theme-violet-20` | var(--product-violet-20) | var(--product-violet-70) | var(--base-neutral-black) |
| `use/surface/theme/violet/60` | `--use-surface-theme-violet-60` | var(--product-violet-60) | var(--product-violet-10) | var(--base-neutral-black) |
| `use/surface/theme/violet/70` | `--use-surface-theme-violet-70` | var(--product-violet-70) | var(--product-violet-20) | var(--base-neutral-black) |
| `use/surface/theme/yellow/30` | `--use-surface-theme-yellow-30` | var(--base-yellow-30) | var(--base-yellow-90) | var(--base-neutral-black) |
| `use/surface/theme/yellow/50` | `--use-surface-theme-yellow-50` | var(--base-yellow-50) | var(--base-yellow-60) | var(--base-neutral-black) |
| `use/surface/theme/yellow/60` | `--use-surface-theme-yellow-60` | var(--base-yellow-60) | var(--base-yellow-70) | var(--base-neutral-black) |
| `use/surface/theme/yellow/70` | `--use-surface-theme-yellow-70` | var(--base-yellow-70) | var(--base-yellow-70) | var(--base-neutral-black) |
