# Responsive / Breakpoints

> Fuente: `docs/guidelines/responsive-breakpoints.html` · Plataforma: Web y App · Sistema de diseño v2.4.0

Guía transversal para definir breakpoints, uso de grilla y adaptación de componentes en Web, ZT Drupal y App. El objetivo es mantener layouts consistentes sin crear reglas aisladas por página.

Estado: estable Web / App Bootstrap compatible Grid 12 columnas

## Resumen

### Principios

- Diseñar mobile first: una columna por defecto y escalar progresivamente.
- Usar grilla de 12 columnas en Web y ZT Drupal.
- Evitar breakpoints personalizados salvo que un componente lo justifique.
- En App priorizar ancho del dispositivo, área segura y controles táctiles.
- Los tokens de espaciado deben mantenerse entre modos Light, Dark y Alto contraste.

### Do

Define el comportamiento por columnas y deja que la grilla resuelva el ancho.

```html
<div class="row g-4">
  <div class="col-12 col-md-6 col-xl-4">...</div>
</div>
```

### Don't

No fijes anchos rígidos que rompan en móvil o tablet.

```html
.card {
  width: 390px;
  margin-left: 80px;
}
```

## Breakpoints Web

Usa la escala Bootstrap como referencia transversal para layouts Web y portal ZT Drupal.

| Nombre | Rango | Uso principal | Grilla recomendada |
| --- | --- | --- | --- |
| `xs` | < 576 px | Móvil pequeño | `col-12`, una columna |
| `sm` | ≥ 576 px | Móvil amplio | `col-sm-*` solo cuando el contenido respira |
| `md` | ≥ 768 px | Tablet vertical | 2 columnas livianas, navegación simplificada |
| `lg` | ≥ 992 px | Tablet horizontal / laptop | 2 a 3 columnas, paneles laterales posibles |
| `xl` | ≥ 1200 px | Desktop | 3 a 4 columnas según densidad |
| `xxl` | ≥ 1400 px | Desktop amplio | Contenedor máximo; no estirar texto indefinidamente |

## Grid usage

La grilla organiza contenido, pero la jerarquía la define el flujo. En móvil, todo debe poder leerse en una sola columna.

### Contenido editorial

Usa `col-12 col-lg-8` para texto principal y limita el ancho de lectura.

### Cards repetidas

Usa `col-12 col-md-6 col-xl-4` para listas escaneables.

### Formularios

Agrupa campos relacionados. En móvil, conserva una columna y labels visibles.

## App

En App no usamos la grilla desktop como base visual. La adaptación parte del ancho disponible, orientación, área segura y tamaño mínimo táctil.

### Reglas App

- Usar una columna para flujos transaccionales y formularios.
- Respetar área segura superior e inferior del dispositivo.
- Controles táctiles mínimos de 44 px; ideal 48 px.
- Bottom sheets ocupan el ancho del dispositivo y se anclan abajo.
- En tablet se permite layout de dos paneles solo si mejora comparación o edición.

## Reglas prácticas

### Espaciado

Usa `var(--space-*)`. Reduce de forma controlada en móvil, pero no elimines separación entre acciones.

### Texto

No escales fuentes con viewport. Usa clases de texto configuradas para los modos.

### Imágenes

Define `aspect-ratio` o contenedor estable para evitar saltos de layout.

### Navegación

En móvil prioriza navegación compacta, drawers o tabs cuando el flujo lo requiera.

## Pendiente de documentación

La página de origen no trae contenido para: Variantes, Estados, Propiedades / API, Responsive, Accesibilidad, Tokens usados. No se completa con suposiciones.
