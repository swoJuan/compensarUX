# Motion / Animación

> Fuente: `docs/guidelines/motion-animation.html` · Plataforma: Web y App · Sistema de diseño v2.4.0

Guía transversal para definir duraciones, curvas de easing y criterios de uso de animación en Web, ZT Drupal y App. La animación debe orientar, confirmar y reducir fricción, no decorar sin propósito.

Estado: estable Web / App Accesibilidad Reduced motion

## Resumen

### Principios

- Usar motion para comunicar cambio de estado, jerarquía o navegación.
- Animar propiedades baratas: `opacity`, `transform`, `box-shadow` y color.
- Evitar animar layout: width, height, margin, top, left o contenido de texto.
- Respetar `prefers-reduced-motion` en animaciones no esenciales.
- En App, mantener transiciones cortas y vinculadas a gestos táctiles.

### Do

Usa transiciones breves para feedback de interacción.

### Don't

No animes elementos críticos de forma lenta, ornamental o repetitiva.

## Durations

Las duraciones deben sentirse inmediatas. Usa rangos cortos para microinteracciones y reserva duraciones mayores para superficies completas.

| Duración | Uso | Ejemplos | Regla |
| --- | --- | --- | --- |
| `100-120 ms` | Respuesta inmediata | Pressed, tap, icon feedback | No usar para entrada/salida de superficies. |
| `150-180 ms` | Microinteracciones | Hover, focus, color, border, shadow | Duración por defecto en controles. |
| `200-250 ms` | Cambio de estado visible | Acordeón, switch, tabs, stepper | Debe sentirse fluido sin bloquear. |
| `280-320 ms` | Superficies móviles | Sidebar, drawer, bottom sheet, modal | Usar con easing expresivo, no lineal. |
| `600-900 ms` | Animación continua | Loading spinner | Solo para estados de espera. |

## Easings

La curva debe acompañar el tipo de movimiento. Evita curvas dramáticas que hagan sentir pesada una interfaz transaccional.

### Standard

`ease` o `ease-in-out` para color, borde y sombra.

### Emphasized

`cubic-bezier(.4,0,.2,1)` para drawers, sidebars y sheets.

### Linear

`linear` solo para loops mecánicos como loading.

## Qué animar y qué no

### Animar

- `opacity` para aparición y salida simple.
- `transform` para desplazamientos de paneles.
- `box-shadow` para elevación o hover.
- `background-color`, `border-color` y `color` para estados.

### Evitar

- Animar alto/ancho de contenedores grandes si causa saltos.
- Usar rebotes o overshoot en flujos médicos o transaccionales.
- Animar texto de lectura, totales, precios o mensajes de error.
- Loops decorativos permanentes fuera de loading.

## App

En App, la animación debe reforzar el gesto. El movimiento debe estar anclado al borde, dirección o elemento que activó la acción.

### Reglas App

- Bottom sheet: entra desde abajo en 280-320 ms.
- Overlay: fade corto de 150-200 ms.
- Tap feedback: 100-150 ms.
- Evitar animaciones simultáneas que compitan con el gesto.

## Accesibilidad

Todo componente con animación debe funcionar con `prefers-reduced-motion: reduce`. En ese modo se eliminan desplazamientos y loops no esenciales, pero se conserva feedback claro mediante color, borde, texto o estado.

```html
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}
```

## Pendiente de documentación

La página de origen no trae contenido para: Variantes, Estados, Propiedades / API, Responsive, Tokens usados. No se completa con suposiciones.
