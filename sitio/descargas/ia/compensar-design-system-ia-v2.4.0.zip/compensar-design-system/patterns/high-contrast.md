# High Contrast — Reglas de uso

> Fuente: `docs/guidelines/high-contrast.html` · Plataforma: Web y App · Sistema de diseño v2.4.0

Modo enfocado en maximizar la legibilidad y facilitar la interacción para todos los usuarios, especialmente en condiciones de baja visión.

Estado: estable Web / ZT Drupal Accesibilidad Figma: 4727:4458

## Principios generales

- El fondo principal debe ser negro o muy oscuro.
- El texto principal debe mantener contraste máximo.
- La estructura debe seguir siendo clara sin depender solo del color.
- Los estados interactivos deben tener borde, icono o texto adicional.

## Reglas de color

- Usar tokens semánticos del sistema, no colores hardcodeados.
- Las variantes deben conservar significado y contraste.
- Evitar grises suaves cercanos al fondo.
- No usar color como único indicador de estado.

## Contenedores y superficies

- Los contenedores deben tener borde visible.
- No depender de sombras para separar elementos.
- Las cards deben conservar jerarquía en ambos modos.
- El contenido debe seguir siendo escaneable.

## Imágenes reales

- Las imágenes deben mantenerse sin filtros automáticos.
- No alterar brillo, contraste ni color de forma artificial.
- Validar que la imagen sea visible en superficies oscuras.
- No usar la imagen como único medio de comunicación.

## Estados e interacción

- Hover, focus y selected deben diferenciarse claramente.
- El focus debe ser visible con teclado.
- Los estados deben combinar color, borde, texto o icono.
- Los alertas deben conservar rol semántico.

## Inputs y formularios

- Los labels deben permanecer visibles.
- El borde del campo debe ser claro en default, focus y error.
- El error debe comunicarse con texto e icono, no solo color.
- El placeholder no debe competir con el contenido.

## Navegación y botones

- Los enlaces de navegación deben conservar foco visible.
- Los botones deben mantener contraste en todos sus estados.
- Usar componentes del sistema para evitar variaciones manuales.
- No mezclar estilos inline con componentes productivos.

## Consideraciones para HTML

- Usar siempre tokens o variables semánticas.
- Evitar estilos inline en implementación productiva.
- Validar estados hover, focus, active y disabled.
- Evitar sombras como único separador.

## Buenas prácticas

- Priorizar legibilidad sobre estética.
- Simplificar la interfaz cuando sea necesario.
- Usar componentes reales del sistema.
- Probar los flujos completos en alto contraste.

## Accesibilidad

- Mantener contraste mínimo 4.5:1 o superior.
- No depender solo del color para comunicar información.
- Asegurar navegación por teclado.
- Mantener focus visible en todos los elementos interactivos.

## Pendiente de documentación

La página de origen no trae contenido para: Resumen / cuándo usarlo, Variantes, Propiedades / API, Responsive, Tokens usados. No se completa con suposiciones.
