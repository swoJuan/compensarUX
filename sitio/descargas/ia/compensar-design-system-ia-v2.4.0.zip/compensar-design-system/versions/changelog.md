# Historial de versiones

Versión de este paquete: v2.4.0.

## v2.4.0 — 2026-11-11

Core Design System v2.4.0 — Tabs: menú desplegable por debajo de 768 px (informe 32)



## v2.3.0 — 2026-11-11

v2.3.0: cierre técnico de la estabilización. Verificaciones diferidas: Safari, VoiceOver y revisión visual del equipo.


**Qué revisar:** Cambios de color en badges e íconos de advertencia, y títulos de tarjeta en negrita. Pendientes de revisión visual del equipo, Safari y VoiceOver.

## v2.2.1 — 2026-11-06

Core Design System v2.2.1 — DEC-003 estados de Inputs (Error, Focus, Disabled, Readonly) conforme a Figma



## v2.2.0 — 2026-11-06

Design System v2.2.0 — campos de solo lectura y deshabilitados


