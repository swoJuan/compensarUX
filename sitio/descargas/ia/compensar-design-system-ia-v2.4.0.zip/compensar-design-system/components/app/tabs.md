# Tabs App

> Fuente: `docs/app/components/tabs.html` · Plataforma: App · Sistema de diseño v2.4.0

Navegación móvil para alternar entre vistas del mismo nivel. Basado en el componente App de Figma y orientado a implementación .NET MAUI.

Estado: estable App · .NET MAUI Figma: 4010:11030 Altura: 48 / 64 px

## Resumen

### Cuándo usarlo

- Para cambiar entre vistas hermanas en una pantalla móvil.
- Cuando las opciones son entre 2 y 4 en tabs fijos.
- Cuando hay más opciones, usa versión scrollable con ancho de tab estable.
- Evita usarlos como navegación global principal; para eso usa Shell o bottom navigation.

### Do

Labels cortos, jerarquía clara y un indicador visible para la pestaña activa.

### Don't

No uses labels extensos ni demasiadas opciones en tabs fijos.

Consulta médica general Medicamentos pendientes Autorizaciones por revisar

## Variantes

### Primary · label only

### Primary · label & icon

### Secondary

### Scrollable

## Estados

### Default

### Active

### Disabled

### Focus

## Pendiente de documentación

La página de origen no trae contenido para: Responsive, Accesibilidad, Tokens usados. No se completa con suposiciones.
