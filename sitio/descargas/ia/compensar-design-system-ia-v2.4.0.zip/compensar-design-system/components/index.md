# Componentes

Componentes documentados del sistema de diseño v2.4.0: 29. Plataforma «Web y App» son componentes transversales.

| Componente | Plataforma | Resumen / cuándo usarlo | Variantes | Estados | Propiedades / API | Responsive | Accesibilidad | Tokens usados |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| [Accordion](transversales/accordion.md) | Web y App | sí | pendiente | sí | sí | sí | sí | pendiente |
| [Alertas](transversales/alerts.md) | Web y App | sí | sí | sí | sí | sí | sí | sí |
| [Avatar / User chip](transversales/avatar.md) | Web y App | sí | sí | sí | sí | pendiente | pendiente | pendiente |
| [Chips / Tags / Badges](transversales/badges.md) | Web y App | sí | pendiente | sí | sí | sí | sí | pendiente |
| [Botón](transversales/buttons.md) | Web y App | sí | sí | sí | sí | sí | sí | sí |
| [Cards](transversales/cards.md) | Web y App | sí | sí | sí | sí | sí | sí | pendiente |
| [Dropdown / Select](transversales/dropdown.md) | Web y App | sí | pendiente | sí | pendiente | sí | sí | sí |
| [Input / Campo de texto](transversales/inputs.md) | Web y App | sí | sí | sí | sí | sí | sí | sí |
| [Loading](transversales/loading.md) | Web y App | sí | sí | sí | sí | sí | sí | pendiente |
| [Modal](transversales/modals.md) | Web y App | sí | sí | sí | sí | sí | sí | sí |
| [Paginación](transversales/pagination.md) | Web y App | sí | pendiente | sí | pendiente | sí | pendiente | pendiente |
| [Checkbox / Radio / Switch](transversales/selection-controls.md) | Web y App | sí | sí | sí | sí | sí | sí | sí |
| [Tables](transversales/tables.md) | Web y App | sí | sí | sí | sí | sí | sí | pendiente |
| [Tabs](transversales/tabs.md) | Web y App | sí | sí | sí | sí | sí | sí | pendiente |
| [Toast](transversales/toasts.md) | Web y App | sí | sí | sí | sí | sí | sí | sí |
| [Accordion](web/accordion.md) | Web | sí | pendiente | sí | sí | sí | sí | pendiente |
| [Chips / Tags / Badges](web/badges.md) | Web | sí | pendiente | sí | sí | sí | sí | pendiente |
| [Breadcrumb](web/breadcrumb.md) | Web | sí | pendiente | sí | sí | sí | sí | pendiente |
| [Empty State](web/empty-state.md) | Web | sí | sí | pendiente | sí | pendiente | sí | pendiente |
| [Navigation patterns](web/header.md) | Web | pendiente | pendiente | pendiente | sí | pendiente | sí | pendiente |
| [Cómo conectarlo](web/icons-connect.md) | Web | pendiente | pendiente | pendiente | pendiente | pendiente | pendiente | pendiente |
| [Sistema de iconos](web/icons-intro.md) | Web | pendiente | pendiente | pendiente | pendiente | pendiente | pendiente | pendiente |
| [Loading](web/loading.md) | Web | sí | sí | sí | sí | sí | sí | pendiente |
| [Sidebar / Overlay](web/sidebar.md) | Web | sí | sí | pendiente | sí | sí | sí | pendiente |
| [Stepper](web/stepper.md) | Web | sí | sí | pendiente | pendiente | pendiente | sí | pendiente |
| [Bottom Sheet](app/bottom-sheet.md) | App | sí | sí | sí | sí | pendiente | sí | pendiente |
| [Dropdown / Select App](app/dropdown.md) | App | sí | pendiente | sí | pendiente | sí | sí | sí |
| [Header App](app/header.md) | App | sí | sí | sí | sí | pendiente | pendiente | pendiente |
| [Tabs App](app/tabs.md) | App | sí | sí | sí | sí | pendiente | pendiente | pendiente |


«pendiente» significa que la página de origen no tiene esa información; no se completa con suposiciones.
