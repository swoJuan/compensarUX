# Sidebar / Overlay

> Fuente: `docs/web/components/sidebar.html` · Plataforma: Web · Sistema de diseño v2.4.0

Panel lateral que emerge desde la derecha de la pantalla para mostrar detalles, confirmar acciones o presentar flujos secundarios sin abandonar la página actual. En móvil se convierte en bottom sheet.

Estado: estable Versión 1.0 Web Categoría: overlay Figma: 4715:5763

## Resumen

### Cuándo usarlo

- Para mostrar detalles de un ítem de lista (centro médico, cita, servicio) sin navegar a otra página.
- Para confirmar o revisar información antes de una acción crítica.
- Para flujos secundarios de 1-3 pasos que no justifican una página completa.
- Cuando el contexto detrás del panel debe mantenerse visible en desktop.

### Do

Usa el sidebar para detalles contextuales que complementan la vista actual.

Detalle de centro médico Confirmar cita

### Don't

No uses el sidebar para flujos complejos de más de 3 pasos — navega a una página dedicada.

Formulario de 5 pasos Onboarding completo

## Variantes

### Detalle (con imagen)

Muestra información de un centro médico: foto, estado, horarios y datos de contacto.

### Confirmación

Resumen previo a una acción crítica (confirmar cita, pago, cancelación).

## Comportamiento

Apertura `translateX(100%)` → `translateX(0)`, 280 ms, `cubic-bezier(.4,0,.2,1)`
Cierre Clic en backdrop · Clic en ✕ · Tecla Escape
Scroll Body del panel scrollable — página detrás bloqueada (`overscroll-behavior: contain`)
Clase activa Agregar `.is-open` al `.mp-sidebar` para mostrar
Ancho desktop `--mp-sidebar-width: 480px` — ajustable con custom property
Alto máx. mobile `max-height: 90dvh` — evita cubrir toda la pantalla
z-index `400` — sobre headers y tooltips, bajo modales de alerta
Responsive ≤ 768 px Bottom sheet — emerge desde abajo: `translateY(100%)` → `translateY(0)`, border-radius arriba

### Demo responsive (bottom sheet)

En pantallas ≤ 768 px el panel cambia a bottom sheet: sale de abajo, ocupa el ancho completo y tiene borde redondeado solo arriba. El backdrop y el cierre por Escape funcionan igual.

- `border-radius: 16px 16px 0 0`
- `width: 100%`
- `max-height: 90dvh`

Calle 94
Abierto 24 horas

## Do / Don't

### Do

- Mantén el título del panel corto (1 línea máx).
- El footer debe tener 1 acción primaria clara.
- Cierra el panel automáticamente tras completar la acción.
- Preserva el foco en el panel al abrirlo (`focus` en el botón cerrar).

### Don't

- No apiles sidebars encima de otro sidebar.
- No uses el sidebar para contenido que el usuario necesita comparar con la página de fondo.
- No bloquees el scroll del body con `overflow: hidden` si hay campos de formulario en el panel (iOS bug).
- No olvides manejar Escape para accesibilidad de teclado.

## Accesibilidad

- `role="dialog"` + `aria-modal="true"` en `.mp-sidebar`.
- `aria-label` o `aria-labelledby` apuntando al título del panel.
- Al abrir, mover el foco al primer elemento interactivo (botón cerrar o primer campo).
- Al cerrar, restaurar el foco al elemento que lo abrió.

- Implementar **focus trap**: Tab y Shift+Tab deben circular dentro del panel.
- Escape cierra el panel siempre.
- El backdrop tiene `aria-hidden="true"` — no es interactivo para lectores de pantalla.
- Contraste mínimo 4.5:1 en todo texto sobre el fondo del panel.

## Checklist QA

- Panel entra con animación suave desde la derecha (desktop) o desde abajo (mobile).
- Backdrop oscurece el fondo y cierra el panel al hacer clic.
- Escape cierra el panel desde cualquier elemento interno.
- El body del panel scrollea independientemente de la página.
- El footer permanece visible (sticky) al hacer scroll dentro del body.
- En mobile, el panel ocupa máximo 90dvh y tiene border-radius arriba.
- Focus ring visible al navegar con teclado.
- Se ve correctamente en Light, Dark y High Contrast.

## Código

Calle 94
Abierto 24 horas

Cierra a las 7:00 pm

Ubicación y contacto

Transversal Pereira # 23-45, Piso 2

321 123 4578

Horarios de atención

Lunes a Viernes6:00 am – 10:30 pm
Sábados6:00 am – 10:30 am
Domingos y FestivosNo hay atención
Confirma tu cita

Revisa que la información sea correcta y si estás de acuerdo, presiona confirmar.

Doctor

Dra. Mariana Zapata

Medicina General

Fecha y hora

Jueves, 01 de Enero 2026 — 8:00 am

Ubicación

San Roque — Cajicá

Modalidad

Cita presencial

## Pendiente de documentación

La página de origen no trae contenido para: Estados, Tokens usados. No se completa con suposiciones.
