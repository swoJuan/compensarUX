# Empty State

> Fuente: `docs/web/components/empty-state.html` · Plataforma: Web · Sistema de diseño v2.4.0

Comunica a los usuarios que no hay contenido disponible en una sección. Orienta sobre qué ocurrió y, cuando es posible, ofrece una acción para resolverlo.

Estado: estable Versión 1.0 Web Categoría: feedback

## Resumen

### Cuándo usarlo

- Cuando una lista, tabla o sección no tiene contenido que mostrar.
- Después de una búsqueda sin resultados.
- En estados iniciales donde el usuario aún no ha creado contenido.
- Cuando un filtro activo excluye todos los resultados.

### Do

Usa un ícono claro, un título breve y una acción concreta cuando aplique.

##### **Sin resultados**

Intenta con otros términos de búsqueda.

### Don't

No uses textos vagos como "Nada aquí" sin contexto ni orientación.

Nada aquí.

## Variantes

Default

Variante base sin borde. Úsala cuando el contenedor padre ya define el fondo y límites visuales.

Con borde `--bordered`

Agrega borde, radio y fondo. Úsala cuando el empty state necesita delimitarse visualmente dentro de un área sin fondo propio.

Compacto `--compact`

Reduce padding, gap e ícono. Ideal para paneles laterales, widgets o áreas con espacio limitado.

Solo texto `--text-only`

Oculta el contenedor del ícono. Úsalo cuando la ilustración es prescindible y se prioriza claridad textual.

## Con acción

Un botón primario

Cuando hay una acción principal clara que resuelve el estado vacío.

Dos acciones

Cuando existen dos caminos: resolver el problema directamente o explorar sin restricciones.

## Código

```html
<!-- Default -->
<div class="mp-empty-state">
  <div class="mp-empty-state__icon" aria-hidden="true">
    <i class="icon icon-package" aria-hidden="true"></i>
  </div>
  <h4 class="mp-h4 mp-empty-state__title">Sin elementos</h4>
  <p class="mp-body-l mp-empty-state__desc">
    No hay elementos disponibles en este momento.
  </p>
  <div class="mp-empty-state__action">
    <button type="button" class="mp-btn mp-btn--primario">Crear nuevo</button>
  </div>
</div>

<!-- Con borde -->
<div class="mp-empty-state mp-empty-state--bordered">
  <!-- mismo contenido interior -->
</div>

<!-- Compacto -->
<div class="mp-empty-state mp-empty-state--compact">
  <!-- mismo contenido interior -->
</div>

<!-- Solo texto (sin ícono) -->
<div class="mp-empty-state mp-empty-state--text-only">
  <h4 class="mp-h4 mp-empty-state__title">No hay notificaciones</h4>
  <p class="mp-body-l mp-empty-state__desc">Estás al día.</p>
</div>
html
// ── Base ──────────────────────────────────────────────────────
.mp-empty-state {
  display:         flex;
  flex-direction:  column;
  align-items:     center;
  justify-content: center;
  gap:             var(--space-16);
  padding:         var(--space-24);
  text-align:      center;
  width:           100%;
}

// ── Ícono / ilustración ───────────────────────────────────────
.mp-empty-state__icon {
  display:         flex;
  align-items:     center;
  justify-content: center;
  width:           rem(56px);
  height:          rem(56px);
  border-radius:   var(--radius-md);
  background:      var(--use-surface-subtle);
  color:           var(--color-text-secondary);
  flex-shrink:     0;

  .icon {
    font-size:   rem(32px);
    line-height: 1;
  }
}

// ── Título — usar <h4 class="mp-h4"> en el HTML ─────────────
.mp-empty-state__title {
  color:  var(--color-text-primary);
  margin: 0;
}

// ── Descripción — usar clase mp-body-m en el HTML ────────────
.mp-empty-state__desc {
  color:     var(--color-text-secondary);
  max-width: rem(480px);
  margin:    0;
}

// ── Acción ───────────────────────────────────────────────────
.mp-empty-state__action {
  display:         flex;
  gap:             var(--space-12);
  align-items:     center;
  flex-wrap:       wrap;
  justify-content: center;
  margin-top:      var(--space-8);
}

// ── Modificadores ─────────────────────────────────────────────
.mp-empty-state--bordered {
  border:        1px solid var(--color-border-subtle);
  border-radius: var(--radius-lg);
  background:    var(--color-surface-default);
}

.mp-empty-state--compact {
  padding: var(--space-16);
  gap:     var(--space-12);

  .mp-empty-state__icon {
    width:  rem(40px);
    height: rem(40px);

    .icon { font-size: rem(22px); }
  }
}

.mp-empty-state--text-only {
  .mp-empty-state__icon { display: none; }
}

// ── Dark mode ─────────────────────────────────────────────────
[data-theme='dark'] {
  .mp-empty-state--bordered {
    border-color: var(--use-border-default);
    background:   var(--use-surface-white);
  }
}

// ── High Contrast ─────────────────────────────────────────────
[data-theme='high-contrast'] {
  .mp-empty-state__icon {
    background: transparent;
    border:     2px solid var(--use-border-default);
    color:      var(--use-text-primary);
  }

  .mp-empty-state--bordered {
    border:     2px solid var(--use-border-default);
    background: var(--use-background-page);
  }
}
html
<mp-empty-state
  icon="package"
  title="Sin elementos"
  description="No hay elementos disponibles en este momento."
  variant="bordered">
  <ng-template mpEmptyStateAction>
    <button type="button" class="mp-btn mp-btn--primario"
            (click)="onCreate()">
      Crear nuevo
    </button>
  </ng-template>
</mp-empty-state>
```

## API del componente

| Clase / Propiedad | Tipo | Default | Descripción |
| --- | --- | --- | --- |
| `.mp-empty-state` | clase base | — | Contenedor principal. Siempre requerido. |
| `.mp-empty-state__icon` | elemento | — | Contenedor del ícono (56×56 px). Usa `aria-hidden="true"` en el ícono decorativo. |
| `.mp-empty-state__title` | elemento | — | Título del estado. Usar elemento `<h4>` con clase `.mp-h4`. Ajusta el nivel semántico según el contexto de la página. |
| `.mp-empty-state__desc` | elemento | — | Descripción de apoyo. Combinar con `.mp-body-m`. Ancho máximo 480 px. |
| `.mp-empty-state__action` | elemento | — | Contenedor opcional para uno o dos botones de acción. |
| `--bordered` | modificador | — | Agrega borde, radio y fondo de superficie al contenedor. |
| `--compact` | modificador | — | Reduce padding (16 px), gap (12 px) e ícono (40×40 px). Para espacios reducidos. |
| `--text-only` | modificador | — | Oculta el contenedor del ícono. Úsalo cuando el ícono no aporta valor semántico. |
| `icon` (Angular) | `string` | — | Nombre del ícono Material Symbols. |
| `title` (Angular) | `string` | — | Texto del título principal. |
| `description` (Angular) | `string` | — | Texto de descripción secundaria. |
| `variant` (Angular) | `'default' \| 'bordered' \| 'compact' \| 'text-only'` | `'default'` | Variante visual del componente. |

## Accesibilidad

Ícono decorativo
El ícono del contenedor debe marcarse con `aria-hidden="true"`. El significado se transmite por el título y la descripción.
Jerarquía semántica
Usa `<h4 class="mp-h4">` como elemento del título. Ajusta el nivel (`h2`, `h3`…) si el contexto lo requiere para mantener la jerarquía correcta de la página.
Acción accesible
Los botones de acción deben tener texto descriptivo. Evita etiquetas genéricas como "Aquí" o "Click". Prefiere "Crear nuevo documento" sobre "Crear".
Contraste
El título y descripción usan tokens de texto primario y secundario respectivamente, garantizando contraste 4.5:1 en todos los modos del sistema.

## Pendiente de documentación

La página de origen no trae contenido para: Estados, Responsive, Tokens usados. No se completa con suposiciones.
