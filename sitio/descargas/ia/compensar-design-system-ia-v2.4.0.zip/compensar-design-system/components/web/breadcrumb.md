# Breadcrumb

> Fuente: `docs/web/components/breadcrumb.html` · Plataforma: Web · Sistema de diseño v2.4.0

Muestra la ubicación del usuario dentro de la estructura del sitio y permite navegar fácilmente entre niveles jerárquicos.

Estado: estable Versión 1.0 Web Categoría: navegación Figma: 4629:87274

## Resumen

### Cuándo usarlo

- Para navegación jerárquica.
- Para mostrar contexto de ubicación dentro del sitio.
- Para facilitar el regreso a niveles anteriores.
- Cuando la arquitectura tiene más de dos niveles.

### Do

Usa niveles cortos y deja el último como página actual no interactiva.

### Don't

No lo uses como menú principal ni con rutas largas difíciles de escanear.

Inicio / Usuarios / Cuenta / Contratos / Pagos / Detalle

## Estados

### Default

Estado base.

### Active

Página actual.

### Página anterior

Enlace hacia otras páginas.

### Focus

Navegación con teclado.

## Comportamiento y reglas

- Los niveles anteriores son clickeables.
- El último nivel no es interactivo y usa `aria-current="page"`.
- Mantén máximo 3 a 4 niveles visibles.
- Usa labels claros y cortos; no trunques el nivel actual.

## Accesibilidad

- Usa `nav` con `aria-label="Breadcrumb"`.
- Los enlaces deben ser identificables y navegables con teclado.
- Los separadores son decorativos y llevan `aria-hidden="true"`.
- Debe mantener contraste en Light, Dark y High Contrast.

## Checklist QA

- Home mide 20 px y separadores 16 px.
- Texto de breadcrumb usa 16 px y el nivel actual va en bold.
- Focus visible en enlaces anteriores.
- El último nivel no es enlace y declara `aria-current="page"`.
- Light, Dark y High Contrast mantienen contraste correcto.

## Pendiente de documentación

La página de origen no trae contenido para: Variantes, Tokens usados. No se completa con suposiciones.
