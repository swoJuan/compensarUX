# Cómo conectarlo

> Fuente: `docs/web/components/icons-connect.html` · Plataforma: Web · Sistema de diseño v2.4.0

1.8.2

# Cómo conectarlo

Integra la fuente de iconos del sistema con un único CSS, precarga el archivo principal y usa clases semánticas para mantener consistencia entre diseño, desarrollo y documentación.

Implementación técnica
Flujo recomendado

## Conexión en tres pasos

La implementación debe ser predecible: copiar los archivos, cargar el CSS del set y usar la clase base con el nombre del icono y su tamaño en rem.

**1. Copiar archivos**

`icons/`, `fonts/` y `selection.json`.

**2. Cargar CSS**

Usar `icons.css` y precargar `woff2`.

**3. Usar clases**

`.icon` + `.icon-name` + `.icon-24`.

Estructura de archivos

```html
icons/
├── fonts/
│   ├── compensar-icons.woff2   ← fuente principal (preferida)
│   ├── compensar-icons.woff    ← fallback
│   └── compensar-icons.ttf     ← fallback legacy
├── icons.css            ← todo en uno: @font-face + .icon + tamaños + 1001 clases
└── selection.json       ← para actualizar en IcoMoon
```

`fonts/`Archivos de la fuente de iconos (woff2, woff, ttf)
`icons.css`Archivo único — @font-face, clase base `.icon`, tamaños y 1001 clases `::before`
`selection.json`Para actualizar o ampliar el set en icomoon.io
Instalación en tu proyecto

```html
<!-- 1. Un solo archivo CSS -->
<link rel="stylesheet" href="icons/icons.css">
<link rel="preload"
      href="icons/fonts/compensar-icons.woff2"
      as="font" type="font/woff2"
      crossorigin="anonymous">

<!-- 2. Usar el icono -->
<i class="icon icon-name icon-24" aria-hidden="true"></i>
html
@font-face {
  font-family: "CompensarIcons";
  src: url("./icons/fonts/compensar-icons.woff2") format("woff2"),
       url("./icons/fonts/compensar-icons.woff")  format("woff"),
       url("./icons/fonts/compensar-icons.ttf")   format("truetype");
  font-weight: normal;
  font-style: normal;
  font-display: block;
}

.icon {
  font-family: "CompensarIcons" !important;
  font-style: normal;
  font-weight: normal;
  font-variant: normal;
  text-transform: none;
  line-height: 1;
  display: inline-block;
  speak: never;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
/* ── Tamaños de icono ──────────────────────────────────── */
/* Base 16px: 1rem = 16px                                  */
/* Uso:            */
.icon-16 { font-size: 1rem; }    /* 16px */
.icon-20 { font-size: 1.25rem; } /* 20px */
.icon-24 { font-size: 1.5rem; }  /* 24px */
.icon-32 { font-size: 2rem; }    /* 32px */
.icon-40 { font-size: 2.5rem; }  /* 40px */
.icon-48 { font-size: 3rem; }    /* 48px */
.icon-64 { font-size: 4rem; }    /* 64px */
```

Uso en HTML

```html
<!-- Clase nombre + clase tamaño -->
<i class="icon icon-key icon-16" aria-hidden="true"></i>
<i class="icon icon-key icon-20" aria-hidden="true"></i>
<i class="icon icon-key icon-24" aria-hidden="true"></i>
<i class="icon icon-key icon-32" aria-hidden="true"></i>
<i class="icon icon-key icon-40" aria-hidden="true"></i>
<i class="icon icon-key icon-48" aria-hidden="true"></i>
html
<!-- Icono interactivo: necesita aria-label -->
<button class="mp-btn mp-btn--secundario mp-btn--icon-only" aria-label="Buscar">
  <i class="icon icon-magnifying-glass icon-24" aria-hidden="true"></i>
</button>

<!-- Área táctil mínima 2.75rem × 2.75rem (44×44px) -->
<button class="mp-btn mp-btn--secundario mp-btn--icon-only" aria-label="Abrir menú">
  <i class="icon icon-list icon-24" aria-hidden="true"></i>
</button>
html
<!-- Icono + texto: el ícono es decorativo -->
<button class="mp-btn mp-btn--primario mp-btn--icon-left">
  <i class="icon icon-key icon-20" aria-hidden="true"></i>
  Iniciar sesión
</button>

<!-- No usar ícono sin texto cuando la acción no es obvia -->
<!-- ❌ Evitar: -->
<button class="mp-btn mp-btn--secundario mp-btn--icon-only"><i class="icon icon-user icon-24"></i></button>

<!-- ✅ Correcto: -->
<button class="mp-btn mp-btn--secundario mp-btn--icon-only" aria-label="Ver perfil de usuario">
  <i class="icon icon-user icon-24" aria-hidden="true"></i>
</button>
```

Actualizar el set en IcoMoon

1. Ir a icomoon.io/app
2. Click en **"Import Icons" **o** "Load"**
3. Subir el archivo `selection.json` (incluido en el ZIP)
4. El set se restaura con todos los iconos actuales
5. Agregar o quitar iconos según necesidad
6. Exportar → descargar ZIP → reemplazar archivos en el proyecto

Nota importante

El archivo `selection.json` es la fuente de verdad del set. **Nunca modificar los archivos .woff o .ttf directamente.**

Clases de tamaño

Combina la clase base `.icon` con una clase de tamaño. Los valores se expresan en rem y muestran su equivalencia en px sobre base 16.

`icon-warning · 16`
`icon-house · 16`
`icon-user-circle · 20`
`icon-lock · 24`
`icon-heart · 32`
`icon-calendar · 40`
`icon-bell-ringing · 48`
`icon-globe · 64`
`icon-map-pin · 16`
`icon-info · 20`
`icon-key · 24`
`icon-magnifying-glass · 32`

| Clase | Tamaño | Uso recomendado |
| --- | --- | --- |
| `.icon-16` | 1rem (16px) | Texto inline, botones pequeños |
| `.icon-20` | 1.25rem (20px) | Botones estándar, inputs |
| `.icon-24` | 1.5rem (24px) | Navegación, acciones principales ✓ recomendado |
| `.icon-32` | 2rem (32px) | Encabezados de sección |
| `.icon-40` | 2.5rem (40px) | Ilustraciones de apoyo |
| `.icon-48` | 3rem (48px) | Estados vacíos, destacados |
| `.icon-64` | 4rem (64px) | Ilustraciones hero |

```html
<!-- Clase base + clase de tamaño -->
<i class="icon icon-lock icon-16" aria-hidden="true"></i>
<i class="icon icon-lock icon-24" aria-hidden="true"></i>
<i class="icon icon-lock icon-32" aria-hidden="true"></i>

<!-- En un botón -->
<button class="mp-btn mp-btn--primario">
  <i class="icon icon-lock icon-20" aria-hidden="true"></i>
  Iniciar sesión
</button>
```

## Pendiente de documentación

La página de origen no trae contenido para: Resumen / cuándo usarlo, Variantes, Estados, Propiedades / API, Responsive, Accesibilidad, Tokens usados. No se completa con suposiciones.
