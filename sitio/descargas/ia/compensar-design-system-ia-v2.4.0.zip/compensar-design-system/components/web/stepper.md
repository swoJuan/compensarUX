# Stepper

> Fuente: `docs/web/components/stepper.html` · Plataforma: Web · Sistema de diseño v2.4.0

Indica el progreso del usuario a través de un flujo de pasos secuenciales. Muestra cuántos pasos tiene el proceso, cuál es el actual y cuántos han sido completados.

Estado: estable Versión 1.0 Web Categoría: navegación Figma: 4693:4707

## Resumen

### Cuándo usarlo

- Flujos de formulario con 2 o más pasos secuenciales.
- Procesos donde el usuario necesita saber cuánto falta para terminar.
- Flujos de checkout, agendamiento o registro multi-paso.
- Cuando el orden de los pasos es fijo y no se puede saltar.

### Do

Usa el stepper al inicio de un formulario multi-paso para orientar al usuario.

Paso 2 de 3

### Elige la fecha y hora

### Don't

No uses el stepper en flujos de 1 solo paso — no aporta valor visual.

Formulario de contacto simple

## Variantes

### Default — 3 pasos

Con head (contador + título) y track de barras. El paso actual tiene barra de color primario.

### 5 pasos — Paso 3 activo

El número de barras escala con el total de pasos del flujo.

### Compact — Solo barras

Agrega `mp-stepper--compact` para ocultar el head. Útil en headers o espacios reducidos.

### Dark mode

### High Contrast

## Custom properties

`--mp-stepper-done` Color de las barras completadas. Default: `var(--use-primary-default)`
`--mp-stepper-current` Color de la barra activa. Default: `var(--use-primary-default)`
`--mp-stepper-pending` Color de barras pendientes. Default: `var(--use-border-default)`
`--mp-stepper-gap` Separación entre barras. Default: `12px`
`--mp-stepper-h` Alto de cada barra. Default: `2px` (High Contrast: `3px`)

## Do / Don't

### Do

- Usa entre 2 y 6 pasos — más de 6 fragmenta demasiado el flujo.
- El título del paso debe describir la acción principal de esa pantalla.
- Actualiza `aria-valuenow` al navegar entre pasos.
- Usa `mp-stepper--compact` dentro de un header de página.

### Don't

- No uses el stepper para navegación no lineal donde el usuario puede saltar pasos.
- No cambies el color de las barras fuera del sistema de tokens.
- No omitas el `role="progressbar"` — es requerido para accesibilidad.
- No uses texto largo en el título del paso — máximo 4-5 palabras.

## Accesibilidad

- `role="progressbar"` en `.mp-stepper__track`.
- `aria-valuenow` = paso actual, `aria-valuemin="1"`, `aria-valuemax` = total.
- `aria-label` descriptivo: *"Paso 2 de 3"*.

- El stepper es solo informativo — no es interactivo ni recibe foco.
- El contraste de las barras cumple WCAG AA en todos los temas.
- En High Contrast, el alto de barra sube a 3 px para mayor visibilidad.

## Checklist QA

- Las barras completadas (`.is-done`) muestran color primario.
- La barra activa (`.is-current`) muestra color primario.
- Las barras pendientes muestran color de borde sutil.
- El head muestra el número y título del paso actual correctamente.
- `aria-valuenow` se actualiza al navegar entre pasos.
- La variante compact oculta el head completamente.
- Se ve correctamente en Light, Dark y High Contrast.
- Las barras son equitativas en ancho (flex: 1 cada una).

## Pendiente de documentación

La página de origen no trae contenido para: Estados, Propiedades / API, Responsive, Tokens usados. No se completa con suposiciones.
