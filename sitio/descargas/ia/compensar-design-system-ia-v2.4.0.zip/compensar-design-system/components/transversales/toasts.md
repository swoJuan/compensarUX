# Toast

> Fuente: `docs/transversales/components/toasts.html` · Plataforma: Web y App · Sistema de diseño v2.4.0

Mensaje breve y flotante que aparece temporalmente para confirmar una acción o informar un estado del sistema.

Estado: estable Versión 1.0 Web Bootstrap compatible Categoría: feedback Tipo: temporal / flotante

## Toast (Temporal / Flotante)

Los toast flotan sobre la interfaz, no hacen parte del layout y desaparecen automáticamente después de 5 segundos.

### Características

- Flotan sobre la interfaz.
- No bloquean la interacción.
- Tienen alta visibilidad y baja intrusión.
- Se cierran automáticamente en 5 segundos.

### Ubicación

- No ocupa espacio dentro del layout.
- Posición recomendada: esquina superior derecha.
- Máximo 1 a 2 visibles simultáneamente.

Toast
Toast

## Resumen

### Cuándo usarlo

- Confirmar acciones breves y no críticas.
- Informar estados del sistema sin interrumpir el flujo.
- Mostrar feedback que no requiere decisión del usuario.
- Dar visibilidad temporal a una acción completada.

### Do

Usa mensajes breves y claros.

Cambios guardados

La información se actualizó correctamente.

### Don’t

No uses toast para errores críticos, decisiones o información extensa.

Texto demasiado largo

Evita convertir el toast en una lectura extensa.

## Estados

Success
Info
Warning
Error

## Comportamiento

- Aparece tras una acción del usuario o evento del sistema.
- Se cierra automáticamente en 5 segundos.
- Permite cierre manual con botón accesible.
- Evitar acumulación: máximo 1 a 2 visibles.

## Guías de contenido

- Usa mensajes breves y directos.
- No incluyas información extensa ni instrucciones complejas.
- El título debe resumir el resultado de la acción.
- El mensaje puede ampliar el contexto en una línea corta.

## Accesibilidad

- Usar región `aria-live="polite"` para feedback no crítico.
- No desaparecer demasiado rápido: 5 segundos como regla base.
- El botón cerrar requiere `aria-label`.
- No depender solo del color: incluir icono y texto.

## Responsive

### Desktop

Esquina superior derecha, ancho máximo 350 px.

### Tablet

Mantiene posición flotante y ancho máximo.

### Mobile

Ocupa el ancho disponible con margen lateral 16 px.

## Tokens usados

`--space-16`16px · padding y gap principal.
`--space-4`4px · separación entre título y mensaje.
`--use-state-success-bg`#e6f7e8 · fondo success light.
`--use-state-success-border`#44bd75 · borde success light.
`--font-size-md`16px · título Roboto SemiBold.
`--body---l`16px · título y mensaje (Roboto SemiBold / Regular).
`--z-toast`1080 · capa flotante recomendada.
`max-width`350px · regla definida para el sistema.

## Código

Descarga estilos planos del componente transversal, unidos al core y organizados por modo.

## Pendiente de documentación

Sin pendientes detectados automáticamente. Las secciones interactivas (anatomía, playground y visualizador de código) no se incluyen porque se generan en el navegador.
