# Chips / Tags / Badges

> Fuente: `docs/transversales/components/badges.html` · Plataforma: Web y App · Sistema de diseño v2.4.0

Familia de pastillas compactas para filtrar, categorizar o comunicar estados. Comparten estructura visual, pero cada una tiene una intención distinta.

Estado: estable Versión 1.0 Web / App Categoría: indicadores Figma: 4610:73562

## Resumen

### Cuándo usarlo

- Chips: cuando el usuario filtra, selecciona o ejecuta una acción rápida.
- Tags: cuando necesitas clasificar contenido sin interacción.
- Badges: cuando debes comunicar estado, prioridad o conteo.
- Cuando el texto corto ayuda a escanear información en tablas, cards o filtros.

### Do

Usa cada variante según su intención de interacción o lectura.

Afiliado   Activo

### Don't

No uses un badge como botón ni un chip para comunicar estados estáticos.

Eliminar filtro

## ¿Cuál usar?

##### Chip

Interactivo

El usuario lo presiona, selecciona o descarta. Cambia de estado.

- Filtros activos o toggleables
- Selección múltiple
- Acciones rápidas con ícono de cierre

`<button>` · `aria-pressed`

##### Tag

No interactivo

Solo clasifica o etiqueta. Nunca responde a clics ni comunica estados de proceso.

- Categorías de contenido
- Etiquetas en tablas o cards
- Tipo de usuario o plan

`<span>` · solo lectura

##### Badge

Estado / conteo

Comunica estado, prioridad o conteo numérico. Nunca es clicable por sí solo.

- Estado de un registro (Activo, Vencido)
- Prioridad o nivel de alerta
- Contadores sobre íconos o avatares

`<span>` · `role="img"` + `aria-label`

|  | Chip | Tag | Badge |
| --- | --- | --- | --- |
| **Interactivo** | ✅ Sí | ❌ No | ❌ No |
| **Elemento HTML** | `<button>` | `<span>` | `<span>` |
| **Comunica estado** | Seleccionado / activo | Categoría / tipo | Estado / prioridad / conteo |
| **Clase base** | `.mp-chip` | `.mp-tag` | `.mp-badge` |
| **ARIA requerido** | `aria-pressed` | Ninguno adicional | `role="img"` + `aria-label` |

## Estados interactivos

### Default

Estado base disponible.

### Hover

Se evidencia solo en chips interactivos.

### Focus

Anillo visible para navegación con teclado.

### Seleccionado

Comunica filtros o selecciones activas.

### Disabled

No permite interacción.

## Comportamiento y reglas

- Usa chips solo cuando hay interacción.
- Usa tags para clasificación no interactiva.
- Usa badges para estados y evita depender solo del color.
- Mantén textos cortos para lectura rápida.

## Accesibilidad

- Los chips deben exponer estado con `aria-pressed` cuando sean seleccionables.
- Los badges de estado deben tener texto claro o `aria-label`.
- No comuniques estados únicamente con color.
- El área clicable mínima para chips es 44 px.

## Checklist QA

- Verificar Light, Dark y High Contrast.
- Confirmar que chips muestran hover, focus, selected y disabled.
- Validar textos cortos sin desbordes.
- Probar que HTML, CSS y Sass del visualizador se copian completos.

## Pendiente de documentación

La página de origen no trae contenido para: Variantes, Tokens usados. No se completa con suposiciones.
