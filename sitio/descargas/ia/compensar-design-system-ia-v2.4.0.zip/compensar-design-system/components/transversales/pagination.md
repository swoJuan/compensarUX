# Paginación

> Fuente: `docs/transversales/components/pagination.html` · Plataforma: Web y App · Sistema de diseño v2.4.0

Permite navegar entre múltiples páginas de contenido cuando la información es extensa. Facilita la exploración de datos sin sobrecargar la interfaz.

Estado: estable Versión 1.0 Web Categoría: navegación Figma: 4610:71122

## Resumen

### Cuándo usarlo

- Listados de información con muchos registros.
- Historiales de solicitudes, pagos o trámites.
- Resultados de búsqueda o filtros.
- Gestión de datos en tablas o cards.

### Do

Muestra entre 5 y 7 páginas visibles y usa truncado cuando el total sea alto.

### Don't

No muestres demasiados números ni dejes controles activos cuando no aplican.

## Estados especiales

### Default

Estado base disponible.

### Active

Página actual seleccionada.

### Hover

Indica que el item es interactivo.

### Focus

Visible al navegar con teclado.

### Disabled

No permite interacción.

## Comportamiento y reglas

### Comportamiento

- Indicar página actual con `aria-current="page"`.
- Permitir navegación directa y secuencial.
- Deshabilitar anterior o siguiente cuando no aplican.
- Mantener ubicación consistente cerca del contenido paginado.

### Reglas de uso

- Usar en listados largos.
- No mostrar demasiados números.
- Usar truncado cuando hay muchas páginas.
- Por defecto, documentar 7 registros por página.

## Pendiente de documentación

La página de origen no trae contenido para: Variantes, Propiedades / API, Accesibilidad, Tokens usados. No se completa con suposiciones.
