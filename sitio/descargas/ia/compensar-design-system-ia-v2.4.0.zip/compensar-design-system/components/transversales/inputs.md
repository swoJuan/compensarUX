# Input / Campo de texto

> Fuente: `docs/transversales/components/inputs.html` · Plataforma: Web y App · Sistema de diseño v2.4.0

Captura información del usuario en formularios. Soporta texto, email, número, contraseña, teléfono, textarea y select con estados interactivos completos y soporte para íconos decorativos y accionables.

Estado: estable Versión 1.0 Web Bootstrap compatible Categoría: formulario

## Resumen

### Cuándo usarlo

- Para capturar texto libre: nombres, documentos, correos, contraseñas.
- Para seleccionar una opción de una lista corta y fija con `mp-select`.
- Para contenido de múltiples líneas con `mp-textarea`.
- Para campos de búsqueda con ícono decorativo.

### Do

Usa siempre label visible y texto de apoyo cuando se necesite.

Como aparece en tu documento

### Don't

No uses solo el placeholder como etiqueta del campo.

## Estados

Default
Texto de apoyo
Hover
Texto de apoyo
Focus
Texto de apoyo
Error
Mensaje de error
Success
Valor confirmado
Disabled
Campo deshabilitado

## Comportamiento

### Foco

Al hacer clic o navegar con Tab el campo recibe foco con borde naranja y ring de 3 px.

### Validación

El error se muestra en el helper text. No eliminar el label ni el campo al mostrar error.

### Contraseña

El ícono derecho interactivo alterna visibilidad. Renderizado como botón con aria-label.

### Responsive

El campo ocupa el ancho disponible del contenedor. Altura fija 56 px en todas las pantallas.

## Guías de contenido

### Labels correctos

Concisos, descriptivos y siempre visibles.

Nombre completo Correo electrónico N.° de documento

### Labels incorrectos

Ambiguos, redundantes o en mayúsculas.

Campo 1 Ingrese aquí NOMBRE

El placeholder es orientativo, no reemplaza la etiqueta. Los mensajes de error deben ser específicos: "Formato inválido. Ej: AF-12345" en lugar de "Campo inválido".

## Accesibilidad

- Cada campo tiene `<label for="…">` explícito. Nunca depender solo del placeholder.
- `aria-invalid="true"` + `aria-describedby` conectan el mensaje de error al campo para lectores de pantalla.
- Campos requeridos: asterisco con `aria-hidden="true"` más `required` y `aria-required="true"`.
- Íconos decorativos con `aria-hidden="true"`. Íconos accionables como `<button>` con `aria-label`.
- Focus visible en todos los estados. Contraste mínimo AA 4.5:1.
- Área táctil mínima 44 px. El campo tiene 56 px de altura.
- No depender solo del color para comunicar error o success.

## Responsive

### Desktop

Ancho controlado por el contenedor. Recomendado máx. 480 px para campos de texto simples.

### Tablet

Puede ocupar una o dos columnas en grids Bootstrap. Mantiene altura 56 px y padding 16 px.

### Mobile

Full width del contenedor. Los íconos se mantienen alineados. Teclado virtual no afecta altura.

## Tokens usados

`--use-border-subtle` #e0e0e0 · borde por defecto (base-neutral-20)
`--use-border-hover` Naranja brand · borde en hover (= use-primary-hover)
`--use-border-strong` #666 · borde en active mousedown (base-neutral-70)
`--use-primary-default` #FF6600 · borde y ring en focus
`--use-state-error-icon` Rojo · borde en estado error
`--use-state-error-mandatory` #bb4945 · asterisco de campo requerido
`--radius-sm` 16 px · border-radius del campo (border-radius/sm)
`--use-surface-white` Blanco · fondo del campo (varía por tema)
`--use-text-primary` #111 · texto del campo y label
`--use-text-tertiary` #666 · placeholder e íconos decorativos
`--use-state-success-text` Verde · helper text en estado success
`--use-focus-outline` Azul · outline de focus-visible (accesibilidad)

## Código

Descarga estilos planos del input, unidos al core y listos para validar en dummy con tokens Figma.

```html
<div class="mp-input-group">
  <label class="mp-input-label" for="inp1">Nombre</label>
  <div class="mp-input-wrapper">
    <input class="mp-input-field" id="inp1" type="text" placeholder="Tu nombre">
  </div>
  <span class="mp-input-helper">Texto de apoyo</span>
</div>
```

## Pendiente de documentación

Sin pendientes detectados automáticamente. Las secciones interactivas (anatomía, playground y visualizador de código) no se incluyen porque se generan en el navegador.
