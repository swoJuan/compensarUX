# Sistema de diseño de Compensar — documentación para IA (v2.4.0)

Generado el 2026-11-13 desde el commit `63bd56e` del sistema de diseño. Este paquete se regenera con cada publicación del portal; no se edita a mano.

## Cómo usarlo

1. Entrega a tu agente `INSTRUCCIONES-IA.md` (o pégalas como instrucciones del proyecto).
2. Adjunta esta carpeta, o el archivo único `compensar-design-system-completo.md`.
3. Para cada tarea, el agente consulta primero `components/index.md`, `tokens/` y `platforms/<plataforma>.md`.

## Contenido

- `manifest.json`: versión, fuentes, archivos con hash y pendientes.
- `tokens/`: colores, tipografía, espaciado, radios y sombras, breakpoints y `tokens.json`.
- `components/`: 29 componentes (índice en `components/index.md`).
- `foundations/`: principios, tipografía, espaciado, radios, sombras y layout.
- `patterns/`: navegación y formularios, búsqueda, responsive, movimiento, modo oscuro y alto contraste.
- `accessibility/`: criterios de accesibilidad reunidos de cada componente.
- `platforms/`: Drupal, ZT y App: paquetes, orden de carga y particularidades.
- `versions/changelog.md`: historial de versiones.

## Qué no está

- Catálogo de iconos (icons-library): se consulta en la página del sistema de diseño
- Las secciones interactivas de cada componente (anatomía, playground, visualizador de código) se generan en el navegador y no se incluyen.
