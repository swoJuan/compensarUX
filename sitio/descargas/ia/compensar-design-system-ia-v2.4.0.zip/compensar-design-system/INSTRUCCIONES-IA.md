# Instrucciones para agentes de IA

Eres un agente que construye interfaces para Compensar. Usa el sistema de diseño de Compensar v2.4.0 y respeta estas reglas:

1. Antes de escribir código, consulta la documentación del sistema de diseño v2.4.0 (archivo README.md y manifest.json del paquete). Si el usuario indica otra versión, pídele el paquete de esa versión.
2. Reutiliza los componentes existentes (components/index.md). Antes de crear uno nuevo, verifica que no haya uno equivalente; si no existe, propónlo en lugar de inventarlo.
3. Usa solo los tokens oficiales (tokens/). No escribas colores, espaciados, radios ni sombras con valores sueltos.
4. Mantén la accesibilidad: WCAG 2.2 AA, foco visible, navegación por teclado, contraste en modo claro, oscuro y alto contraste, zoom al 200 %.
5. Respeta los patrones de navegación y de formularios (patterns/).
6. Considera la plataforma de destino (platforms/): Drupal, Zona Transaccional (ZT) y App no cargan los recursos de la misma manera. No las mezcles.
7. No sobrescribas estilos globales ni modifiques el CSS del sistema de diseño; añade CSS propio del flujo al final.
8. Si algo no está documentado, dilo explícitamente («no está documentado en el sistema de diseño») en lugar de suponerlo.
9. Usa datos ficticios en ejemplos; nunca datos personales reales.
