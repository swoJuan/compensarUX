# Drupal

Prototipos del portal web institucional.

- Tecnología: HTML, CSS y JavaScript
- Sistema de diseño de referencia: v2.4.0

## Paquete web `compensar-drupal`

Versión publicada: v1.0.0. No incluye el sistema de diseño: cárgalo antes. Compatibilidad registrada con el sistema de diseño: no hay una matriz registrada; se publica junto a v2.4.0.

| Archivo | Tamaño (bytes) | integrity (SRI) |
| --- | --- | --- |
| `compensar-drupal.min.css` | 18505 | `sha384-O7hlw/QIirIjV7yd9kVqcX/Rx/BP24f8bEBVYfOjGQyEcyugSunkDwKTj/DUuR3l` |
| `compensar-drupal.min.js` | 12105 | `sha384-naJtPMw/AksRZcZy/ibLu/HJjrDKY3krWiBZ9l9UwsG1MMlsobtNifFo44RUKR+g` |


### Orden de carga

```html
<!-- 1. Sistema de diseño -->
<link rel="stylesheet" href="https://stappmedprepdeveus2.z20.web.core.windows.net/sitio/cdn/compensar/v2.4.0/compensar.min.css">
<!-- 2. Paquete DRUPAL -->
<link rel="stylesheet" href="https://stappmedprepdeveus2.z20.web.core.windows.net/sitio/cdn/compensar-drupal/v1.0.0/compensar-drupal.min.css">
<!-- 3. CSS propio del flujo -->
<link rel="stylesheet" href="css/mi-pantalla.css">
<script src="https://stappmedprepdeveus2.z20.web.core.windows.net/sitio/cdn/compensar/v2.4.0/compensar.min.js" defer></script>
<script src="https://stappmedprepdeveus2.z20.web.core.windows.net/sitio/cdn/compensar-drupal/v1.0.0/compensar-drupal.min.js" defer></script>
```

## Flujos publicados

- Navegación del portal
