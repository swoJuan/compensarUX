# Aplicación móvil

Representación web navegable de la aplicación móvil.

- Tecnología: Referencia para .NET MAUI
- Sistema de diseño de referencia: v2.5.0

## Paquete web `compensar-app`

Versión publicada: v1.0.0. No incluye el sistema de diseño: cárgalo antes. Compatibilidad registrada con el sistema de diseño: no hay una matriz registrada; se publica junto a v2.5.0.

| Archivo | Tamaño (bytes) | integrity (SRI) |
| --- | --- | --- |
| `compensar-app.min.css` | 14581 | `sha384-v/M6U31qjpPQeinLHcSVX2+Zkid4wMnO+AbhYem46vpzjUMTEwjv7Away9p24CZ7` |
| `compensar-app.min.js` | 481 | `sha384-YBXP3b9E4frSpmynx5cJ6/StaG9EDNTwofe5RaZnWYyv9gKeMPWAdYV6yDpRkadv` |


### Orden de carga

```html
<!-- 1. Sistema de diseño -->
<link rel="stylesheet" href="https://stappmedprepdeveus2.z20.web.core.windows.net/sitio/cdn/compensar/v2.5.0/compensar.min.css">
<!-- 2. Paquete APP -->
<link rel="stylesheet" href="https://stappmedprepdeveus2.z20.web.core.windows.net/sitio/cdn/compensar-app/v1.0.0/compensar-app.min.css">
<!-- 3. CSS propio del flujo -->
<link rel="stylesheet" href="css/mi-pantalla.css">
<script src="https://stappmedprepdeveus2.z20.web.core.windows.net/sitio/cdn/compensar/v2.5.0/compensar.min.js" defer></script>
<script src="https://stappmedprepdeveus2.z20.web.core.windows.net/sitio/cdn/compensar-app/v1.0.0/compensar-app.min.js" defer></script>
```

## Recursos para .NET MAUI

La aplicación móvil no consume CSS ni JavaScript. Los recursos nativos son diccionarios XAML generados de los tokens:

- `Resources/Styles/Compensar.Colors.xaml`
- `Resources/Styles/Compensar.Sizes.xaml`

```
Sistema de diseño de Compensar — .NET MAUI
commit-8a4b4cb · generado de tokens/compensar.tokens.json

Qué trae
  Resources/Styles/Compensar.Colors.xaml  Los colores del sistema.
  Resources/Styles/Compensar.Sizes.xaml   Espaciados y medidas, como x:Double.

Cómo usarlo — en App.xaml:
  <Application.Resources>
    <ResourceDictionary>
      <ResourceDictionary.MergedDictionaries>
        <ResourceDictionary Source="Resources/Styles/Compensar.Colors.xaml" />
        <ResourceDictionary Source="Resources/Styles/Compensar.Sizes.xaml" />
      </ResourceDictionary.MergedDictionaries>
    </ResourceDictionary>
  </Application.Resources>

Cada color va dos veces: la clave normal es el modo claro y la misma clave
terminada en _Dark es el modo oscuro, para usarlas juntas:

  <Setter Property="BackgroundColor"
          Value="{AppThemeBinding Light={StaticResource UseBackgroundPage},
                                  Dark={StaticResource UseBackgroundPage_Dark}}" />

El modo de alto contraste de la web no está aquí: MAUI solo distingue claro y oscuro.
Los archivos se generan en cada publicación del portal. No los edites a mano: los
cambios se hacen en los tokens del sistema de diseño.
```

## Flujos publicados

- Inicio de la APP
- Historia clínica (APP)
- Efecto Swap (APP)
