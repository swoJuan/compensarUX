# Zona Transaccional

Flujos y pantallas de la oficina virtual.

- Tecnología: Referencia para Angular
- Sistema de diseño de referencia: v2.5.0

## Paquete web `compensar-zt`

Versión publicada: v1.0.0. No incluye el sistema de diseño: cárgalo antes. Compatibilidad registrada con el sistema de diseño: no hay una matriz registrada; se publica junto a v2.5.0.

| Archivo | Tamaño (bytes) | integrity (SRI) |
| --- | --- | --- |
| `compensar-zt.min.css` | 44211 | `sha384-zm+LVARNDZaP0Fqc3AZZVX2LDoG1V9mk4H19LE5NPwW9Rb5uTilHw8CuQd5i+qop` |
| `compensar-zt.min.js` | 65761 | `sha384-XQOUfsZ/RG/bm4k+bog/uBzC0cLK6g/gKOf8sywcBdAnSRudejRvBgMarmUl/50T` |


### Orden de carga

```html
<!-- 1. Sistema de diseño -->
<link rel="stylesheet" href="https://stappmedprepdeveus2.z20.web.core.windows.net/sitio/cdn/compensar/v2.5.0/compensar.min.css">
<!-- 2. Paquete ZT -->
<link rel="stylesheet" href="https://stappmedprepdeveus2.z20.web.core.windows.net/sitio/cdn/compensar-zt/v1.0.0/compensar-zt.min.css">
<!-- 3. CSS propio del flujo -->
<link rel="stylesheet" href="css/mi-pantalla.css">
<script src="https://stappmedprepdeveus2.z20.web.core.windows.net/sitio/cdn/compensar/v2.5.0/compensar.min.js" defer></script>
<script src="https://stappmedprepdeveus2.z20.web.core.windows.net/sitio/cdn/compensar-zt/v1.0.0/compensar-zt.min.js" defer></script>
```

El menú lateral de ZT necesita declarar la ruta a la raíz del flujo: `<nav class="sidebar" data-zt-root="../../">`.

## Flujos publicados

- Oficina virtual (inicio ZT)
- Agendamiento de citas
- Solicitud de historia clínica
- Ventas y afiliación
