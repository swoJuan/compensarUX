# Radios y sombras

## Radios

| Token | Variable CSS | Valor |
| --- | --- | --- |
| `border-radius/xs` | `--border-radius-xs` | 8px |
| `border-radius/sm` | `--border-radius-sm` | 16px |
| `border-radius/md` | `--border-radius-md` | 24px |
| `border-radius/lg` | `--border-radius-lg` | 32px |


## Sombras

Fuente: `core/abstracts/_tokens-shadows.scss`.

| Variable SCSS | Valor | Uso |
| --- | --- | --- |
| `$shadow-1` | `0.125rem 0.3125rem 1rem rgba(0, 0, 0, 0.15)` | 2px 5px 16px · cards estaticas |
| `$shadow-2` | `0 0.5rem 1.5rem rgba(0, 0, 0, 0.15)` | 0px 8px 24px · dropdowns, popovers |
| `$shadow-3` | `0 1rem 2.5rem rgba(0, 0, 0, 0.20)` | 0px 16px 40px · modales |
| `$shadow-4` | `0 1.25rem 3.125rem rgba(0, 0, 0, 0.20)` | 0px 20px 50px · drawers |
| `$shadow-header` | `0 0.25rem 0.25rem rgba(0, 0, 0, 0.25)` | 0px 4px 4px |
| `$shadow-btn-hover` | `0.125rem 0.125rem 0.1875rem rgba(255, 157, 92, 1)` | 2px 2px 3px |
| `$shadow-btn-especial-hover` | `0.125rem 0.125rem 0.1875rem rgba(162, 141, 218, 1)` | 2px 2px 3px |
| `$shadow-btn-pressed` | `inset 0 0.25rem 0.25rem rgba(0, 0, 0, 0.25)` | 0px 4px 4px |
| `$shadow-card` | `$shadow-1` |  |
| `$shadow-dropdown` | `$shadow-2` |  |
| `$shadow-modal` | `$shadow-3` |  |
| `$shadow-drawer` | `$shadow-4` |  |
