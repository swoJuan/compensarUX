# Breakpoints

Fuente: `$grid-breakpoints` en `core/abstracts/_variables.scss` (iguales a Bootstrap).

| Nombre | Desde |
| --- | --- |
| `xs` | `0` |
| `sm` | `576px` |
| `md` | `768px` |
| `lg` | `992px` |
| `xl` | `1200px` |
| `xxl` | `1400px` |


Reglas de uso: ver `patterns/responsive-breakpoints.md`.
