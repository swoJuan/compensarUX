# Espaciado

Variables CSS publicadas en `css/core.css` v2.5.0: `--space-N` (N en píxeles). Base de 8 px; también hay pasos de 2, 4 y 10 px.

| Variable CSS | Valor |
| --- | --- |
| `--space-0` | `0` |
| `--space-2` | `0.125rem` |
| `--space-4` | `0.25rem` |
| `--space-8` | `0.5rem` |
| `--space-10` | `0.625rem` |
| `--space-12` | `0.75rem` |
| `--space-16` | `1rem` |
| `--space-24` | `1.5rem` |
| `--space-32` | `2rem` |
| `--space-40` | `2.5rem` |
| `--space-48` | `3rem` |
| `--space-56` | `3.5rem` |
| `--space-64` | `4rem` |
| `--space-72` | `4.5rem` |
| `--space-80` | `5rem` |
| `--space-96` | `6rem` |
| `--space-128` | `8rem` |


> Nota de consistencia: `tokens/compensar.tokens.json` declara 15 tokens de espaciado como `--spacing-Npx`, pero el CSS publicado usa `--space-N`. Usa `--space-N`.
