# Tipografía

Fuente: `core/abstracts/_tokens-typography.scss` (variables SCSS). Los valores se copian tal cual; el comentario es el de la fuente.

| Variable SCSS | Valor | Nota |
| --- | --- | --- |
| `$font-heading` | `'Roboto', sans-serif` |  |
| `$font-body` | `'Roboto', sans-serif` |  |
| `$font-code` | `'Roboto Mono', monospace` |  |
| `$fs-display-l` | `3.5rem` | 56px |
| `$fs-display-m` | `3rem` | 48px |
| `$fs-display-mob-xl` | `2.5rem` | 40px |
| `$fs-display-mob-l` | `2.25rem` | 36px |
| `$fs-display-mob-m` | `2rem` | 32px |
| `$fs-h1` | `3rem` | 48px |
| `$fs-h2` | `2.5rem` | 40px |
| `$fs-h3` | `2.25rem` | 36px |
| `$fs-h4` | `1.75rem` | 28px |
| `$fs-h5` | `1.5rem` | 24px |
| `$fs-h6` | `1.125rem` | 18px |
| `$fs-eyebrow` | `1.125rem` | 18px |
| `$fs-paragraph-xl` | `1.125rem` | 18px |
| `$fs-paragraph-l` | `1rem` | 16px |
| `$fs-body-2xl` | `1.5rem` | 24px |
| `$fs-body-xl` | `1.125rem` | 18px |
| `$fs-body-l` | `1rem` | 16px — base |
| `$fs-body-m` | `0.875rem` | 14px |
| `$fs-body-s` | `0.75rem` | 12px |
| `$fs-body-xs` | `0.625rem` | 10px |
| `$fs-button` | `1rem` | 16px |
| `$fs-label` | `1rem` | 16px |
| `$fs-hint` | `0.875rem` | 14px |
| `$fs-placeholder` | `1rem` | 16px |
| `$fw-regular` | `400` |  |
| `$fw-medium` | `500` |  |
| `$fw-bold` | `700` |  |
| `$fw-black` | `900` |  |
| `$lh-display-l` | `1.1` |  |
| `$lh-display-m` | `1.2` |  |
| `$lh-display-mob` | `1.1` |  |
| `$lh-h1-h4` | `1.2` |  |
| `$lh-h5-h6` | `1.3` |  |
| `$lh-eyebrow` | `1.3` |  |
| `$lh-paragraph` | `1.5` |  |
| `$lh-body` | `1.3` |  |
| `$lh-body-m` | `1.5` |  |
| `$lh-ui` | `1.0` |  |
| `$ls-eyebrow` | `0.1em` |  |
| `$ls-label` | `0.08em` |  |
| `$ls-normal` | `normal` |  |


Clases tipográficas del sistema (`mp-h1`…`mp-h6`, `mp-body-*`): ver `foundations/typography.md`.
