Fundamentos

# Border radius

Define el nivel de redondeo aplicado a los componentes del sistema. El uso consistente del radio ayuda a mantener coherencia visual, identidad de producto y uniformidad entre superficies y componentes.

**El objetivo es:** Coherencia visual, identidad y consistencia entre superficies

## Escala recomendada

El sistema utiliza una escala simple de radios para evitar variaciones arbitrarias entre componentes.

border-radius
radius-xs
0.5rem
radius-sm
1rem
radius-md
1.5rem
radius-lg
2rem

Esta escala cubre la mayoría de los casos de uso dentro del sistema. Evitar valores intermedios fuera de esta escala.

## Uso recomendado

Cada nivel de radio corresponde a un tipo de componente específico.

### Recomendaciones

Radio Uso
0.5rem (8px) elementos pequeños, inputs compactos
1rem (16px) botones, inputs, controles de formulario
1.5rem (24px) cards, modales, contenedores principales
2rem (32px) superficies grandes o componentes destacados

Esto mantiene coherencia entre los distintos tipos de superficies.

## Componentes comunes

Ejemplos de aplicación dentro del sistema:

Componente Radio recomendado
Inputs 1rem (16px)
Botones 1rem (16px)
Cards 1.5rem (24px)
Modales 1.5rem (24px)
Chips 2rem (32px)
Badges 2rem (32px)

Esto mantiene coherencia entre los distintos tipos de superficies.

* Label
Texto de apoyo

Reglas

- No usar valores de radio arbitrarios.
- Mantener consistencia dentro de un mismo componente.
- Evitar radios diferentes dentro de un mismo bloque visual.
- Priorizar radios moderados para interfaces transaccionales.
- Mantener consistencia entre estados (default, hover, focus).

## Accesibilidad

El radio no debe afectar la legibilidad ni la claridad visual de los componentes.

**Reglas generales:**

- Evitar radios extremos en componentes críticos.
- Mantener consistencia entre estados interactivos.
- Asegurar que el radio no interfiera con el área táctil del componente.

```html
/* Border radius tokens — Compensar */

/* Escala */
--radius-xs: 0.5rem;  /* 8px · Elementos pequeños, inputs compactos  */
--radius-sm: 1rem;    /* 16px · Botones, inputs, controles           */
--radius-md: 1.5rem;  /* 24px · Cards, modales, contenedores         */
--radius-lg: 2rem;    /* 32px · Chips, badges, superficies grandes   */

/* Uso */
.btn         { border-radius: var(--radius-sm); }  /* 1rem = 16px */
.input       { border-radius: var(--radius-sm); }  /* 1rem = 16px */
.card        { border-radius: var(--radius-md); }  /* 1.5rem = 24px */
.modal       { border-radius: var(--radius-md); }  /* 1.5rem = 24px */
.chip, .badge{ border-radius: var(--radius-lg); }  /* 2rem = 32px */
html
// Border radius — App (SCSS)
// Los tokens viven en :root como CSS custom props

.cmp-button  { border-radius: var(--radius-sm); }  // 1rem = 16px
.cmp-input   { border-radius: var(--radius-sm); }  // 1rem = 16px
.cmp-card    { border-radius: var(--radius-md); }  // 1.5rem = 24px
.cmp-modal   { border-radius: var(--radius-md); }  // 1.5rem = 24px
.cmp-chip,
.cmp-badge   { border-radius: var(--radius-lg); }  // 2rem = 32px

// Nunca usar valores arbitrarios como border-radius: 10px
```

> Fuente: `docs/transversales/fundamentos/border-radius.html` · v2.5.0
