Fundamentos

# Layout System

Estructura macro de las interfaces. Bootstrap 5 · 12 columnas · Gutter 24px · Totalmente responsive.

Bootstrap 5 12 columnas Gutter 24px Responsive

## Base estructural

12 columnas
24px gutter
B5 Bootstrap

- ✓ No modificar cantidad de columnas
- ✓ No crear grids fuera del sistema
- ✓ Siempre respetar el gutter de 24px

123456 789101112

## Container

Elige el tipo de container según el contexto de uso.

Portal · Drupal

### .container

Ancho máximo · centrado automáticamente

container
max-width

- Landings y páginas informativas
- Contenido editorial
- Secciones de marketing

Anchos máximos
SM`540px`
MD`720px`
LG`960px`
XL`1140px`
XXL`1320px`
VS
Zona transaccional

### .container-fluid

100% del ancho · sin límite

container-fluid
100% del ancho

- Formularios extensos
- Tablas de datos
- Paneles administrativos

En desktop mantener jerarquía visual clara y alineación a la izquierda.
Landings .container
Contenido editorial .container
Tablas de datos .container-fluid
Paneles admin .container-fluid
Formularios extensos .container-fluid
Secciones marketing .container

## Reglas clave

✓

Usar `.container` para centrar contenido con max-width

✗

No usar anchos arbitrarios (`width: 56.25rem`, etc.)

✓

Usar `.container-fluid` en interfaces operativas y dashboards

✗

No mezclar containers sin intención ni documentar el motivo

✓

Siempre usar `.row` + `.col-*` para la distribución interna

✗

No crear grids personalizados con CSS fuera del sistema Bootstrap

## Responsive — breakpoints

El layout responde por breakpoints, no por dispositivos específicos.

xs < 576px Móvil pequeño
sm ≥ 576px Móvil grande
md ≥ 768px Tablet
lg ≥ 992px Desktop sm
xl ≥ 1200px Desktop std
xxl ≥ 1400px Desktop amplio
Mobile 1 columna `col-12`
→
Tablet 2 columnas `col-md-6`
→
Desktop 3–4 columnas `col-xl-4`

## Validación rápida

1
**Revisar dispositivos clave** Mobile 375px · Tablet 820px · Desktop 1280px como base de QA.
2
**Sin scroll horizontal** En ningún breakpoint. Bloqueante para aprobación.
3
**Usar DevTools responsive** F12 → modo dispositivo → cambiar viewports manualmente
4
**Respetar grilla de 12 col** Activar grid overlay para verificar alineación
5
**Probar con contenido real** No usar Lorem ipsum. Textos largos y cortos.
6
**iOS Safari obligatorio** Inputs ≥ 16px para evitar zoom automático
Recomendado QA · iPhone SE · 375px
iPhone 14 · 393px
Recomendado tablet · iPad Air · 820px
Recomendado desktop · Laptop 1280px
Monitor 1920px

```html
<!-- Portal (Drupal) — contenido centrado -->
<div class="container">
  <div class="row">
    <div class="col-12 col-md-6 col-xl-4">
      <!-- Contenido -->
    </div>
  </div>
</div>

<!-- Zona transaccional — ancho completo -->
<div class="container-fluid">
  <div class="row">
    <div class="col-12 col-md-3"><!-- Sidebar --></div>
    <div class="col-12 col-md-9"><!-- Contenido --></div>
  </div>
</div>
html
// Angular — en el template del componente

// Landing o sección informativa
<section class="container">
  <div class="row">
    <div class="col-12 col-md-4"
         *ngFor="let item of items">
      <app-card [data]="item" />
    </div>
  </div>
</section>

// Dashboard / zona transaccional
<main class="container-fluid">
  <div class="row">
    <aside class="col-md-3"><app-sidebar /></aside>
    <div   class="col-md-9"><router-outlet /></div>
  </div>
</main>
```

> Fuente: `docs/transversales/fundamentos/layout.html` · v2.5.0
