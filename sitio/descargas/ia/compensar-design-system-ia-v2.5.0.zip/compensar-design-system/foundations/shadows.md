1.4

# Sombras

Tokens de elevación e interacción. Comunican profundidad y respuesta táctil sin usar bordes. Siempre usar el token — nunca valores hardcoded.

Nunca escribir `box-shadow: 0 0.5rem 1.5rem ... /* 0px 8px 24px */` directo. Siempre `var(--shadow-2)`.   Ver en Figma
Elevación

Jerarquía de profundidad para superficies. A mayor número, mayor elevación percibida.

Tarjeta
Nivel 1
Shadow 1
Tarjetas, contenedores base
`--shadow-1`
`0.125rem 0.3125rem 1rem rgba(0,0,0,0.15) /* 2px 5px 16px */`
Modal
Nivel 2
Shadow 2
Modales, dropdowns, popovers
`--shadow-2`
`0 0.5rem 1.5rem rgba(0,0,0,0.15) /* 0px 8px 24px */`
Drawer
Nivel 3
Shadow 3
Drawers, sidebars, paneles laterales
`--shadow-3`
`0 1rem 2.5rem rgba(0,0,0,0.2) /* 0px 16px 40px */`
Overlay
Nivel 4
Shadow 4
Menús flotantes, overlays máximos
`--shadow-4`
`0 1.25rem 3.125rem rgba(0,0,0,0.2) /* 0px 20px 50px */`
Componentes UI

Sombras específicas de la shell de la aplicación.

Header
Barra de navegación fija superior
`--shadow-header`
`0 0.25rem 0.25rem rgba(0,0,0,0.25) /* 0px 4px 4px */`
Sombra 1 alias
Alias genérico — mismo valor que `--shadow-header`
`--sombra-1`
`0 0.25rem 0.25rem rgba(0,0,0,0.25) /* 0px 4px 4px */`
Interacción — Botones

Respuesta visual a estados de hover y pressed. Refuerzan el feedback táctil del componente.

Botón hover
Botón primario naranja — estado hover
`--shadow-btn-hover`
`0.125rem 0.125rem 0.1875rem rgba(255,157,92,1) /* 2px 2px 3px */`
Botón especial hover
Botón especial violeta — estado hover
`--shadow-button-special-hover`
`0.125rem 0.125rem 0.1875rem rgba(162,141,218,1) /* 2px 2px 3px */`
Botón pressed
Cualquier botón — estado activo / presionado
`--shadow-button-pressed`
`inset 0 0.25rem 0.25rem rgba(0,0,0,0.25) /* 0px 4px 4px */`
Uso en código

```html
/* Tarjeta básica */
.card {
  box-shadow: var(--shadow-1);
  transition: box-shadow 0.2s ease;
}
.card:hover {
  box-shadow: var(--shadow-2);
}

/* Modal / Diálogo */
.modal {
  box-shadow: var(--shadow-3);
}

/* Header fijo */
.site-header {
  box-shadow: var(--shadow-header);
}

/* Botones con estados */
.btn-primary:hover   { box-shadow: var(--shadow-btn-hover); }
.btn-primary:active  { box-shadow: var(--shadow-button-pressed); }
.btn-especial:hover  { box-shadow: var(--shadow-button-special-hover); }
html
// Tarjeta básica
.cmp-card {
  box-shadow: var(--shadow-1);
  transition: box-shadow 0.2s ease;

  &:hover { box-shadow: var(--shadow-2); }
}

// Modal Angular Material override
.mat-dialog-container {
  box-shadow: var(--shadow-3) !important;
}

// Botón con estados
.cmp-btn--primary {
  &:hover  { box-shadow: var(--shadow-btn-hover); }
  &:active { box-shadow: var(--shadow-button-pressed); }
}

.cmp-btn--especial {
  &:hover { box-shadow: var(--shadow-button-special-hover); }
}
```

> Fuente: `docs/transversales/fundamentos/shadows.html` · v2.5.0
