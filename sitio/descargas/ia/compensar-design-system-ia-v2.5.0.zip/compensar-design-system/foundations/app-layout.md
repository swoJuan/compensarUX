Fundamentos App

# Layout System MAUI

Guía de rejilla para .NET MAUI. En App usamos maximo 4 columnas y el contenido se redistribuye por zonas segun el ancho disponible.

.NET MAUI Grid Spacing 16dp Adaptive

## Base estructural App

4 columnas
16dp separación base
Grid layout core

- ✓ Maximo 4 columnas en todos los anchos
- ✓ Compacto: contenido en 1 columna
- ✓ Medio/expandido: 2 a 4 columnas segun prioridad

1234

## Rejillas por contexto MAUI

En App no usamos container/container-fluid. El comportamiento se define por ancho disponible y cambio de columnas del Grid.

Compacto y medio

### 1 a 4 columnas

Pantallas de teléfono y tablet en portrait

Grid.ColumnDefinitions
1 a 2 columnas de contenido

- Forms y flujos de captura
- Listados con tarjetas
- Resumenes por bloques

→
Expandido

### Maximo 4 columnas

Tablet landscape, escritorio o ventanas amplias

Panel + contenido + soporte
Hasta 3 zonas simultáneas

- Master-detail
- Tablas o grillas densas
- Flujos con panel lateral

En expandido conservar max-width de contenido principal para no perder legibilidad.
Login y onboarding 4 columnas
Formularios 1-4 columnas
Listado de cards 2 columnas en medium
Tablet landscape 4 columnas
Master-detail 3 zonas
Desktop MAUI 4 + zonas adaptadas

## Reglas clave de implementación

✓

Definir layout base con `Grid` (filas y columnas), no con posiciones absolutas.

✗

No fijar anchos en px para contenedores principales.

✓

Usar spacing en múltiplos de 4dp y mantener base de 16dp entre bloques.

✗

No mezclar márgenes y paddings arbitrarios por pantalla.

✓

Respetar Safe Area en iOS y separación de barras del sistema en Android.

✗

No aprobar pantallas con clipping, solapamientos o scroll horizontal.

## Rangos recomendados para App

Las revisiones se hacen por ancho lógico (dp), no solo por nombre de dispositivo.

compact < 600dp Teléfono portrait
medium 600–839dp Tablet portrait / foldable
expanded ≥ 840dp Tablet landscape / desktop
Compact 1 columna de contenido `hasta 4 columnas`
→
Medium 2 columnas de contenido `hasta 4 columnas`
→
Expanded hasta 3 zonas funcionales `hasta 4 columnas`

## QA de estilos en App

1
**Revisión por perfil de ancho** Validar compact, medium y expanded en portrait y landscape.
2
**Sin clipping ni overlap** Texto, íconos y CTAs no deben recortarse ni montarse.
3
**Consistencia de spacing** Comprobar separaciones base de 16dp y submúltiplos de 8/4dp.
4
**Tema y contraste** Probar claro, oscuro y alto contraste con foco visible.
5
**Accesibilidad tipográfica** Escalar fuente del sistema y validar reflow sin cortes.
6
**Evidencia QA** Captura por cada perfil (compact/medium/expanded) con check de estados.
Recomendado · iPhone 14 (390x844 pt)
Recomendado · Pixel 7 (412x915 dp)
Recomendado · iPad 11" portrait (834x1194)
Recomendado · iPad 11" landscape (1194x834)
Opcional desktop · Windows 1366x768+

```html
<!-- MAUI: layout base de pantalla -->
<Grid
  Padding="16"
  ColumnSpacing="16"
  RowSpacing="16"
  RowDefinitions="Auto,*"
  ColumnDefinitions="*,*">

  <Label Grid.ColumnSpan="2" Text="Resumen" />

  <Border Grid.Row="1" Grid.Column="0" />
  <Border Grid.Row="1" Grid.Column="1" />

</Grid>

<!-- Regla: en compacto usar una sola columna de contenido -->
<!-- Regla: en expanded dividir en 2 o 3 zonas segun flujo -->
html
// MAUI code-behind: cambiar columnas segun ancho disponible
protected override void OnSizeAllocated(double width, double height)
{
    base.OnSizeAllocated(width, height);

    int cols = width < 600 ? 1 : (width < 840 ? 2 : 4);

    ContentGrid.ColumnDefinitions.Clear();
    for (int i = 0; i < cols; i++)
        ContentGrid.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Star));

    ContentGrid.ColumnSpacing = 16;
    ContentGrid.RowSpacing    = 16;
}

// QA: registrar capturas en compact/medium/expanded y ambos temas
```

> Fuente: `docs/app/fundamentos/layout.html` · v2.5.0
