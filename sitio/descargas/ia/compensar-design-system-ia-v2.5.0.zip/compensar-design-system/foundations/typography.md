1.3

# Tipografía

El sistema usa exclusivamente **Roboto **en todos los contextos. Base tipográfica:** 1rem = 16px**. Cada estilo expone tres variables semánticas (`--mp-*-size`, `--mp-*-lh`, `--mp-*-weight`) y una clase CSS (`.mp-*`) lista para producción.

Nunca uses valores hardcoded. Usa `.mp-h1`, `.mp-body-l`, etc., o las variables `var(--mp-h1-size)`.   Ver en Figma

Descarga generada en vivo desde `core/abstracts/_tokens-typography.scss`, `core/base/_typography.scss` y `core/utils/_typography.scss`.

Vista previa
Mostrando tamaños desktop
Familia — Roboto
Roboto
Todas las vistas — titulares, cuerpo, labels y UI
Aa Bb Cc Dd Ee Ff Gg Hh Ii Jj Kk Ll Mm Nn Oo Pp Qq Rr Ss Tt Uu Vv Ww Xx Yy Zz · 0 1 2 3 4 5 6 7 8 9 · ! @ # $ % & ( )
100ThinCompensar Medicina Prepagada
300LightCompensar Medicina Prepagada
400RegularCompensar Medicina Prepagada
500MediumCompensar Medicina Prepagada
700BoldCompensar Medicina Prepagada
900BlackCompensar Medicina Prepagada
Escala tipográfica · base 1rem = 16px

### Utilidades tipográficas (qué hace cada clase)

Guía rápida y visual. Cada tarjeta te dice para qué sirve la clase y muestra una vista previa real. Fuente viva: `core/utils/_typography.scss`.

#### Alineación y formato `.u-text-left .u-fs-* .u-fw-* ...`

Ejemplo directo: `.u-text-left` alinea el texto a la izquierda.

#### Color de texto `.u-text-*`

Cada tarjeta muestra el nombre de la clase y su color aplicado en vista previa.

#### Comportamiento `.u-truncate .u-line-clamp-* ...`

Utilidades para textos largos: recorte con puntos, saltos de línea y quiebre de palabras.

#### Estandar recomendado (uso diario)

Si no sabes que clase usar, empieza con esta tabla. Estas combinaciones cubren la mayoria de pantallas sin romper consistencia.

| Caso | Clases ideales | Ejemplo rapido |
| --- | --- | --- |
| Parrafo principal | `.u-fs-md .u-lh-relaxed .u-text-primary` | `<p class="u-fs-md u-lh-relaxed u-text-primary">...</p>` |
| Texto secundario / apoyo | `.u-fs-sm .u-text-muted` | `<p class="u-fs-sm u-text-muted">...</p>` |
| Titulo de card o bloque | `.u-fw-bold .u-text-primary` | `<h3 class="u-fw-bold u-text-primary">...</h3>` |
| Label de formulario | `.u-uppercase .u-fw-bold .u-fs-sm` | `<label class="u-uppercase u-fw-bold u-fs-sm">...</label>` |
| Enlace dentro de texto | `.u-text-link` | `<a class="u-text-link" href="#">...</a>` |
| Titulo largo en listado | `.u-line-clamp-2` | `<h4 class="u-line-clamp-2">...</h4>` |
| Texto de una linea en tabla | `.u-truncate` | `<span class="u-truncate">...</span>` |
| Contenido con palabras largas | `.u-break-word` | `<p class="u-break-word">...</p>` |

/g,'>'); } function renderItem(item){ const clsId = item.cls.replace(/-/g,'_'); const cssSnippet = `.${item.cls} {\n font-size: var(--${item.cls}-size); /* ${item.desk.rem} / ${item.desk.px}px */\n font-weight: var(--${item.cls}-weight); /* ${item.w} */\n line-height: var(--${item.cls}-lh); /* ${item.lh} */\n font-family: var(--font-body);\n${item.extra ? ' '+item.extra.replace(/;(\s*)/g,';\n ').trim()+'\n' : ''} color: var(${item.color});\n}`; const clampSnippet = `.${item.cls} {\n font-size: ${item.clamp};\n font-weight: ${item.w};\n line-height: ${item.lh};\n font-family: var(--font-body);\n color: var(${item.color});\n}`; return `
${item.preview}
${item.name}
Tamaño desk ${item.desk.rem} / ${item.desk.px}px
${item.desk.rem !== item.mob.rem ? `
Tamaño app ${item.mob.rem} / ${item.mob.px}px
` : ''}
Grosor ${item.w} ${item.wn}
Line height ${item.lh}
Figma `${item.token}`
Size `--${item.cls}-size`
Weight `--${item.cls}-weight`
LH `--${item.cls}-lh`
Clase `.${item.cls}`
${item.clamp !== item.desk.rem ? `
clamp() `${item.clamp}`
` : ''}
HTML

```html
${escape(item.html)}
```

CSS vars

```html
${escape(cssSnippet)}
```

${item.desk.rem !== item.mob.rem ? `
CSS clamp()

```html
${escape(clampSnippet)}
```

` : ''}
`; } function tyToggleCode(id){ const tog = document.getElementById('code-tog-'+id); const pan = document.getElementById('code-pan-'+id); tog.classList.toggle('open'); pan.classList.toggle('open'); } window.tyToggleCode = tyToggleCode; function renderAll(){ const root = document.getElementById('ty-scale-root'); if(!root) return; let html = '
'; CATS.forEach(cat=>{ html += `
${cat.title} ${cat.desc}
`; cat.items.forEach(item=>{ html += renderItem(item); }); html += '
'; }); html += '
'; root.innerHTML = html; } renderAll(); /* ── Download helpers ────────────────────────────────── */ const TY_DIRECT_DOC = location.pathname.includes('/docs/'); const CORE_TYPO_TOKENS_URL = TY_DIRECT_DOC ? '../../../core/abstracts/_tokens-typography.scss' : 'core/abstracts/_tokens-typography.scss'; const CORE_TYPO_CLASSES_URL = TY_DIRECT_DOC ? '../../../core/base/_typography.scss' : 'core/base/_typography.scss'; const CORE_TYPO_UTILS_URL = TY_DIRECT_DOC ? '../../../core/utils/_typography.scss' : 'core/utils/_typography.scss'; const TY_SASS_SIZE_MAP = { 'mp-display-l': 'fs-display-l', 'mp-display-m': 'fs-display-m', 'mp-display-xl-mob': 'fs-display-mob-xl', 'mp-display-l-mob': 'fs-display-mob-l', 'mp-display-m-mob': 'fs-display-mob-m', 'mp-h1': 'fs-h1', 'mp-h2': 'fs-h2', 'mp-h3': 'fs-h3', 'mp-h4': 'fs-h4', 'mp-h5': 'fs-h5', 'mp-h6': 'fs-h6', 'mp-eyebrow': 'fs-eyebrow', 'mp-parrafo-xl': 'fs-paragraph-xl', 'mp-parrafo-l': 'fs-paragraph-l', 'mp-body-2xl': 'fs-body-2xl', 'mp-body-xl': 'fs-body-xl', 'mp-body-l': 'fs-body-l', 'mp-body-m': 'fs-body-m', 'mp-body-s': 'fs-body-s', 'mp-body-xs': 'fs-body-xs', 'mp-btn': 'fs-button', 'mp-label': 'fs-label', 'mp-hint': 'fs-hint', 'mp-placeholder': 'fs-placeholder' }; async function tyReadCoreSource(url){ try { const res = await fetch(url); return res.ok ? await res.text() : ''; } catch (_) { return ''; } } function tyParseSassVars(source){ const vars = {}; source.replace(/^\$([a-z0-9-]+):\s*([^;]+);/gim, (_, name, value)=>{ vars[name] = value.trim(); return ''; }); return vars; } function tyRemToPx(value){ const rem = Number.parseFloat(String(value).replace('rem','')); return Number.isFinite(rem) ? Math.round(rem * 16) : null; } async function tyGetLiveCats(){ const [tokensSource, classesSource] = await Promise.all([ tyReadCoreSource(CORE_TYPO_TOKENS_URL), tyReadCoreSource(CORE_TYPO_CLASSES_URL) ]); const sassVars = tyParseSassVars(tokensSource); const cats = CATS.map(cat => ({ ...cat, items: cat.items.map(item => { const sassName = TY_SASS_SIZE_MAP[item.cls]; const size = sassVars[sassName]; const px = size ? tyRemToPx(size) : null; return { ...item, source: { tokens: CORE_TYPO_TOKENS_URL, classes: CORE_TYPO_CLASSES_URL, live: Boolean(size && classesSource.includes(`.${item.cls}`)) }, desk: size && px ? { rem: size, px } : item.desk }; }) })); return cats; } function tyClassifyUtility(className, props, body) { const propNames = props.map(p => p.name); const hasColor = propNames.includes('color'); const hasTypo = propNames.some(name => [ 'text-align', 'text-transform', 'font-weight', 'font-size', 'line-height', 'letter-spacing', 'font-style', 'text-decoration' ].includes(name)); if (hasColor || className.startsWith('u-text-')) return 'color'; if (hasTypo) return 'type'; if (className.startsWith('u-fs-') || className.startsWith('u-fw-') || className.startsWith('u-lh-') || className.startsWith('u-ls-')) return 'type'; if (body.includes('@include')) return 'behavior'; return 'behavior'; } function tyParseUtilitiesFromScss(utilsScss) { const re = /\.([a-z0-9-]+)\s*\{([\s\S]*?)\}/gim; const out = { type: [], color: [], behavior: [] }; let match; while ((match = re.exec(utilsScss)) !== null) { const className = match[1].trim(); const body = match[2].trim(); const props = []; body.replace(/([a-z-]+)\s*:\s*([^;]+);/gim, (_, name, value) => { props.push({ name: name.trim(), value: value.trim() }); return ''; }); const tokenMatch = body.match(/var\((--[^)]+)\)/); const group = tyClassifyUtility(className, props, body); const property = props.length ? props.map(p => p.name).join(', ') : (body.includes('@include') ? 'mixin' : 'regla'); const value = props.length ? props.map(p => p.value).join(' | ') : body.replace(/\s+/g, ' ').trim(); out[group].push({ cls: `.${className}`, token: tokenMatch ? tokenMatch[1] : '—', property, value }); } Object.keys(out).forEach(key => { out[key].sort((a, b) => a.cls.localeCompare(b.cls)); }); return out; } function tyUtilityMeaning(className) { const cls = className.replace(/^\./, ''); if (cls === 'u-text-left') return `${cls} alinea el texto a la izquierda.`; if (cls === 'u-text-center') return `${cls} centra el texto.`; if (cls === 'u-text-right') return `${cls} alinea el texto a la derecha.`; if (/^u-text-(sm|md|lg)-(left|center|right)$/.test(cls)) { const parts = cls.split('-'); return `${cls} alinea el texto en breakpoint ${parts[2]} (${parts[3]}).`; } if (/^u-fs-/.test(cls)) return `${cls} define tamaño de fuente.`; if (/^u-fw-/.test(cls)) return `${cls} define peso tipográfico.`; if (/^u-lh-/.test(cls)) return `${cls} define interlineado.`; if (/^u-ls-/.test(cls)) return `${cls} define espaciado entre letras.`; if (cls === 'u-uppercase') return `${cls} convierte el texto a mayúsculas.`; if (cls === 'u-lowercase') return `${cls} convierte el texto a minúsculas.`; if (cls === 'u-capitalize') return `${cls} pone iniciales en mayúscula.`; if (cls === 'u-normal-case') return `${cls} mantiene capitalización normal.`; if (/^u-text-/.test(cls)) return `${cls} aplica color de texto semántico.`; if (cls === 'u-truncate') return `${cls} recorta texto en una línea con puntos suspensivos.`; if (/^u-line-clamp-/.test(cls)) return `${cls} limita el texto a un número de líneas.`; if (/^u-whitespace-/.test(cls)) return `${cls} controla el manejo de espacios y saltos.`; if (/^u-break-/.test(cls)) return `${cls} controla el quiebre de palabras.`; if (cls === 'u-underline') return `${cls} subraya el texto.`; if (cls === 'u-line-through') return `${cls} tacha el texto.`; if (cls === 'u-no-underline') return `${cls} quita subrayado.`; if (cls === 'u-italic') return `${cls} aplica estilo itálico.`; if (cls === 'u-not-italic') return `${cls} quita estilo itálico.`; return `${cls} aplica una utilidad tipográfica.`; } function tyUtilityPreviewText(group, cls) { if (group === 'behavior') return 'Texto de ejemplo largo para ver cómo se comporta esta utilidad en contenedores reales de interfaz.'; if (group === 'color') return 'Texto de ejemplo con color aplicado'; if (cls === '.u-uppercase') return 'Texto de ejemplo'; return 'Texto de ejemplo de tipografía'; } function tyCopyUtilityClass(cls) { navigator.clipboard.writeText(cls).then(() => { if (typeof showToast === 'function') { showToast('Clase copiada: ' + cls); } }); } function tyRenderUtilityGrid(gridId, items, emptyText, group) { const grid = document.getElementById(gridId); if (!grid) return; if (!items.length) { grid.innerHTML = `
**No hay utilidades en esta categoria**

${emptyText}

`; return; } grid.innerHTML = items.map(item => { const utilityClass = item.cls.replace(/^\./, ''); const previewText = tyUtilityPreviewText(group, item.cls); const meaning = tyUtilityMeaning(item.cls); const previewClass = group === 'color' ? ' ty-util-preview--color' : ''; return `  `; }).join(''); } async function tyRenderUtilitiesFromSource() { try { const utilsScss = await tyReadCoreSource(CORE_TYPO_UTILS_URL); const parsed = tyParseUtilitiesFromScss(utilsScss || ''); const setCount = (id, count) => { const el = document.getElementById(id); if (el) el.textContent = String(count); }; setCount('ty-util-type-count', parsed.type.length); setCount('ty-util-color-count', parsed.color.length); setCount('ty-util-behavior-count', parsed.behavior.length); tyRenderUtilityGrid('ty-util-type-grid', parsed.type, 'Define clases en core/utils/_typography.scss para verlas aqui.', 'type'); tyRenderUtilityGrid('ty-util-color-grid', parsed.color, 'Define clases de color con var(--...) en core/utils/_typography.scss.', 'color'); tyRenderUtilityGrid('ty-util-behavior-grid', parsed.behavior, 'Agrega reglas de truncado, whitespace o word-break en core/utils/_typography.scss.', 'behavior'); } catch (error) { console.warn('Typography utilities rendering skipped:', error); } } window.tyUtilTab = function(btn, panelId) { document.querySelectorAll('.ty-util-tab').forEach(b => b.classList.remove('active')); document.querySelectorAll('.ty-util-panel').forEach(p => p.classList.remove('active')); btn.classList.add('active'); const panel = document.getElementById(panelId); if (panel) panel.classList.add('active'); }; window.tyCopyUtilityClass = tyCopyUtilityClass; function tyDownloadFile(filename, content, type){ const blob = new Blob([content],{type}); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = filename; a.click(); URL.revokeObjectURL(a.href); } function tyToMauiKey(cls){ return cls .replace(/^mp-/, 'Mp-') .split('-') .map(part => part ? part.charAt(0).toUpperCase() + part.slice(1) : '') .join(''); } async function tyDownloadMAUI(){ const cats = await tyGetLiveCats(); const d = new Date().toISOString().split('T')[0]; const lines = [ '?xml version="1.0" encoding="utf-8" ?>', '', ` `, ' ', ' Roboto', ' Roboto', '' ]; cats.forEach(cat => { lines.push(` `); cat.items.forEach(it => { const key = tyToMauiKey(it.cls); lines.push(` ${it.mob.px}`); lines.push(` ${it.lh}`); lines.push(` ${it.w}`); lines.push(` '); lines.push(''); }); }); lines.push(''); tyDownloadFile('Typography.Maui.xaml', lines.join('\n'), 'application/xml'); } function tyBuildUtilitiesCss(utilsScss){ const re = /\.([a-z0-9-]+)\s*\{([\s\S]*?)\}/gim; const lines = []; let match; while ((match = re.exec(utilsScss)) !== null) { const className = match[1].trim(); const body = match[2].trim(); const props = []; body.replace(/([a-z-]+)\s*:\s*([^;]+);/gim, (_, name, value) => { props.push({ name: name.trim(), value: value.trim() }); return ''; }); if (!props.length) continue; lines.push(`.${className} {`); props.forEach(prop => lines.push(` ${prop.name}: ${prop.value};`)); lines.push('}'); } return lines.join('\n'); } async function tyDownloadCSS(){ const [cats, utilsScss] = await Promise.all([ tyGetLiveCats(), tyReadCoreSource(CORE_TYPO_UTILS_URL) ]); const d = new Date().toISOString().split('T')[0]; let lines = [ `/* ════════════════════════════════════════════════════════════════════ TYPOGRAPHY TOKENS — Compensar Medicina Prepagada · Design System v2 ──────────────────────────────────────────────────────────────────── Fuente : Figma · Compensar v2 – Sistema de diseño Generado : ${d} Archivo : typography-tokens.css Fuente : Roboto (Google Fonts) Base rem : 1rem = 16px Core : core/abstracts/_tokens-typography.scss core/base/_typography.scss core/utils/_typography.scss CONTENIDO ───────── 1. Custom properties :root — --mp-h1-size, --mp-h1-lh, --mp-h1-weight… 2. Clases utilitarias .mp-* — .mp-h1, .mp-body-l, .mp-eyebrow… 3. Clamp responsive — font-size: clamp(min, fluid, max) 4. Utilidades .u-* — core/utils/_typography.scss 5. Fuente: @import Google Fonts REGLA DE USO ──────────── ✓

# Título

✓ font-size: var(--mp-h1-size); ✗ Nunca font-size: 32px (valor hardcoded) INSTALACIÓN ─────────── 1. Importar Roboto:  2. Importar tokens:  ════════════════════════════════════════════════════════════════════ */ /* ─── Google Fonts ──────────────────────────────────────────────────── */ @import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,400;0,500;0,700;1,400&display=swap'); /* ───────────────────────────────────────────────────────────────────── 1. CUSTOM PROPERTIES Cada estilo expone 3 variables: -size, -lh (line-height), -weight. ──────────────────────────────────────────────────────────────────── */ :root { --font-body: 'Roboto', sans-serif; --font-code: 'Roboto Mono', monospace; `]; cats.forEach(cat=>{ lines.push(`\n /* ── ${cat.title} */`); cat.items.forEach(it=>{ lines.push(` ${it.token}: ${it.desk.rem};`); lines.push(` --${it.cls}-size: ${it.desk.rem}; /* ${it.desk.px}px */`); lines.push(` --${it.cls}-lh: ${it.lh};`); lines.push(` --${it.cls}-weight: ${it.w}; /* ${it.wn} */`); }); }); lines.push( `} /* ───────────────────────────────────────────────────────────────────── 2. CLASES .mp-* Uso:

## Encabezado

Cada clase aplica las 3 propiedades tipográficas del token. ──────────────────────────────────────────────────────────────────── */`); cats.forEach(cat=>{ lines.push(`\n/* ── ${cat.title} */`); cat.items.forEach(it=>{ const extra = it.extra ? '\n ' + it.extra.replace(/;(\s*)/g,';\n ').trim() : ''; const clamp = it.clamp ? `\n /* Responsive clamp: ${it.clamp} */\n font-size: ${it.clamp};` : ''; lines.push(`.${it.cls} {\n font-size: var(--${it.cls}-size); /* ${it.desk.px}px desktop */${clamp}\n font-weight: var(--${it.cls}-weight);\n line-height: var(--${it.cls}-lh);\n font-family: var(--font-body);${extra}\n}`); }); }); if (utilsScss) { const utilitiesCss = tyBuildUtilitiesCss(utilsScss); if (utilitiesCss) { lines.push( `\n/* ───────────────────────────────────────────────────────────────────── 3. UTILIDADES TIPOGRÁFICAS (.u-*) Generadas desde core/utils/_typography.scss Nota: reglas basadas en mixins (truncate/line-clamp responsive) se conservan en la descarga SCSS para uso completo de Sass. ──────────────────────────────────────────────────────────────────── */`); lines.push(utilitiesCss); } } lines.push('\n/* ── FIN: typography-tokens.css ─── Compensar Medicina Prepagada ── */'); tyDownloadFile('typography-tokens.css', lines.join('\n'), 'text/css'); } async function tyDownloadSCSS(){ const [cats, utilsScss] = await Promise.all([ tyGetLiveCats(), tyReadCoreSource(CORE_TYPO_UTILS_URL) ]); const d = new Date().toISOString().split('T')[0]; let lines = [ `// ════════════════════════════════════════════════════════════════════ // TYPOGRAPHY TOKENS — Compensar Medicina Prepagada · Design System v2 // ──────────────────────────────────────────────────────────────────── // Fuente : Figma · Compensar v2 – Sistema de diseño // Generado : ${d} // Archivo : _typography-tokens.scss // Fuente : Roboto (Google Fonts) // Base rem : 1rem = 16px // Core : core/abstracts/_tokens-typography.scss // core/base/_typography.scss // core/utils/_typography.scss // // CONTENIDO // ───────── // 1. Variables Sass por estilo ($mp-h1-size, $mp-h1-lh, $mp-h1-weight) // 2. Clases CSS listas (.mp-*) // 3. Utilidades .u-* (source core) // // REGLA // ───── // ✓ Usa estas clases o variables // ✗ Evita valores hardcoded // ════════════════════════════════════════════════════════════════════ $font-body: 'Roboto', sans-serif; $font-code: 'Roboto Mono', monospace; `]; lines.push('// ─────────────────────────────────────────────────────────────────────'); lines.push('// 1. VARIABLES SASS'); lines.push('// ─────────────────────────────────────────────────────────────────────'); cats.forEach(cat=>{ lines.push(`\n// ── ${cat.title}`); cat.items.forEach(it=>{ lines.push(`// Figma token: ${it.token}`); lines.push(`$${it.cls}-size: ${it.desk.rem}; // ${it.desk.px}px desktop | móvil: ${it.mob.px}px`); lines.push(`$${it.cls}-lh: ${it.lh};`); lines.push(`$${it.cls}-weight: ${it.w}; // ${it.wn}`); }); }); lines.push('\n// ─────────────────────────────────────────────────────────────────────'); lines.push('// 2. CLASES .mp-* (LISTAS PARA USAR)'); lines.push('// ─────────────────────────────────────────────────────────────────────'); cats.forEach(cat=>{ lines.push(`\n// ── ${cat.title}`); cat.items.forEach(it=>{ lines.push(`.${it.cls} {`); lines.push(` font-size: $${it.cls}-size;`); lines.push(` font-weight: $${it.cls}-weight;`); lines.push(` line-height: $${it.cls}-lh;`); lines.push(` font-family: $font-body;`); if (it.extra) { it.extra.split(';').map(v => v.trim()).filter(Boolean).forEach(rule => { lines.push(` ${rule};`); }); } lines.push(`}`); }); }); if (utilsScss) { lines.push('\n// ─────────────────────────────────────────────────────────────────────'); lines.push('// 3. UTILIDADES .u-* (SOURCE)'); lines.push('// ─────────────────────────────────────────────────────────────────────'); lines.push(utilsScss.trim()); } lines.push('\n// ── FIN: _typography-tokens.scss ─── Compensar Medicina Prepagada ──'); tyDownloadFile('_typography-tokens.scss', lines.join('\n'), 'text/plain'); } async function tyDownloadJSON(){ const [cats, utilsScss] = await Promise.all([ tyGetLiveCats(), tyReadCoreSource(CORE_TYPO_UTILS_URL) ]); const d = new Date().toISOString().split('T')[0]; const categories = {}; cats.forEach(cat=>{ categories[cat.title] = cat.items.map(it=>({ token: it.cls, cssClass: '.' + it.cls, figmaToken: it.token, desktop: { fontSize: it.desk.rem, fontSizePx: it.desk.px }, mobile: { fontSize: it.mob.rem, fontSizePx: it.mob.px }, clamp: it.clamp || null, lineHeight: it.lh, fontWeight: it.w, fontWeightName: it.wn, cssVariables: { size: '--' + it.cls + '-size', lh: '--' + it.cls + '-lh', weight: '--' + it.cls + '-weight' } })); }); const out = { metadata: { title: 'Typography Tokens — Compensar Medicina Prepagada', version: '2.0', generatedAt: d, source: 'Figma · Compensar v2 – Sistema de diseño', coreSources: [ 'core/abstracts/_tokens-typography.scss', 'core/base/_typography.scss', 'core/utils/_typography.scss' ], fontFamily: 'Roboto (Google Fonts)', baseRem: '1rem = 16px', description: 'Escala tipográfica completa del Design System. Cada token expone size, line-height y font-weight.', usage: { html: '

# Título

', css: 'font-size: var(--mp-h1-size);', sass: '@include mp-h1;', rule: 'Nunca usar valores hardcoded (font-size: 32px). Siempre token o clase .mp-*.' } }, categories, utilities: utilsScss ? tyParseUtilitiesFromScss(utilsScss) : { type: [], color: [], behavior: [] } }; tyDownloadFile('typography-tokens.json', JSON.stringify(out,null,2), 'application/json'); } window.tyDownloadCSS = tyDownloadCSS; window.tyDownloadSCSS = tyDownloadSCSS; window.tyDownloadJSON = tyDownloadJSON; window.tyDownloadMAUI = tyDownloadMAUI; if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', tyRenderUtilitiesFromSource); } else { tyRenderUtilitiesFromSource(); } })();

> Fuente: `docs/transversales/fundamentos/typography.html` · v2.5.0
