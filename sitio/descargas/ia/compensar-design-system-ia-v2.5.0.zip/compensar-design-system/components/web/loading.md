# Loading

> Fuente: `docs/web/components/loading.html` · Plataforma: Web · Sistema de diseño v2.5.0

Representa el estado en el que la información aún no ha cargado. Ayuda a reducir la incertidumbre del usuario y mejora la percepción de rendimiento del sistema.

Estado: estable Versión 1.0 Web Categoría: feedback Figma: 4610:73484

## Resumen

### Cuándo usarlo

- Cuando los datos están en proceso de carga.
- Cuando hay transición entre vistas o actualización de resultados.
- Cuando se espera una respuesta breve del sistema.
- Para cargas cortas con mensaje visible de estado.

### Do

Muestra el estado con animación y texto claro.

Estamos buscando opciones para ti...

### Don't

No dejes una pantalla bloqueada sin mensaje ni salida esperada.

Cargando sin contexto

## Estados y variantes

### Default

Spinner centrado con texto visible.

### Inline

Acompaña acciones o mensajes compactos.

### Overlay

Cubre un bloque mientras actualiza contenido.

### Reducido

Debe conservar el texto y bajar intensidad.

## Comportamiento y reglas

- Se muestra mientras carga la información y desaparece automáticamente al terminar.
- No debe bloquear más tiempo del necesario.
- Evita tiempos largos sin feedback adicional.
- Mantén consistencia de tamaño y texto en toda la interfaz.

## Accesibilidad

- No dependas solo de la animación: conserva un texto visible.
- Usa `role="status"`, `aria-live="polite"` y `aria-busy="true"`.
- Mantén contraste adecuado en Light, Dark y High Contrast.
- Respeta usuarios con reducción de movimiento.

## Checklist QA

- Spinner mide 48 px por defecto y conserva proporciones en small/large.
- Texto visible usa 16 px y no se oculta en mobile.
- Light, Dark y High Contrast mantienen contraste correcto.
- El HTML expone `role="status"`, `aria-live` y `aria-busy`.
- Las descargas de CSS/Sass incluyen componente completo y animación separada.

## Pendiente de documentación

La página de origen no trae contenido para: Tokens usados. No se completa con suposiciones.
