# Navigation patterns

> Fuente: `docs/web/components/header.html` · Plataforma: Web · Sistema de diseño v2.5.0

3.3 — Patrones de navegación

# Navigation patterns

Define cómo se organiza y presenta la navegación según el contexto del producto. La navegación debe responder al tipo de usuario, sus objetivos y la profundidad del contenido.

Estado: estable Web / Drupal / ZT Categoría: navegación

## 4.1 — Portal público (Drupal)

Patrón orientado a exploración, descubrimiento y acceso a información general. Se utiliza en experiencias abiertas, sin autenticación, donde el usuario recorre servicios, beneficios y canales de atención.

Vista desktop

### Objetivo

Permitir que el usuario:

- explore el sitio con facilidad
- entienda la oferta de servicios
- llegue rápidamente a contenidos clave
- acceda a acciones estratégicas del negocio

### Estructura

Elementos principales:

- Logo
- Buscador
- CTA principal
- Navegación horizontal (nv1)
- Menú desplegable por categoría (nv2)

### Responsive

En pantallas pequeñas, la navegación se transforma en un patrón compacto:

- Menú hamburguesa o drawer
- Priorizar accesos principales
- Mantener visibles las acciones clave del negocio
- Se despliega de izquierda a derecha
- Se cierra al presionar la X o fuera del drawer

Vista responsive

### Comportamiento

- Navegación horizontal, visible en desktop
- Cada categoría puede desplegar subniveles
- El usuario explora sin perder contexto
- El CTA principal se mantiene siempre visible

### Uso recomendado

Usar este patrón cuando:

- El contenido es público
- El usuario necesita explorar
- Existen múltiples categorías de información
- Se busca impulsar acciones como afiliación o contacto

### Reglas de uso

- Priorizar categorías claras y reconocibles
- Mantener labels cortos
- Evitar sobrecargar el primer nivel
- Submenús agrupados por tema
- Protagonismo a acciones como "Afíliate"

## 4.2 — Zona transaccional (ZT)

Patrón orientado a ejecución de tareas y acceso frecuente a funcionalidades. Se utiliza en experiencias autenticadas donde el usuario necesita resolver acciones concretas de forma rápida y clara.

Vista desktop — menú sin colapsar

Vista desktop — menú colapsado

Vista desktop — colapsado + hover

### Objetivo

Permitir que el usuario:

- acceda rápidamente a tareas frecuentes
- navegue entre módulos funcionales
- mantenga contexto dentro del sistema
- reduzca pasos innecesarios

### Estructura

Elementos principales:

- Header superior
- Botón de menú
- Navegación lateral o drawer
- Módulos principales con subniveles
- Accesos rápidos al home o dashboard

### Responsive

En dispositivos pequeños:

- La navegación se abre desde un botón de menú
- El contenido no depende de hover
- El drawer se puede cerrar fácilmente
- El usuario identifica claramente dónde está

Menú en móvil

Menú desplegado en móvil

### Comportamiento

- Menú lateral con módulos expandibles
- Sección activa claramente identificada
- Versión compacta con solo iconos disponible
- En móvil, se presenta como drawer lateral

### Uso recomendado

Usar este patrón cuando:

- El usuario está autenticado
- Existen múltiples tareas operativas
- Hay navegación frecuente entre módulos
- El sistema necesita escalar funcionalmente

### Reglas de uso

- Priorizar tareas frecuentes al inicio
- Jerarquía clara entre niveles
- Resaltar estado activo
- Evitar menús demasiado profundos
- En versión colapsada, iconos claros y consistentes

## Accesibilidad

- Focus visible obligatorio en todos los elementos interactivos
- Navegación por teclado completa (Tab, Enter, Escape)
- Estado activo con `aria-current="page"`
- No depender solo del color para comunicar estado
- Áreas clicables mínimo 44×44 px
- En móvil, evitar patrones dependientes de hover
- Usar `aria-expanded` en submenús y drawers
- Cerrar drawer con Escape y devolver foco al botón disparador

## Componente en vivo

Lo que se ve aquí es el componente real `.mp-web-header` del Core, no una imagen. Cambia las opciones para ver cómo responde. El botón de menú aparece en pantallas menores de 768 px.

### Variantes

#### Portal público

#### Con menú desplegado (nv2)

#### Zona transaccional (ZT)

### Estados de navegación

#### Hover

#### Focus

## Pendiente de documentación

La página de origen no trae contenido para: Resumen / cuándo usarlo, Variantes, Estados, Responsive, Tokens usados. No se completa con suposiciones.
