# Sistema de iconos

> Fuente: `docs/web/components/icons-intro.html` · Plataforma: Web · Sistema de diseño v2.5.0

1.8.1

# Sistema de iconos

Una guía para elegir, usar e implementar iconos de forma consistente en las interfaces de Compensar. La iconografía debe ayudar a reconocer acciones, estados y categorías sin reemplazar el contenido principal.

Iconografía oficial

## Iconos claros, consistentes y listos para desarrollo

El sistema usa una fuente de iconos propia para mantener consistencia visual, rendimiento y facilidad de implementación. Cada icono debe conservar el mismo lenguaje outline, alinearse a la grilla y usarse solo cuando aporte comprensión.

Ver librería    Ver en Figma
`<i class="icon icon-name icon-24" aria-hidden="true"></i>`
**Primero librería oficial**

Antes de buscar alternativas, valida si el icono existe en el set Compensar.

**Tamaño base 1.5rem**

Usa 1.5rem (24px) para acciones principales; 1.25rem (20px) y 1rem (16px) solo para contextos compactos.

**Accesibilidad siempre**

Los iconos decorativos usan `aria-hidden`; los interactivos necesitan texto o `aria-label`.

Estilo base

El sistema utiliza principalmente iconos en estilo **outline**.

Este estilo se caracteriza por:

- Trazos limpios
- Formas simples
- Buena legibilidad en tamaños pequeños
- Coherencia visual con interfaces modernas

Todos los iconos del sistema **deben respetar el mismo estilo visual** para evitar inconsistencias dentro de la interfaz.

Reglas

- No usar valores arbitrarios.
- No usar decimales.
- Todo tamaño debe respetar la escala rem del sistema, equivalente a múltiplos de 8px.
- Evitar usar margin para alinear elementos internos de un componente.
- No ajustar espaciado visualmente para compensar errores de layout.
- Priorizar siempre la consistencia del sistema.

Orden de uso de iconos

Para mantener consistencia dentro del sistema, se debe seguir el siguiente orden de prioridad al seleccionar iconos.

1
Iconografía oficial del producto

La primera opción siempre debe ser la librería de iconos **proporcionada por el equipo de Compensar**. Estos iconos siguen el estilo visual oficial del sistema (outline) y representan la base de la iconografía del producto. Siempre que exista un icono dentro de esta librería, debe utilizarse antes de buscar alternativas.

Esta librería · 1025 iconos
2
Google Material Symbols

Si el icono requerido no existe en la librería principal, se puede utilizar Google Material Symbols. Estos iconos deben configurarse para mantener un estilo visual similar al del sistema.

**Configuración recomendada: **- Estilo **Outlined **- Tamaño base **1.5rem (24px)**
- Grosor de trazo consistente
- Sin rellenos sólidos

3
Font Awesome

En casos donde el icono no esté disponible ni en la librería principal ni en Google Material Icons, **se permite el uso de Font Awesome**. Debe priorizarse siempre la variante que más se acerque al estilo outline del sistema. Evitar iconos con estilos demasiado pesados o visualmente diferentes al resto del sistema.

Iconos personalizados

Algunos iconos específicos del producto han sido diseñados de forma personalizada.

Estos iconos deben:

- Seguir el mismo estilo outline del sistema
- Respetar proporciones y grosor de trazo
- Mantener consistencia con la librería base

Para facilitar su implementación en desarrollo, estos iconos deben convertirse a font icon. Esto permite:

- Mejor integración con el sistema
- Reutilización en diferentes componentes
- Control mediante CSS
- Mejor rendimiento que múltiples SVG independientes

Reglas

- Utilizar siempre iconos de la librería principal cuando existan.
- Evitar mezclar estilos diferentes dentro de una misma interfaz.
- No modificar manualmente el grosor de los iconos.
- Mantener proporciones y alineación dentro del grid del icono.
- Usar iconos solo cuando aporten valor a la comprensión de la acción.

Tamaños recomendados

### Tamaños recomendados

| Tamaño | Uso |
| --- | --- |
| Icono estándar UI | **1.5rem (24px)** |
| Icono compacto | **1.25rem (20px)** |
| Icono pequeño | **1rem (16px)** |

Evitar tamaños intermedios que rompan la consistencia visual.

Reglas

El tamaño visual del icono puede ser 1rem (16px), 1.25rem (20px) o 1.5rem (24px).
Cuando el icono sea interactivo, el área clicable mínima debe ser 2.75rem × 2.75rem (44px × 44px).
El icono debe centrarse dentro del contenedor interactivo.
No usar iconos clicables sin área táctil suficiente.

### Tamaño mínimo para iconos interactivos

El icono no necesita medir 2.75rem (44px). Lo importante es que el contenedor clicable sí respete esa medida mínima.

| Tamaño | Uso |
| --- | --- |
| Icono | **1.25rem – 1.5rem (20px – 24px)** |
| Área clicable | **2.75rem (44px)** |

## Pendiente de documentación

La página de origen no trae contenido para: Resumen / cuándo usarlo, Variantes, Estados, Propiedades / API, Responsive, Accesibilidad, Tokens usados. No se completa con suposiciones.
