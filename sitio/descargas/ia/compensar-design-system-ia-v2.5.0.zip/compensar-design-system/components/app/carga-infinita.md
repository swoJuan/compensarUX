# Carga infinita

> Fuente: `docs/app/components/carga-infinita.html` · Plataforma: App · Sistema de diseño v2.5.0

Patrón para listados largos en móvil. Se muestra una primera tanda y el usuario carga la siguiente con el gesto de deslizar hacia arriba al llegar al final de la lista (efecto swap) o con el botón «Cargar más». Cada tanda se agrega debajo de las anteriores.

Estado: estable App · .NET MAUI Figma: 8658:24679 Flujo: Efecto swap

## Resumen

### Cuándo usarlo

- Listados que crecen con el tiempo y se consultan en orden: solicitudes, citas, resultados, historial.
- Cuando el usuario suele revisar los primeros registros y solo a veces necesita los anteriores.
- Cuando cargar todo de una vez afecta el rendimiento de la app o el consumo de datos.

### Disparadores de carga

- **Gesto swap:** deslizar hacia arriba (empujar) estando al final de la lista.
- **Botón «Cargar más»:** siempre disponible como alternativa sin gesto. También reintenta tras un error.

### Do

Lotes de 7 registros, indicador del avance («Mostrando 7 de 18») y botón visible como alternativa al gesto.

### Don't

No cargues solo al gesto, no reemplaces las tarjetas ya cargadas y no uses el patrón para listas cortas (hasta 10 registros).

Si el usuario necesita saltar a una posición concreta o buscar, usa filtros o búsqueda; la carga infinita no permite ir a «la página 5».

## Anatomía

El pie del listado muestra un solo estado a la vez. El botón terciario se mantiene debajo en reposo, cargando y error.

1. **Lista de tarjetas.** Cada tanda se agrega debajo de la anterior; las tarjetas ya cargadas no se reemplazan.
2. **Indicador del gesto.** Barra de 36 × 4 px con opacidad 40 % y el texto «Desliza hacia arriba para cargar más».
3. **Contador.** «Mostrando X de Y solicitudes». Se oculta en el estado de error.
4. **Botón «Cargar más».** `mp-btn mp-btn--terciario`, alto mínimo 48 px. Alternativa al gesto y reintento tras error. Se oculta cuando no hay más registros.

## Demo interactivo

Lista ficticia de 18 solicitudes en tandas de 7. Desliza hacia arriba al final (rueda, arrastre con mouse o táctil) o usa el botón. Datos ficticios.

## Estados

Los seis estados están aprobados y diseñados en Figma (sección Swap).

### Reposo

Figma 8655:24380. Indicador del gesto, contador y botón.

### Cargando

Figma 8657:139. Spinner del DS con «Cargando más solicitudes…». El botón se ve inactivo y no actúa.

### Error con reintento

Figma 8923:25318. `mp-alert--error` con título y mensaje. El reintento es el botón «Cargar más». El gesto no reintenta.

### Fin de lista

Figma 8908:24622. Texto «No hay más solicitudes para mostrar» y sin botón.

### Vacío Estable

Figma 8954:26680. Primera carga sin registros. Usa `mp-empty-state` y no muestra pie de carga.

### Ítem skeleton Estable

Figma 8954:26839. Solo para la primera carga de la pantalla. En las tandas siguientes se usa el spinner del pie.

## Reglas de comportamiento

Valores tomados del flujo «Efecto swap». Los valores de rendimiento deben validarse con datos reales.

ReglaValor
`Registros por tanda`7 (Figma, aprobado). Rango recomendado de 5 a 10; el equipo técnico lo ajusta según rendimiento.
`Gesto swap`Solo cuenta si la lista ya está al final y el arrastre hacia arriba supera 48 px.
`Rueda / trackpad`Acumula 80 px de desplazamiento tras 700 ms de haber llegado al final, para ignorar la inercia.
`Botón «Cargar más»`Siempre visible mientras haya registros. Durante la carga se ve inactivo y no actúa.
`Cargas simultáneas`Una sola. Se ignora cualquier disparador mientras carga.
`Error`Alerta de error en el pie. El gesto queda deshabilitado; el usuario reintenta con el botón.
`Fin de lista`Se oculta el botón y se muestra el texto de fin, sin spinner. Decisión aprobada sobre el Figma 8908:24622.
`Foco`Si la carga viene del botón, el foco pasa a la primera tarjeta nueva. Si falla, el foco vuelve al botón.
`Animación de entrada`Tarjetas nuevas: 280 ms, desplazamiento de 12 px. Se desactiva con `prefers-reduced-motion`.

Rendimiento: con más de 100 registros cargados, el equipo técnico debe evaluar virtualización de la lista (reciclar vistas) para no degradar la app.

## Modos

El patrón usa solo tokens semánticos del sistema; no define colores propios.

### Light

### Dark

### Alto contraste

## Implementación en .NET MAUI

Este patrón no agrega componentes nuevos al core: se arma con la alerta, el loading, el botón terciario y el empty state existentes. La tabla orienta al equipo de desarrollo y debe validarse en la implementación.

NecesidadReferencia sugerida
`ListaCollectionView` con `ItemsSource` incremental.
`Carga por cercanía al finalRemainingItemsThreshold` y `RemainingItemsThresholdReachedCommand` sirven si se acepta carga automática. Este patrón carga con gesto o botón, por lo que el comando se invoca solo desde ellos.
`Gesto swapPanGestureRecognizer` o `SwipeGestureRecognizer` sobre el pie, activo solo con la lista al final. Umbral de 48 px.
`Pie de listaFooter` / `FooterTemplate` con el estado actual (reposo, cargando, error o fin).
`Anuncios accesiblesSemanticScreenReader.Announce` para carga, éxito, error y fin.

## Accesibilidad

### Roles y atributos

- El gesto no es la única vía: el botón «Cargar más» es la alternativa para teclado, lector de pantalla y control por switch.
- Región con `role="status"` y `aria-live="polite"` que anuncia: «Cargando más solicitudes…», «Se cargaron 7 solicitudes más. Mostrando 14 de 18», el error y el fin de la lista.
- La alerta de error no usa `role="alert"`; se anuncia por la región en vivo para no duplicar el mensaje.
- La lista usa `<ul>` con `aria-label`; cada tarjeta incluye número de radicado y estado en su etiqueta.
- El indicador del gesto y el spinner son decorativos (`aria-hidden="true"`).

### Checklist QA

- Carga con gesto y con botón; ambas agregan la misma cantidad de registros.
- Con la lista fuera del final, el gesto no dispara la carga.
- Durante la carga no se inicia otra carga.
- Tras el error, el botón reintenta y el gesto no.
- En fin de lista se oculta el botón y no hay más peticiones.
- Foco visible y orden lógico; el foco pasa a la primera tarjeta nueva al cargar con el botón.
- Contraste ≥ 4.5:1 en Light, Dark y Alto contraste.
- Zoom de texto al 200 % sin solapamientos ni texto cortado.
- Con movimiento reducido no hay animación de entrada ni rebote del indicador.

## Pendiente de documentación

La página de origen no trae contenido para: Variantes, Tokens usados. No se completa con suposiciones.
