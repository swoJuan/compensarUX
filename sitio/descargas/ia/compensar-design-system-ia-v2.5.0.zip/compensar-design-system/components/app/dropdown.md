# Dropdown / Select App

> Fuente: `docs/app/components/dropdown.html` · Plataforma: App · Sistema de diseño v2.5.0

Permite seleccionar una o varias opciones dentro de una lista. En App conserva el dropdown base y suma una variante móvil tipo bottom sheet para listas largas o con búsqueda.

Estado: estable Versión 1.0 App · .NET MAUI Bottom sheet compatible Categoría: formulario Figma: 4489:16322

## Resumen

### ¿Cuándo usar este componente?

Usa el dropdown cuando el usuario debe elegir una opción de una lista predefinida (más de 4 opciones). En móvil, usa bottom sheet cuando la lista supera 8–10 ítems o necesita búsqueda.

### ¿Cuándo NO usarlo?

Evítalo para acciones destructivas o flujos que requieran confirmación; usa un diálogo modal en su lugar. Para pocas opciones (2–3) prefiere radio buttons visibles.

### Variantes disponibles

- **Simple** — selección de un único ítem
- **Con búsqueda** — filtro de texto dentro del panel
- **Múltiple** — selección de varios ítems con chips
- **Con grupos** — opciones organizadas en categorías
- **Bottom sheet** — lista móvil persistente desde la parte inferior

### Clases base

`.mp-dropdown-group · .mp-dropdown · .mp-dropdown__trigger · .mp-dropdown__panel · .mp-dropdown__option`

## Variante App: bottom sheet

Para listas largas en móvil, el select abre un panel inferior con búsqueda, scroll interno y opciones táctiles de 48 px mínimo.

### Reglas App

- Usa bottom sheet para más de 8 opciones o listas con búsqueda.
- El panel ocupa el ancho del dispositivo y se ancla al borde inferior.
- El drag handle mantiene 32 × 4 px y radio completo.
- Las opciones usan texto mínimo de 16 px y padding horizontal de 16 px.

## Estados

Default
Bogotá D.C.
Medellín
Cali
Barranquilla
Texto de apoyo
Hover
Bogotá D.C.
Medellín
Cali
Barranquilla
Texto de apoyo
Focus
Bogotá D.C.
Medellín
Cali
Barranquilla
Texto de apoyo
Con valor
Bogotá D.C.
Medellín
Cali
Barranquilla
Texto de apoyo
Error
Bogotá D.C.
Medellín
Cali
Barranquilla
Este campo es requerido
Disabled
Campo deshabilitado

## Comportamiento

### Apertura y cierre

El panel se abre al hacer clic en el trigger o al presionar Enter/Space. Se cierra al seleccionar una opción, al presionar Escape o al hacer clic fuera del componente. El trigger cambia `aria-expanded` a `true` y el caret rota 180°.

### Navegación por teclado

↑↓ navega entre opciones. Enter/Space selecciona. Escape cierra sin cambio. Home/End van al primer/último ítem. Escritura de caracteres filtra en modo búsqueda.

### Posición del panel

El panel se posiciona debajo del trigger por defecto. Si no hay espacio visible se puede invertir a la posición superior (flip). El ancho del panel iguala al del trigger.

### Selección múltiple

Cada opción seleccionada se muestra como chip dentro del trigger. El panel permanece abierto hasta que el usuario lo cierra. Los chips muestran un botón de remoción individual.

### Búsqueda integrada

En modo búsqueda, el campo de texto se ubica en la parte superior del panel con borde inferior separador. El filtro actúa sobre el texto de cada opción y muestra el estado vacío si no hay coincidencias.

### Grupos de opciones

Los encabezados de grupo no son seleccionables, se muestran en mayúsculas 11 px y no reciben foco. Los grupos se separan con un divider de 1 px.

## Guías de contenido

### Label

Siempre presente. Primera letra en mayúscula, resto en minúscula. Evitar verbos; usar sustantivos descriptivos. Ejemplo: «Ciudad de residencia», no «Selecciona tu ciudad».

### Placeholder

«Seleccionar» por defecto cuando el campo está vacío. No uses el placeholder como sustituto del label. El placeholder desaparece al seleccionar una opción.

### Opciones

Ordenar alfabéticamente salvo razón semántica (ej. frecuencia de uso). Máximo 40–50 caracteres por opción. Primera letra en mayúscula.

### Texto de apoyo

Opcional. Explica qué tipo de información se espera o añade restricciones relevantes. En estado error, reemplaza el helper con el mensaje de error específico.

### Mensaje de error

Concreto y accionable. Ejemplo: «Debes seleccionar al menos una ciudad» en lugar de «Campo requerido».

### Grupos

Los encabezados de grupo deben ser cortos (1–2 palabras). En mayúsculas sostenidas. No deben repetir la información del label del componente.

## Accesibilidad

### Roles ARIA obligatorios

- Wrapper: `role="combobox"`, `aria-expanded`, `aria-haspopup="listbox"`, `aria-controls="[panel-id]"`
- Panel: `role="listbox"` (simple) o `role="listbox" aria-multiselectable="true"` (múltiple)
- Opción: `role="option"`, `aria-selected`
- Opción deshabilitada: `aria-disabled="true"`
- Campo requerido: `aria-required="true"`
- Estado de error: `aria-invalid="true"`, `aria-describedby`

### Interacción por teclado

- Tab — mueve el foco al trigger
- Enter / Space — abre el panel o selecciona la opción activa
- ↑ / ↓ — navega entre opciones (mueve `aria-activedescendant`)
- Escape — cierra el panel, devuelve el foco al trigger
- Home / End — primera / última opción

### Contraste mínimo

4.5:1 para texto de opción y label. El estado focus debe ser perceptible sin depender solo del color.

## Responsive

El trigger ocupa el 100% del ancho de su contenedor. El panel iguala ese ancho. En viewport ≤ 480 px el panel puede expandirse a pantalla completa con un overlay para mejorar la usabilidad en touch. Las opciones mantienen el mínimo de 48 px de altura táctil.

## Tokens usados

`--use-border-subtle`
Borde default del trigger
`--use-border-hover`
Borde en hover (naranja brand)
`--use-border-strong`
Borde en active / mousedown
`--use-primary-default`
Borde focus y estado open
`--use-surface-white`
Fondo del trigger y panel
`--use-text-primary`
Texto del valor seleccionado
`--use-text-tertiary`
Placeholder y caret
`--use-surface-theme-gray-5`
Fondo de opción en hover
`--use-state-error-mandatory`
Asterisco requerido
`--use-state-error-icon`
Borde en estado error
`--use-surface-subtle`
Fondo del trigger disabled
`--use-primary-default (12%)`
Fondo de chip multi-select

## Pendiente de documentación

La página de origen no trae contenido para: Variantes, Propiedades / API. No se completa con suposiciones.
