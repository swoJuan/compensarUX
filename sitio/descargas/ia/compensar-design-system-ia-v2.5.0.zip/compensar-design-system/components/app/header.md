# Header App

> Fuente: `docs/app/components/header.html` · Plataforma: App · Sistema de diseño v2.5.0

Barra superior móvil para pantallas App. Incluye zona segura, navegación contextual, marca o título y acciones rápidas.

Estado: estable App · .NET MAUI Figma: 4485:16287 Altura: 88 px

## Resumen

### Cuándo usarlo

- Como cabezote principal en pantallas App.
- Para mostrar marca en home o título en vistas internas.
- Cuando se requiere acción rápida como notificaciones.
- Respeta la zona segura superior del dispositivo.

### Do

Usa título corto o marca clara, con iconos de 32 px y contraste alto.

## Consentimiento

### Don't

No cargues el header con textos largos ni acciones que compitan por el centro visual.

Autorizaciones y consentimientos de medicina prepagada pendientes

## Variantes

### Home

compensarmedicina
prepagada

### Pantalla interna

## Estados

### Default

### Pressed

### Focus

### Disabled

## Pendiente de documentación

La página de origen no trae contenido para: Responsive, Accesibilidad, Tokens usados. No se completa con suposiciones.
