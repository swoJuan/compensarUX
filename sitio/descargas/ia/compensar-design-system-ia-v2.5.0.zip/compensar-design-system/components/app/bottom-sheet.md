# Bottom Sheet

> Fuente: `docs/app/components/bottom-sheet.html` · Plataforma: App · Sistema de diseño v2.5.0

Panel inferior móvil para listas, filtros y selecciones contextuales. Se ancla al borde inferior de la pantalla, mantiene el foco en la tarea y evita navegar a otra pantalla cuando la decisión es breve.

Estado: estable App · .NET MAUI Figma: 4489:16322 Uso: listas / filtros

## Resumen

### Cuándo usarlo

- Para seleccionar una opción desde una lista extensa (especialidades, sedes, ciudades).
- Para filtros de citas, servicios o resultados en móvil.
- Cuando la tarea debe permanecer en el contexto actual sin cambiar de pantalla.
- Cuando se necesita búsqueda, scroll interno o acciones aplicar / limpiar.

### Do

Handle visible, campo de búsqueda accesible y opciones táctiles de mínimo 56 px.

### Don't

No uses el bottom sheet para flujos de varios pasos ni para acciones destructivas de alto impacto.

Si la tarea tiene más de un paso consecutivo o requiere confirmar datos críticos, usa una pantalla dedicada o un modal.

## Variantes

### Lista con búsqueda

Campo de búsqueda + lista de opciones con scroll. Ideal para selección de especialidad, centro o ciudad.

### Filtros

Grupos de chips de selección múltiple con acciones Aplicar / Limpiar en la zona inferior.

## Estados del ítem

### Default

### Hover

### Focus

### Seleccionado

## Modos

### Light

### Dark

### Alto contraste

## Propiedades CSS

Variables personalizables del componente. Todas se declaran en el selector raíz `.mp-bottom-sheet` y pueden sobreescribirse en contexto.

Propiedad Valor por defecto
`--mp-bs-width` 390px
`--mp-bs-bg` var(--use-surface-white, #fff)
`--mp-bs-text` var(--use-text-primary, #111)
`--mp-bs-muted` var(--use-text-tertiary, #666)
`--mp-bs-border` var(--use-border-subtle, #e0e0e0)
`--mp-bs-handle` #79747e (M3 outline)
`--mp-bs-shadow` 2px 5px 16px rgba(0,0,0,.15)
`--mp-bs-chip-bg` #f3f0fa (violet-50)
`--mp-bs-chip-text` #5d4992 (violet-700)
`--mp-bs-chip-active-bg` #775ebb (violet-600)
`--mp-bs-chip-active-text` var(--base-neutral-white, #fff)

## Accesibilidad

### Roles y atributos ARIA

- El panel raíz lleva `role="dialog"`, `aria-modal="true"` y `aria-label` o `aria-labelledby`.
- El botón handle tiene `aria-label="Arrastrar o cerrar"`.
- El campo de búsqueda usa `<label>` o `aria-label` explícito.
- Cada chip de filtro usa `aria-pressed` para reflejar el estado seleccionado.
- Los grupos de filtros usan `<section>` con `aria-labelledby` apuntando al título del grupo.

### Checklist QA

- Handle visible en todos los modos (Light, Dark, Alto contraste).
- Panel se cierra al tocar/pulsar el handle o al presionar Esc.
- Foco queda atrapado dentro del sheet mientras está abierto.
- Ítems de lista con min-height 56 px (área táctil mínima).
- Chips de filtro responden correctamente a tap/clic y actualizan `aria-pressed`.
- Botón "Aplicar" aplica los filtros seleccionados y cierra el panel.
- Botón "Limpiar" deselecciona todos los chips del panel.
- Contraste de texto ≥ 4.5:1 en todos los modos.
- Chips de filtro activos (#775ebb/#fff): contraste verificado ≥ 4.5:1.

## Pendiente de documentación

La página de origen no trae contenido para: Responsive, Tokens usados. No se completa con suposiciones.
