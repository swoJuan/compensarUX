# Alertas

> Fuente: `docs/transversales/components/alerts.html` · Plataforma: Web y App · Sistema de diseño v2.5.0

Comunican información relevante sobre el estado de una acción o del sistema. Esta página documenta la alerta contextual integrada en el contenido.

Estado: estable Versión 1.0 Web Bootstrap compatible Categoría: feedback Tipo: contextual

## Contextual (Inline / Banner)

Mensaje integrado dentro de la interfaz. Se usa para validaciones en formularios, mensajes informativos y advertencias no críticas.

### Características

- No bloquea la interacción.
- Aparece cerca del contenido relacionado.
- Puede ser persistente dentro del flujo.

### Ubicación

- Dentro de formularios.
- Bajo o sobre el elemento afectado.
- En bloques o secciones específicas.
- Siempre visible en el flujo de lectura.

**Notification title**Notification message. **Notification title**Notification message. **Notification title**Notification message.

## Resumen

### Cuándo usarlo

- Validaciones dentro de formularios o secciones específicas.
- Información que ayuda a completar una acción.
- Advertencias no críticas dentro del flujo.
- Feedback contextual que no debe bloquear al usuario.

### Do

Usa el tipo correcto y ubícalo cerca del contenido relacionado.

Solicitud enviada

Recibirás la confirmación en tu correo.

### Don’t

No dupliques mensajes ni uses alertas para decisiones que requieren confirmación.

Revisa todo

Mensaje ambiguo y poco accionable.

## Estados

Info
Success
Warning
Error

## Comportamiento

- Aparece tras una acción, evento o validación.
- No bloquea la interacción cuando es contextual.
- Puede ser persistente o temporal según el patrón que lo use.
- Si tiene cierre, el botón debe ser accesible por teclado.

## Guías de contenido

- Usa mensajes claros, visibles y accionables.
- Prioriza claridad sobre cantidad de información.
- No dupliques mensajes para la misma acción.
- Usa el tipo correcto: info, success, warning o error.

## Accesibilidad

- Contraste mínimo 4.5:1.
- No depender solo del color: incluir icono y texto.
- Usar `role="status"` para información y `role="alert"` para errores importantes.
- El cierre debe tener `aria-label` descriptivo.

## Responsive

### Desktop

Puede ocupar el ancho de la sección o mantener ancho contextual.

### Tablet

Mantiene padding 16 px y lectura en dos líneas cuando aplique.

### Mobile

Debe ajustarse a una columna sin truncar texto ni icono.

## Tokens usados

`--space-16`16px · padding interno y gap success/warning.
`--space-8`8px · gap info/error observado en Figma.
`--space-4`4px · separación entre título y cuerpo.
`--use-state-info-bg`#e6f1fb · fondo info light.
`--use-state-success-bg`#e6f7e8 · fondo success light.
`--use-state-warning-bg`#fff2d9 · fondo warning light.
`--use-state-error-bg`#f7eeed · fondo error light.
`--font-size-md`16px · título Roboto SemiBold.

## Código

Descarga estilos planos del componente transversal, unidos al core y organizados por modo.

## Pendiente de documentación

Sin pendientes detectados automáticamente. Las secciones interactivas (anatomía, playground y visualizador de código) no se incluyen porque se generan en el navegador.
