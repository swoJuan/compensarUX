# Checkbox / Radio / Switch

> Fuente: `docs/transversales/components/selection-controls.html` · Plataforma: Web y App · Sistema de diseño v2.5.0

Permiten al usuario tomar decisiones dentro de la interfaz: selección múltiple, selección única y activación inmediata de opciones binarias.

Estado: estable Versión 1.0 Web Bootstrap compatible Categoría: selección

## Resumen

### Cuándo usarlo

- Checkbox: cuando se permiten varias opciones.
- Radio: cuando solo se permite una opción por grupo.
- Switch: cuando el cambio es inmediato y binario.
- Cuando la decisión necesita label visible y accesible.

### Do

Usa el control que corresponda al tipo de decisión.

### Don't

No uses switch para decisiones que requieren guardar o confirmar.

## Estados

Por defecto
Seleccionado
Error
Disabled

## Comportamiento

- Checkbox permite múltiples selecciones y puede marcarse o desmarcarse.
- Radio solo permite una selección activa por grupo.
- Switch alterna entre dos estados y aplica el cambio de inmediato.
- Todos deben responder a click, Enter y Space.

## Guías de contenido

- Usa labels breves, claros y accionables.
- Evita preguntas ambiguas o dobles negaciones.
- El texto de apoyo debe explicar error, requisito o consecuencia.
- En switch, el label debe describir qué se activa o desactiva.

## Accesibilidad

- Área mínima: 44 x 44 px (Checkbox y Radio). Switch: área interactiva de 52 x 44 px, con track de 52 x 32 px y knob de 28 x 28 px, centrados verticalmente.
- Label asociado al control mediante estructura de label/input.
- Focus visible obligatorio: contorno de 3 px con `use/border/strong` en Checkbox, Radio y Switch. El Switch deshabilitado no recibe foco.
- No depender solo del color para error o selección.
- Grupos radio deben usar `name` compartido.

## Responsive

### Desktop

Se agrupan en listas o columnas según el formulario.

### Tablet

Mantienen área táctil y separación entre opciones.

### Mobile

Usar una opción por fila cuando haya labels largos.

## Tokens usados

`--space-8`8px · gap entre control y label.
`--use-primary-default`Color seleccionado en light y alto contraste.
`--use-primary-default-dark`#ff9d5c · color seleccionado en dark.
`--use-text-primary`Color de label y borde por defecto.
`--use-state-error-icon`Color para estado error.
`--use-border-strong`Color del contorno de focus de 3 px (Light #666666 · Dark #E0E0E0 · Alto contraste #FFFFFF).
`--body---l`16px / line-height 24px · label de Checkbox, Radio y Switch.
`--body---s`14px · texto de apoyo.

## Código

Descarga estilos planos del componente transversal, unidos al core y organizados por modo.

## Pendiente de documentación

Sin pendientes detectados automáticamente. Las secciones interactivas (anatomía, playground y visualizador de código) no se incluyen porque se generan en el navegador.
