# Cards

> Fuente: `docs/transversales/components/cards.html` · Plataforma: Web y App · Sistema de diseño v2.5.0

Contenedores que agrupan información relacionada dentro de una interfaz. Organizan contenido, facilitan la lectura y permiten acciones dentro de un mismo bloque.

Estado: estable Versión 1.0 Web Bootstrap compatible Categoría: contenido

## Resumen

### Cuándo usarlo

- Para mostrar información agrupada y fácil de escanear.
- Para resultados de búsqueda, servicios, beneficios o contenido resumido.
- Para agrupar contenido con una acción principal clara.
- Para construir vistas modulares en grillas responsive.

### Do

Usa una jerarquía simple: imagen opcional, título, texto breve y acción principal.

### Programa bienestar

Resumen corto del beneficio principal.

### Don't

No mezcles múltiples prioridades ni conviertas la card en una página completa.

### Demasiada información

Texto extenso, varias acciones principales, estados mezclados y contenido sin jerarquía reducen la claridad.

## Estados

### Default

Card disponible sin énfasis de interacción.

### Hover

Indica que la card o su acción puede ejecutarse.

### Focus

El foco debe ser visible cuando la card es interactiva.

### Disabled

Reduce énfasis y bloquea interacción.

## Variantes

### Vertical

Uso principal para contenido resumido con media opcional.

### Horizontal

Útil cuando la imagen acompaña una pieza de contenido más breve.

### Compacta

Para listados densos o agrupaciones con menos contenido.

### Interactiva

Debe tener foco visible y una acción claramente definida.

## Responsive

En pantallas pequeñas, la card se ajusta al ancho disponible y la variante horizontal se apila para conservar legibilidad.

- Usa grillas Bootstrap para distribuir cards.
- Evita alturas fijas cuando el contenido sea variable.
- Mantén el orden: imagen, contenido y acciones.

## Código

```html
<article class="mp-card mp-card--raised">
  <img class="mp-card__media"
       src="https://picsum.photos/id/1011/800/450"
       alt="Persona caminando al aire libre">
  <div class="mp-card__content">
    <header class="mp-card__header">
      <div>
        <h3 class="mp-card__title">Programa bienestar</h3>
        <p class="mp-card__subtitle">Beneficio destacado</p>
      </div>
    </header>
    <p class="mp-card__body">Encuentra servicios y acompañamiento para cuidar tu bienestar.</p>
    <footer class="mp-card__footer">
      <button type="button" class="mp-btn mp-btn--primario">Conocer más</button>
    </footer>
  </div>
</article>
html
<mp-card
  variant="raised"
  imageSrc="https://picsum.photos/id/1011/800/450"
  imageAlt="Persona caminando al aire libre"
  title="Programa bienestar"
  subtitle="Beneficio destacado"
  actionLabel="Conocer más"
  (action)="openProgram()">
  Encuentra servicios y acompañamiento para cuidar tu bienestar.
</mp-card>
html
{# Variables: card #}
<article class="mp-card {{ card.variant ? 'mp-card--' ~ card.variant }}">
  {% if card.image %}
    <img class="mp-card__media" src="{{ card.image.src }}" alt="{{ card.image.alt }}">
  {% endif %}
  <div class="mp-card__content">
    <h3 class="mp-card__title">{{ card.title }}</h3>
    <p class="mp-card__body">{{ card.body }}</p>
  </div>
</article>
```

## API del componente

| Propiedad | Tipo | Default | Descripción |
| --- | --- | --- | --- |
| `variant` | `vertical \| raised \| compact \| horizontal \| interactive` | `vertical` | Define presentación y comportamiento visual. |
| `imageSrc` | `string` | - | Imagen real opcional. No recibe filtros por tema. |
| `title` | `string` | - | Título principal de la card. |
| `disabled` | `boolean` | `false` | Reduce énfasis y desactiva interacción cuando aplica. |
| `action` | `EventEmitter \| callback` | - | Evento de la acción principal o de la card interactiva. |

## Accesibilidad

Contraste
Texto, borde y acciones deben mantener contraste AA; en alto contraste el contenedor usa borde blanco sólido.
Foco visible
Si la card es interactiva, debe poder enfocarse y mostrar un indicador visible.
Texto alternativo
Las imágenes informativas requieren `alt`; las decorativas deben usar alt vacío.
Acción clara
Evita múltiples acciones principales y no dependas solo del hover para revelar interacción.

## Pendiente de documentación

La página de origen no trae contenido para: Tokens usados. No se completa con suposiciones.
