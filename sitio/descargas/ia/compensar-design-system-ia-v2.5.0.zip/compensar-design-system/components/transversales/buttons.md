# Botón

> Fuente: `docs/transversales/components/buttons.html` · Plataforma: Web y App · Sistema de diseño v2.5.0

Permite ejecutar acciones principales, secundarias o de apoyo dentro de la interfaz. Guía la interacción, la toma de decisiones y la jerarquía visual de cada pantalla.

Estado: estable Versión 1.0 Web Bootstrap compatible Categoría: acción

## Resumen

### Cuándo usarlo

- Para ejecutar acciones principales del flujo.
- Para confirmar, guardar o continuar una tarea.
- Para navegar a la siguiente etapa con una acción explícita.
- Para acciones de apoyo que no compitan con la acción primaria.

### Do

Usa jerarquía clara y etiquetas accionables.

### Don't

No uses textos ambiguos ni jerarquías confusas.

## Estados

Default
Hover
Focus
Active
Disabled
Loading

### Texto con enlace

Si no hay acción, usa texto plano. Si navega a otra vista o URL, usa un enlace `<a>` con los tokens existentes del sistema.

#### Enlace con tag a

Usa el color de enlace existente: `--use-text-link`, expuesto como `--color-text-link` y utilidad `.mp-text-link`.

Color `--use-text-link`
Default Ver términos y condiciones
Hover Ver términos y condiciones

## Comportamiento

### Click

Ejecuta la acción asociada al hacer clic, Enter o Space.

### Loading

Muestra progreso y debe evitar doble activación.

### Error

El feedback se comunica fuera del botón con mensaje contextual.

### Responsive

Puede ocupar el ancho disponible cuando el flujo lo requiera.

## Guías de contenido

### Textos correctos

Usa verbos claros y directos.

Guardar Enviar Continuar

### Textos incorrectos

Evita palabras genéricas o confusas.

Hacer Click aquí Ir

## Accesibilidad

- Navegación por teclado con Tab; activación con Enter y Space.
- Focus visible en todos los estados.
- Contraste mínimo AA 4.5:1 para texto y controles.
- Botones solo icono requieren `aria-label` descriptivo.
- No depender solo del color para comunicar estados.

## Responsive

### Desktop

Usa ancho hug content salvo acciones principales en layouts amplios.

### Tablet

Mantiene altura y padding; puede agruparse en filas flexibles.

### Mobile

Puede usar full width para acciones críticas y conserva área táctil mínima.

## Tokens usados

`--base-brand-80`#FF6600 · inicio del gradiente primario
`--base-brand-90`#E63F0C · final del gradiente primario
`--radius-md`24px · border-radius/md
`--space-12`12px · padding vertical con iconos
`--space-16`16px · gap e icon padding cercano
`--space-32`32px · padding de solo texto y lado sin icono
`--font-size-btn`16px · texto del botón
`--font-weight-bold`700 · peso tipográfico

## Código

Descarga estilos planos del botón, unidos al core y listos para validar en dummy con tokens Figma.

```html
<button class="mp-btn mp-btn--primario" type="button">
  Guardar
</button>
```

## Pendiente de documentación

Sin pendientes detectados automáticamente. Las secciones interactivas (anatomía, playground y visualizador de código) no se incluyen porque se generan en el navegador.
