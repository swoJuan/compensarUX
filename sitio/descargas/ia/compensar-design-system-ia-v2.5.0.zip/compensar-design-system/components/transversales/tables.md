# Tables

> Fuente: `docs/transversales/components/tables.html` · Plataforma: Web y App · Sistema de diseño v2.5.0

Permiten mostrar información estructurada en filas y columnas, facilitando la lectura, comparación y gestión de datos.

Estado: estable Versión 1.0 Web Bootstrap compatible Categoría: datos

## Resumen

### Cuándo usarlo

- Para listados de información.
- Para historial de registros.
- Para resultados de búsqueda.
- Para gestión y comparación de datos.

### Tipos

- **Tabla básica:** muestra información sin interacción.
- **Tabla con acciones:** incluye acciones por fila.
- **Tabla seleccionable:** permite seleccionar una o varias filas.

## Estados especiales

### Empty state

Cuando no hay datos disponibles.

No tienes registros generados
Cuando generes un certificado aparecerá aquí.

### Loading

Mientras se cargan los datos.

Estamos buscando opciones para filtrar.

## Variantes

### Básica

### Con acciones

### Seleccionable

### Compacta

## Responsive

Las tablas deben envolver la grilla con `table-responsive` para permitir scroll horizontal cuando el contenido excede el ancho disponible.

- Máximo recomendado de 6 a 8 columnas visibles.
- Priorizar información relevante.
- Evitar acciones innecesarias por fila.
- El contenedor con scroll lleva `role="group"`, `tabindex="0"` y `aria-label` para que el teclado pueda desplazarlo.

## Código

```html
<div class="table-responsive mp-table-wrap" role="group" tabindex="0" aria-label="Tabla de solicitudes">
  <table class="table table-striped table-hover mp-table">
    <thead>
      <tr><th>Fecha solicitud</th><th>Estado</th><th class="mp-table__cell--center">Descargar</th></tr>
    </thead>
    <tbody>
      <tr><td>25/08/2023</td><td><span class="mp-badge mp-badge--warning">En trámite</span></td><td class="mp-table__actions">-</td></tr>
    </tbody>
  </table>
</div>
html
<mp-table [rows]="requests" [selectable]="true" [actions]="rowActions"></mp-table>
html
{# Variables: rows #}
<div class="table-responsive mp-table-wrap" role="group" tabindex="0" aria-label="Tabla de solicitudes">
  <table class="table table-hover mp-table">
    {% for row in rows %}
      <tr><td>{{ row.date }}</td><td>{{ row.status }}</td></tr>
    {% endfor %}
  </table>
</div>
```

## API del componente

| Propiedad | Tipo | Default | Descripción |
| --- | --- | --- | --- |
| `variant` | `basic \| striped \| hover \| bordered \| compact` | `basic` | Controla el estilo Bootstrap aplicado. |
| `selectable` | `boolean` | `false` | Agrega columna de selección y estado seleccionado. |
| `actions` | `boolean` | `false` | Muestra acciones por fila. |
| `responsive` | `boolean` | `true` | Envuelve la tabla con scroll horizontal. |

## Accesibilidad

Contraste
Filas, selección y hover deben mantener contraste suficiente.
Encabezados
Usa `th` y `scope` cuando aplique.
Teclado
Acciones y selección deben ser navegables por teclado.
No solo color
Estados como selección o error deben tener apoyo textual o estructural.

## Pendiente de documentación

La página de origen no trae contenido para: Tokens usados. No se completa con suposiciones.
