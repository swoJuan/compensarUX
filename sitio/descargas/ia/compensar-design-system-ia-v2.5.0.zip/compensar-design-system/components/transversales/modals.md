# Modal

> Fuente: `docs/transversales/components/modals.html` · Plataforma: Web y App · Sistema de diseño v2.5.0

Componente que interrumpe el flujo para presentar información importante o solicitar una decisión del usuario.

Estado: estable Versión 1.0 Web Bootstrap compatible Categoría: feedback Tipo: crítico / bloqueante

## Modal (Crítico)

Este tipo bloquea la interacción con el fondo y requiere una acción explícita antes de volver al flujo.

### Características

- Bloquea la interacción con el fondo.
- Se muestra sobre overlay `#111` al 30%.
- Requiere acción del usuario.
- Tiene alta prioridad visual.

### Ubicación

- Centrado en pantalla.
- Sobre fondo oscuro overlay.
- Nivel más alto de jerarquía visual.

## Resumen

### Cuándo usarlo

- Confirmaciones importantes o irreversibles.
- Información crítica que exige lectura.
- Validaciones que detienen el flujo.
- Flujos guiados de pocos pasos.
- No usar para mensajes simples, listas largas o feedback temporal.

### Do

Usa el modal cuando la decisión es necesaria para continuar.

### Don’t

No lo uses para confirmaciones rápidas. Para eso usa toast.

Cambios guardados

La acción se completó.

## Tamaños ideales

**Pequeño · `.modal-sm`**

300 px. Para confirmaciones cortas y mensajes de una sola acción.

**Mediano · default**

479 px. Tamaño oficial observado en Figma y recomendado por defecto.

**Grande · `.modal-lg`**

800 px. Para contenido guiado, tablas pequeñas o formularios breves.

## Estados y tipos

**Info**

Información relevante que detiene el flujo para confirmar lectura.

**Success**

Confirmación importante después de una acción de alto impacto.

**Warning**

Advertencia previa a una decisión sensible o irreversible.

**Error**

Bloqueo del flujo por error que requiere corrección o salida.

## Comportamiento

**Apertura**

Se abre después de una acción y mueve el foco al modal.

**Bloqueo**

El overlay bloquea el contenido de fondo mientras el modal está activo.

**Teclado**

ESC cierra el modal y Tab mantiene el foco dentro del contenedor.

**Cierre**

Permite cerrar con X, acción secundaria, botón principal cuando aplique o ESC.

## Guías de contenido

### Do

- Usa títulos directos que expliquen el problema o decisión.
- Redacta mensajes breves y accionables.
- Usa una sola acción primaria.

### Don’t

- No incluyas textos largos o listas extensas.
- No uses etiquetas ambiguas como “Aceptar” si la acción es irreversible.
- No combines varias decisiones en el mismo modal.

## Accesibilidad

- Usar `role="dialog"` y `aria-modal="true"`.
- Conectar título con `aria-labelledby`.
- Conectar mensaje con `aria-describedby`.
- Devolver el foco al botón que abrió el modal.

- Focus visible en cierre y acciones.
- Contraste mínimo AA.
- No depender solo del color para comunicar tipo.
- No abrir múltiples modales simultáneamente.

## Responsive

**Desktop**

Centrado, con ancho máximo según tamaño y overlay completo.

**Tablet**

Mantiene el ancho máximo disponible y conserva margen lateral.

**Mobile**

Ocupa el ancho disponible con 16 px de margen lateral mínimo.

## Tokens usados

| Token / regla | Valor | Uso |
| --- | --- | --- |
| `use/surface/white` | #ffffff / modos | Fondo del modal |
| `use/border/default` | #cccccc | Borde del contenedor |
| `space/24` | 24 px | Padding interno y gap |
| `shadow/modal` | 2px 5px 16px rgba(0,0,0,.15) | Elevación Figma |
| Radio | 12 px | Radio del contenedor |
| Icono | 64 px / interno 32 px | Elemento visual de estado |
| Overlay | #111 · 30% | Bloqueo de fondo |

## Código

Ejemplos con estructura Bootstrap y clases productivas `mp-modal` del core.

## Pendiente de documentación

Sin pendientes detectados automáticamente. Las secciones interactivas (anatomía, playground y visualizador de código) no se incluyen porque se generan en el navegador.
