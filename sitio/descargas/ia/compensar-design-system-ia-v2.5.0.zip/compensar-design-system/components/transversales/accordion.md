# Accordion

> Fuente: `docs/transversales/components/accordion.html` · Plataforma: Web y App · Sistema de diseño v2.5.0

Organiza contenido en paneles colapsables para reducir carga visual y permitir que el usuario consulte detalles solo cuando los necesita.

Estado: estable Versión 1.0 Web / App Categoría: contenido Figma: 4622:76590

## Resumen

### Cuándo usarlo

- Para preguntas frecuentes o contenido de soporte.
- Para detalles secundarios que no deben ocupar toda la página.
- Para agrupar secciones independientes de información.
- Cuando el usuario puede decidir qué bloque consultar.

### Do

Usa títulos claros y contenido breve dentro de cada panel.

Incluye atención de urgencias según el plan contratado.

### Don't

No escondas pasos obligatorios ni información crítica que el usuario deba ver completa.

Formulario completo oculto

## Estados

### Default

Ítem disponible.

### Abierto

Panel expandido.

### Cerrado

Panel colapsado.

### Hover

Indica interacción.

### Focus

Visible con teclado.

## Comportamiento y reglas

- El trigger completo debe ser clicable.
- Permite múltiples paneles abiertos salvo que el flujo pida modo exclusivo.
- Usa títulos breves y descriptivos.
- No ocultes acciones críticas ni pasos obligatorios.

## Accesibilidad

- El trigger es un `button` con `aria-expanded`.
- El panel usa `role="region"` y referencia al trigger.
- Tab, Enter y Space deben funcionar nativamente.
- Focus visible en todos los modos de color.

## Checklist QA

- Trigger usa texto mínimo de 16 px y componente real `mp-accordion`.
- Chevron 24 px rota al abrir/cerrar.
- Hover y focus son evidentes en los estados interactivos.
- El panel actualiza `aria-expanded` y altura al interactuar.
- Light, Dark y High Contrast mantienen contraste correcto.

## Pendiente de documentación

La página de origen no trae contenido para: Variantes, Tokens usados. No se completa con suposiciones.
