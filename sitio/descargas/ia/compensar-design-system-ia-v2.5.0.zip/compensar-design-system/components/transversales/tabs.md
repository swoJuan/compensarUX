# Tabs

> Fuente: `docs/transversales/components/tabs.html` · Plataforma: Web y App · Sistema de diseño v2.5.0

Organizan contenido relacionado en secciones de una misma vista. Permiten alternar entre paneles sin recargar la página y mantienen el contexto de la tarea. Disponible en tres formatos: Texto, Pill XL y Tarjeta con ícono.

Estado: estable Versión 1.0 · formatos XL desde DS v2.5.0 Web Bootstrap compatible Categoría: navegación

Elige el formato para ver su documentación. Pill XL y Tarjeta con ícono (v2, color Naranja o Violeta) están aprobados por UX y disponibles desde la versión 2.5.0 del sistema de diseño.

## Resumen

### Cuándo usarlo

- Para agrupar contenido relacionado dentro de una misma vista.
- Para alternar entre paneles sin cambiar de página.
- Para mejorar el escaneo de información por categorías.
- Para mantener visible el contexto mientras cambia el contenido.

### Do

Usa labels cortos y un máximo recomendado de 4 a 5 tabs.

### Don't

No lo uses como navegación global ni con etiquetas largas.

## Estados

### Default

Opción disponible no seleccionada.

### Active

Muestra el contenido activo de la sección.

### Hover

Indica que el tab es interactivo.

### Disabled

Tab no disponible para interacción.

## Variantes

### Solo texto

Uso principal cuando las categorías son claras por texto.

### Con ícono

Úsalo solo cuando el ícono aporte claridad real al escaneo.

## Responsive

Por debajo de **768 px **(punto de quiebre `md`, el mismo de cards y sidebar) la tira de pestañas se presenta como** menú desplegable**. No hay que cambiar el marcado: lo hace `js/mp-tabs.js`, que oculta la tira y, en su lugar, inserta un `<select>` con las mismas opciones.

- Transformarse en menú desplegable.
- Mantener la selección visible.
- Facilitar la navegación en espacios reducidos.

Al elegir una opción se activa la pestaña correspondiente. Si las pestañas son enlaces (`<nav class="mp-tabs">` con `<a class="mp-tab">`), la opción **navega **a esa página. Al volver a 768 px o más, el desplegable se retira y reaparece la tira.** Sin JavaScript** la tira no se parte en dos líneas: se desplaza en horizontal. Es una red de seguridad, no el comportamiento esperado: carga siempre `js/mp-tabs.js`.

Ejemplo en vivo: reduce la ventana por debajo de 768 px y esta tira se convierte en desplegable.

Contenido de Servicios.

### Dejar una tira fuera

Los especímenes de esta documentación conservan la tira a cualquier ancho para poder mostrarla. Para hacer lo mismo en una página, marca el contenedor con `data-mp-tabs-responsive="off"`. Úsalo solo para muestras visuales: en una pantalla real, las pestañas deben convertirse en desplegable.

## Código

```html
<div class="mp-tabs" role="tablist" aria-label="Secciones del portal">
  <button class="mp-tab is-active" role="tab" aria-selected="true"
          aria-controls="panel-servicios" id="tab-servicios">
    Servicios
  </button>
  <button class="mp-tab" role="tab" aria-selected="false"
          aria-controls="panel-beneficios" id="tab-beneficios" tabindex="-1">
    Beneficios
  </button>
</div>

<div class="mp-tab-panel" role="tabpanel" id="panel-servicios"
     aria-labelledby="tab-servicios">
  Contenido de servicios...
</div>
<div class="mp-tab-panel" role="tabpanel" id="panel-beneficios"
     aria-labelledby="tab-beneficios" hidden>
  Contenido de beneficios...
</div>
html
<mp-tabs ariaLabel="Secciones del portal" (tabChange)="onTabChange($event)">
  <mp-tab label="Servicios">
    <p>Contenido de servicios...</p>
  </mp-tab>
  <mp-tab label="Beneficios" icon="favorite">
    <p>Contenido de beneficios...</p>
  </mp-tab>
  <mp-tab label="Historial" disabled></mp-tab>
</mp-tabs>
html
{# Variables: tabs, aria_label #}
<div class="mp-tabs" role="tablist" aria-label="{{ aria_label }}">
  {% for tab in tabs %}
    <button class="mp-tab{{ loop.first ? ' is-active' }}"
            role="tab"
            aria-selected="{{ loop.first ? 'true' : 'false' }}"
            aria-controls="tab-panel-{{ loop.index }}"
            id="tab-{{ loop.index }}"
            {{ not loop.first ? 'tabindex="-1"' }}
            {{ tab.disabled ? 'disabled' }}>
      {{ tab.label }}
    </button>
  {% endfor %}
</div>
```

## API del componente

| Propiedad | Tipo | Default | Descripción |
| --- | --- | --- | --- |
| `label` | `string` | - | Texto visible del tab. Debe ser corto y claro. |
| `icon` | `string` | - | Nombre del ícono opcional. El ícono se marca con `aria-hidden="true"`. |
| `disabled` | `boolean` | `false` | Deshabilita el tab y lo elimina de la interacción por teclado. |
| `ariaLabel` | `string` | - | Etiqueta accesible para el contenedor con `role="tablist"`. |
| `data-mp-tabs-responsive` | `"off"` | - | En el contenedor: deja la tira fuera del menú desplegable de móvil (solo para muestras visuales). |
| `tabChange` | `EventEmitter<number>` | - | Emite el índice seleccionado cuando cambia el tab activo. |

## Accesibilidad

Foco visible
El foco debe ser visible en cada tab, activo o inactivo. El componente dibuja un contorno exterior de 3 px con `use/border/strong` alrededor de la superficie visual de 35 px; si lo reemplazas, no lo elimines sin una alternativa visible.
Teclado
Flechas laterales cambian el foco entre tabs; `Tab` avanza al panel activo.
ARIA
Usa `tablist`, `tab`, `tabpanel`, `aria-controls` y `aria-labelledby`.
No solo color
El activo debe diferenciarse por color, forma y peso visual; no dependas solo del color.

## Pendiente de documentación

La página de origen no trae contenido para: Tokens usados. No se completa con suposiciones.
