# Avatar / User chip

> Fuente: `docs/transversales/components/avatar.html` · Plataforma: Web y App · Sistema de diseño v2.5.0

Representa una persona mediante foto, iniciales o icono, y puede combinarse con nombre y metadata en headers, cards, listas y menús de usuario.

Estado: estable Web / App Categoría: identidad Header / cards / listas

## Resumen

### Cuándo usarlo

- Para identificar al usuario actual en headers o menús de sesión.
- Para mostrar profesionales, asesores o pacientes en cards y listados.
- Para agrupar participantes en un contexto de equipo o atención.
- Cuando la foto no existe, usa iniciales; si no hay nombre, usa icono.

### Do

Usa foto o iniciales con texto visible cuando el usuario necesita reconocer a la persona.

### Don't

No uses una imagen sin alternativa visible si la identidad es crítica.

Sin nombre ni contexto

## Variantes

### Foto

### Iniciales

AR

### Icono

### User chip

## Estados

### Default

### Hover

### Focus

### Compact

## Pendiente de documentación

La página de origen no trae contenido para: Responsive, Accesibilidad, Tokens usados. No se completa con suposiciones.
