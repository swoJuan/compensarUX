# Historial de versiones

Versión de este paquete: v2.5.0.

## v2.5.0 — 2026-11-25

Core Design System v2.5.0 — Tabs v2: Pill XL y Tarjeta con ícono (mp-tab-xl, mp-tab-card), color Violeta, Light/Dark/Alto contraste


**Qué revisar:** Tabs v2 (aprobado por UX): Pill XL y Tarjeta con ícono en Naranja y Violeta, sin sombra en Active. Verificar contraste de texto de 4,5:1, foco de 3 px (4 px en Alto contraste), navegación por teclado y el desplegable por debajo de 768 px. El mp-tab base no cambia.

## v2.4.0 — 2026-11-11

Core Design System v2.4.0 — Tabs: menú desplegable por debajo de 768 px (informe 32)



## v2.3.0 — 2026-11-11

v2.3.0: cierre técnico de la estabilización. Verificaciones diferidas: Safari, VoiceOver y revisión visual del equipo.


**Qué revisar:** Cambios de color en badges e íconos de advertencia, y títulos de tarjeta en negrita. Pendientes de revisión visual del equipo, Safari y VoiceOver.

## v2.2.1 — 2026-11-06

Core Design System v2.2.1 — DEC-003 estados de Inputs (Error, Focus, Disabled, Readonly) conforme a Figma



## v2.2.0 — 2026-11-06

Design System v2.2.0 — campos de solo lectura y deshabilitados


