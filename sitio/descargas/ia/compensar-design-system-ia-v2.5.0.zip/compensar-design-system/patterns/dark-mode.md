# Dark Mode — Reglas de uso

> Fuente: `docs/guidelines/dark-mode.html` · Plataforma: Web y App · Sistema de diseño v2.5.0

El modo oscuro reduce la fatiga visual, respeta la preferencia del sistema del usuario y mantiene la identidad de marca. Su implementación correcta depende exclusivamente de tokens semánticos `--use-*` — nunca de colores hardcodeados.

Estado: estable Web · ZT Drupal Tokens semánticos WCAG AA

## Principios generales

El sistema conmuta entre temas únicamente cambiando `data-theme` en el elemento raíz. Ningún componente debe tener lógica de color propia.

- Usa solo tokens `--use-*`; nunca valores raw.
- Las superficies se apilan por elevación, no por brillo arbitrario.
- El contraste texto / fondo ≥ 4.5:1 en todo momento (WCAG AA).
- El naranja de marca se aclara en dark para conservar legibilidad.

## Superficies y elevación

Las superficies definen profundidad mediante tokens, no colores arbitrarios. En dark, cada nivel es ligeramente más claro que el anterior.

- Nivel 0 — fondo de página: `--use-surface-bg`
- Nivel 1 — cards y paneles: `--use-surface-white`
- Nivel 2 — modales y popovers: `--use-surface-theme-gray-5`
- No mezclar niveles sin borde o separador visual.

## Color y tokens semánticos

Los tokens de estado mantienen su semántica en dark — solo cambia el tono para garantizar contraste.

- El primario naranja aclara a `#FF9D5C` (base/brand/80 dark).
- Badges, chips y tags adaptan su tono automáticamente.
- Los botones secundario y terciario usan bordes más visibles.
- No redefinas colores en componentes individuales.

## Alertas y feedback

Los componentes de feedback mantienen su semántica en dark — el color cambia de tono pero nunca de significado.

- No depender solo del color para comunicar el estado.
- El icono refuerza el mensaje en todos los temas.
- El texto siempre debe ser legible sobre el fondo del alert.
- Los toasts heredan los tokens de superficie nivel 2.

## Inputs y formularios

Los campos de formulario adaptan fondo, borde y texto automáticamente. El error siempre combina icono + texto.

- El borde del campo es visible en default, focus y error.
- El placeholder usa `--use-text-placeholder` (contraste suficiente).
- Labels siempre visibles — nunca desaparecen al enfocar.
- El estado de error no depende solo del color rojo.

## Navegación y estados interactivos

Todos los estados (hover, focus, active, disabled) deben ser perceptibles en dark sin ajustes manuales.

- El focus ring usa `--use-focus-ring` que cambia en dark automáticamente.
- Los botones disabled bajan opacidad sin perder legibilidad.
- El breadcrumb y tabs usan tokens de texto y borde.
- El ítem activo combina color + borde para no depender solo del tono.

## Cards y contenedores

Las cards no necesitan ajuste manual — sus tokens de superficie y borde se adaptan en dark.

- Las sombras se reducen en dark — el borde suple su función.
- Imágenes fotográficas nunca se filtran ni invierten.
- La jerarquía de contenido se mantiene sin cambios de HTML.
- Los dividers usan `--use-border-subtle` siempre.

## Sí hacer

- Usar siempre tokens `--use-*` para colores.
- Probar el flujo completo en dark antes de entregar.
- Validar contraste ≥ 4.5:1 con herramienta automática.
- Mantener la jerarquía tipográfica visible en todos los temas.
- Conservar bordes en contenedores cuando no hay sombra.

## No hacer

- Usar colores hexadecimales o RGB hardcodeados.
- Invertir imágenes fotográficas o ilustraciones con `filter: invert()`.
- Depender solo del color para comunicar un estado.
- Mezclar superficies de distinto nivel sin separación visual.
- Aplicar `filter: brightness()` a iconos SVG del sistema.

## Accesibilidad en dark mode

4.5:1

Contraste mínimo para texto normal (WCAG AA)

3:1

Contraste mínimo para texto grande (≥ 18px bold o ≥ 24px)

3:1

Contraste mínimo para componentes UI e íconos informativos

70%

Opacidad mínima de texto en estados secundarios

- El focus ring cambia automáticamente con `--use-focus-ring` en dark.
- Validar con usuarios reales que usan el modo oscuro del sistema operativo.
- Los iconos decorativos tienen `aria-hidden="true"` en todos los temas.
- Los mensajes de error incluyen texto descriptivo, no solo color.

## Pendiente de documentación

La página de origen no trae contenido para: Resumen / cuándo usarlo, Variantes, Propiedades / API, Responsive. No se completa con suposiciones.
