# Search & Filters

> Fuente: `docs/guidelines/search-filters.html` · Plataforma: Web y App · Sistema de diseño v2.5.0

3.2 — Patrones de interacción

# Search & Filters

Permite a los usuarios encontrar información de forma rápida mediante búsqueda y filtrado. Se utiliza para reducir resultados y facilitar la toma de decisiones.

Estado: estable Web / App Lógica AND

## Demo

Buscar por nombre
Especialidad
Bogotá DC
Bogotá DC  Oftalmología  Neurología  Psiquiatra  Pediatría

Encontramos **0** opciones para ti

No encontramos resultados con los filtros seleccionados

Intenta ajustar o eliminar algunos filtros para ver más opciones

### Estructura base

- Input de búsqueda
- Filtros (chips / dropdown / select)
- Resultados (cards o tabla)
- Paginación (opcional)
- Empty / loading

### Tipos de filtros

- Filtros simples (una opción)
- Filtros múltiples (varias opciones)
- Filtros combinados

## Lógica de filtros

Cuando el usuario selecciona múltiples filtros, el sistema aplica una lógica de tipo: **AND (Y lógico)**

Comportamiento

Cada filtro aplicado hace la búsqueda más específica

- Agregar filtro → reduce resultados
- Quitar filtro → amplía resultados

Ejemplo

Filtros seleccionados:

- **Ciudad:** Bogota D.C
- **Especialidad:** Cardiología

Resultados

Centros en Bogota D.C **Y**
que tengan Cardiología

## Comportamiento y reglas

### Comportamiento

- La búsqueda filtra resultados en tiempo real o al ejecutar acción
- Los filtros reducen el conjunto de resultados
- Los resultados se actualizan automáticamente al aplicar filtros

### Reglas de uso

- Usar filtros cuando hay muchos resultados
- No usar filtros innecesarios
- Priorizar filtros relevantes
- Mantener claridad en las opciones

## Accesibilidad

- Focus visible en todos los filtros y el input de búsqueda
- Labels claros y asociados correctamente con `for` / `aria-label`
- Filtros seleccionados visibles y con estado comunicado vía `aria-pressed`
- No depender solo del color para indicar estado activo
- Anunciar cambios de resultados con `aria-live="polite"`

## Pendiente de documentación

La página de origen no trae contenido para: Resumen / cuándo usarlo, Variantes, Estados, Propiedades / API, Tokens usados. No se completa con suposiciones.
