# Patrones y guías

Patrones de navegación, formularios, búsqueda, responsive, movimiento y modos de color del sistema de diseño.

- [Form Patterns](form-patterns.md) — `docs/guidelines/form-patterns.html`
- [Search & Filters](search-filters.md) — `docs/guidelines/search-filters.html`
- [Responsive / Breakpoints](responsive-breakpoints.md) — `docs/guidelines/responsive-breakpoints.html`
- [Motion / Animación](motion-animation.md) — `docs/guidelines/motion-animation.html`
- [Dark Mode — Reglas de uso](dark-mode.md) — `docs/guidelines/dark-mode.html`
- [High Contrast — Reglas de uso](high-contrast.md) — `docs/guidelines/high-contrast.html`
