# Form Patterns

> Fuente: `docs/guidelines/form-patterns.html` · Plataforma: Web y App · Sistema de diseño v2.5.0

Guía de estructura, layout y componentes para construir formularios accesibles y de alta conversión. Incluye el componente `mp-stepper` para flujos multi-paso.

Estado: estable Web · ZT Drupal Componente: mp-stepper WCAG AA

## Resumen

### Principios

- Labels siempre visibles — nunca reemplazar con placeholder.
- Campos obligatorios marcados con `*` y leyenda al inicio.
- Agrupar campos relacionados en secciones con título en MAYÚSCULAS.
- Acción primaria (enviar) a la derecha; terciaria (cancelar) a la izquierda.
- Feedback de validación inline — no solo al hacer submit.
- Usar `mp-stepper` en flujos de más de 2 pasos o con 7+ campos.

### Do

Label visible sobre el campo, estado de error con icono y texto.

Campo obligatorio

### Don't

No uses placeholder como label ni indiques error solo con color.

## Stepper — Anatomía interactiva

El componente `mp-stepper` indica el avance en formularios multi-paso mediante barras de progreso proporcionales.

**Head **`.mp-stepper__head` — contenedor del count y título del paso.** Count + Title **`.mp-stepper__count` texto secundario. `.mp-stepper__title` heading semántico.** Track **`.mp-stepper__track` — fila flex de barras, `role="progressbar"` con `aria-valuenow`.** Barras **`.is-done` completado · `.is-current` activo · sin clase = pendiente.** Compact** `.mp-stepper--compact` oculta el head. Usar cuando el título del paso vive fuera del stepper.
2 px — alto barra 3 barras

## Variantes

Paso 1 de 3 — inicio

Paso 1 de 3

### Datos personales

Paso 2 de 3 — en progreso

Paso 2 de 3

### Elige la fecha y hora

Paso 3 de 3 — último

Paso 3 de 3

### Confirmación y envío

5 pasos — intermedio

Paso 3 de 5

### Información médica

Compact — solo barras

Paso 2 de 4

### Modos de color

Light

Paso 2 de 3

### Elige la fecha

Dark

Paso 2 de 3

### Elige la fecha

High Contrast

Paso 2 de 3

### Elige la fecha

```html
<!-- Stepper estándar -->
<div class="mp-stepper" role="group" aria-label="Progreso del formulario">
  <div class="mp-stepper__head">
    <span class="mp-stepper__count">Paso 2 de 3</span>
    <h2 class="mp-stepper__title">Elige la fecha y hora</h2>
  </div>
  <div class="mp-stepper__track"
       role="progressbar"
       aria-valuenow="2"
       aria-valuemin="1"
       aria-valuemax="3"
       aria-label="Paso 2 de 3">
    <div class="mp-stepper__bar is-done"></div>
    <div class="mp-stepper__bar is-current"></div>
    <div class="mp-stepper__bar"></div>
  </div>
</div>

<!-- Variante compact -->
<div class="mp-stepper mp-stepper--compact" role="group" aria-label="Paso 2 de 4">
  <div class="mp-stepper__track" role="progressbar" aria-valuenow="2" aria-valuemin="1" aria-valuemax="4" aria-label="Paso 2 de 4">
    <div class="mp-stepper__bar is-done"></div>
    <div class="mp-stepper__bar is-current"></div>
    <div class="mp-stepper__bar"></div>
    <div class="mp-stepper__bar"></div>
  </div>
</div>
```

## Estructura base de formulario

Demo interactivo: Reembolso de medicamentos. Interactúa con los campos, selects y botones.

### Grilla de campos

- **1 col** — campos largos (nombre, descripción).
- **2 col** — campos relacionados (tipo doc / número).
- **3 col** — campos cortos en la misma fila.
- Gap entre campos: `16 px`.
- Gap entre secciones: `32 px`.

### Orden recomendado

- Breadcrumb de contexto.
- Título + descripción del formulario.
- Alert informativo si aplica.
- Secciones con título en MAYÚSCULAS.
- Acciones al final.

### Acciones

- Primario (enviar) a la derecha.
- Terciario (cancelar) a la izquierda.
- Máximo 3 acciones visibles.

## Reembolso de medicamentos

Diligencia el formulario para gestionar el reembolso de tus medicamentos.

Importante

Si eres usuario de programas especiales (VIH, cáncer, artritis), solicita el reembolso directamente a miprescompensar@compensarsalud.com.

## Formulario multi-paso

Patrón para flujos con más de 7 campos o con dependencias lógicas. El stepper siempre al inicio de cada paso.

### Cuándo usar

- Más de 7–8 campos en total.
- Secciones con dependencias lógicas entre pasos.
- Flujos de agendamiento, afiliación o radicación.

### Reglas de navegación

- Stepper siempre al inicio del paso.
- "Regresar" no borra datos ingresados.
- Validar antes de avanzar al paso siguiente.
- Ofrecer guardar borrador en flujos largos.

### Último paso

- Mostrar resumen antes del envío final.
- Confirmar con modal si la acción es irreversible.

Paso 2 de 3

### Elige la fecha y hora

## Comportamiento y reglas

### Sí hacer

- Label visible sobre cada campo.
- Campos obligatorios con `*` y leyenda visible.
- Error inline con icono + texto descriptivo.
- Agrupar campos en secciones.
- Stepper en flujos de más de 2 pasos.
- Regresar sin perder datos ingresados.

### No hacer

- Usar el placeholder como reemplazo del label.
- Pedir información innecesaria o duplicada.
- Validar solo al hacer submit.
- Ocultar el stepper en pasos intermedios.
- Más de 3 acciones en la barra de botones.
- Reiniciar el formulario al navegar entre pasos.

## Accesibilidad y checklist QA

### Accesibilidad

- Label siempre visible — nunca reemplazar con placeholder.
- Altura mínima 44 px en campos y botones (WCAG).
- Errores: `aria-invalid="true"` + `aria-describedby` al mensaje.
- Mensaje de error = icono + texto, nunca solo color.
- `mp-stepper__track` con `role="progressbar"` y `aria-valuenow/min/max`.
- Selects: clase combinada `mp-input-field mp-select`.

### Checklist QA

- Labels visibles y asociados con `for`/`id`.
- Campos obligatorios con `*` y leyenda al inicio.
- Errores: `aria-invalid`, icono y texto descriptivo.
- Stepper actualiza `aria-valuenow` al navegar.
- "Regresar" no borra datos ya ingresados.
- Se ve correctamente en Light, Dark y High Contrast.
- Focus ring visible con navegación por teclado.

## Pendiente de documentación

La página de origen no trae contenido para: Estados, Propiedades / API, Tokens usados. No se completa con suposiciones.
